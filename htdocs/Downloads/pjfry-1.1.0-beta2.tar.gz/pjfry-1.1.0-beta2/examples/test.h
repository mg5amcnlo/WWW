      
      printenabled=1
      maxeval=5
      
      SQRTS=100D0              !CMS energy in GEV
      
      ps1=4D0
      ps2=4D0
      ps3=25D0
      ps4=25D0
      ps5=0D0
      ms1=0D0
      ms2=4D0
      ms3=0D0
      ms4=25D0
      ms5=0D0
      