/*
 * This file automatically produced by /opt/net/Mathematica/8.0.4/SystemFiles/Links/MathLink/DeveloperKit/Linux-x86-64/CompilerAdditions/mprep from:
 *	PJFry.tm
 * mprep Revision 16 Copyright (c) Wolfram Research, Inc. 1990-2009
 */

#define MPREP_REVISION 16

#include "mathlink.h"

int MLAbort = 0;
int MLDone  = 0;
long MLSpecialCharacter = '\0';

MLINK stdlink = 0;
MLEnvironment stdenv = 0;
#if MLINTERFACE >= 3
MLYieldFunctionObject stdyielder = (MLYieldFunctionObject)0;
MLMessageHandlerObject stdhandler = (MLMessageHandlerObject)0;
#else
MLYieldFunctionObject stdyielder = 0;
MLMessageHandlerObject stdhandler = 0;
#endif /* MLINTERFACE >= 3 */

/********************************* end header *********************************/


# line 1 "PJFry.tm"
/*
 * PJFry.tm - MathLink inteface for PJFry library
 *
 * To launch this program from within Mathematica use:
 *   In[1]:= link = Install["PJFry"]
 *
 * Or, launch this program from a shell and establish a peer-to-peer connection.
 * When given the prompt Create Link: type a port name.
 * Then, from within Mathematica use:
 *   In[1]:= link = Install["portname", LinkMode->Connect]
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include <iostream>
#include <mathlink.h>
#include "../src/pjfry.h"

// ====================================================================

# line 51 "PJFry.cpp"


# line 100 "PJFry.tm"
// ==================== My wrappers =========================

# line 57 "PJFry.cpp"


# line 134 "PJFry.tm"
// ==================== BUBBLES =========================

# line 63 "PJFry.cpp"


# line 160 "PJFry.tm"
// ==================== TRIANGLES =========================

# line 69 "PJFry.cpp"


# line 194 "PJFry.tm"
// ==================== BOXES =========================

# line 75 "PJFry.cpp"


# line 236 "PJFry.tm"
// ==================== PENTAGONS =========================

# line 81 "PJFry.cpp"


# line 286 "PJFry.tm"
// ==================== HEXAGONS =========================

# line 87 "PJFry.cpp"


# line 347 "PJFry.tm"
// ====================================================================

using namespace std;

void fClearCache() {
    PJFry::ClearCache();
    MLPutSymbol(stdlink, "Null");
}

double fGetMu2() {
    return PJFry::GetMu2();
}

double fSetMu2(double newmu2) {
    return PJFry::SetMu2(newmu2);
}

void fA0v0(double m1, int ep) {
    complex<double> result = PJFry::A0v0(m1,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fB0v0(double p1,
           double m1,  double m2, int ep) {
    complex<double> result = PJFry::B0v0(p1,m1,m2,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fB0v1(int i,
           double p1,
           double m1,  double m2, int ep) {
    complex<double> result = PJFry::B0v1(i,p1,m1,m2,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fB0v2(int i, int j,
           double p1,
           double m1,  double m2, int ep) {
    complex<double> result = PJFry::B0v2(i,j,p1,m1,m2,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fC0v0(double p1,  double p2,  double p3,
           double m1,  double m2,  double m3, int ep) {
    complex<double> result = PJFry::C0v0(p1,p2,p3,m1,m2,m3,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fC0v1(int i,
           double p1,  double p2,  double p3,
           double m1,  double m2,  double m3, int ep) {
    complex<double> result = PJFry::C0v1(i,p1,p2,p3,m1,m2,m3,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fC0v2(int i, int j,
           double p1,  double p2,  double p3,
           double m1,  double m2,  double m3, int ep) {
    complex<double> result = PJFry::C0v2(i,j,p1,p2,p3,m1,m2,m3,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fC0v3(int i, int j, int k,
           double p1,  double p2,  double p3,
           double m1,  double m2,  double m3, int ep) {
    complex<double> result = PJFry::C0v3(i,j,k,p1,p2,p3,m1,m2,m3,ep);
    MLPutFunction(stdlink, "Complex", 2);
    MLPutReal64(stdlink, result.real());
    MLPutReal64(stdlink, result.imag());
}

void fD0v0(double p1,  double p2,  double p3,  double p4,
           double s12, double s23,
           double m1,  double m2,  double m3,  double m4,  int ep) {
  complex<double> result = PJFry::D0v0(p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fD0v1(int i,
           double p1,  double p2,  double p3,  double p4,
           double s12, double s23,
           double m1,  double m2,  double m3,  double m4,  int ep) {
  complex<double> result = PJFry::D0v1(i,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fD0v2(int i, int j,
           double p1,  double p2,  double p3,  double p4,
           double s12, double s23,
           double m1,  double m2,  double m3,  double m4,  int ep) {
  complex<double> result = PJFry::D0v2(i,j,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fD0v3(int i, int j, int k,
           double p1,  double p2,  double p3,  double p4,
           double s12, double s23,
           double m1,  double m2,  double m3,  double m4,  int ep) {
  complex<double> result = PJFry::D0v3(i,j,k,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fD0v4(int i, int j, int k, int l,
           double p1,  double p2,  double p3,  double p4,
           double s12, double s23,
           double m1,  double m2,  double m3,  double m4,  int ep) {
  complex<double> result = PJFry::D0v4(i,j,k,l,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fE0v0(double p1,  double p2,  double p3,  double p4,  double p5,
           double s12, double s23, double s34, double s45, double s15,
           double m1,  double m2,  double m3,  double m4,  double m5, int ep) {
  complex<double> result = PJFry::E0v0(p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3,m4,m5,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fE0v1(int i,
           double p1,  double p2,  double p3,  double p4,  double p5,
           double s12, double s23, double s34, double s45, double s15,
           double m1,  double m2,  double m3,  double m4,  double m5, int ep) {
  complex<double> result = PJFry::E0v1(i,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3,m4,m5,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fE0v2(int i, int j,
           double p1,  double p2,  double p3,  double p4,  double p5,
           double s12, double s23, double s34, double s45, double s15,
           double m1,  double m2,  double m3,  double m4,  double m5, int ep) {
  complex<double> result = PJFry::E0v2(i,j,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3,m4,m5,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fE0v3(int i, int j, int k,
           double p1,  double p2,  double p3,  double p4,  double p5,
           double s12, double s23, double s34, double s45, double s15,
           double m1,  double m2,  double m3,  double m4,  double m5, int ep) {
  complex<double> result = PJFry::E0v3(i,j,k,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3,m4,m5,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fE0v4(int i, int j, int k, int l,
           double p1,  double p2,  double p3,  double p4,  double p5,
           double s12, double s23, double s34, double s45, double s15,
           double m1,  double m2,  double m3,  double m4,  double m5, int ep) {
  complex<double> result = PJFry::E0v4(i,j,k,l,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3,m4,m5,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fE0v5(int i, int j, int k, int l, int m,
           double p1,  double p2,  double p3,  double p4,  double p5,
           double s12, double s23, double s34, double s45, double s15,
           double m1,  double m2,  double m3,  double m4,  double m5, int ep) {
  complex<double> result = PJFry::E0v5(i,j,k,l,m,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3,m4,m5,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}


void fF0v0(double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v0(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fF0v1(int i,
           double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v1(i,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fF0v2(int i, int j,
           double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v2(i,j,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fF0v3(int i, int j, int k,
           double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v3(i,j,k,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fF0v4(int i, int j, int k, int l,
           double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v4(i,j,k,l,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fF0v5(int i, int j, int k, int l, int m,
           double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v5(i,j,k,l,m,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

void fF0v6(int i, int j, int k, int l, int m, int n,
           double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
           double s12, double s23, double s34, double s45, double s56, double s16,
           double s234, double s345, double s456,
           double m1,  double m2,  double m3,  double m4,  double m5, double m6, int ep) {
  complex<double> result = PJFry::F0v6(i,j,k,l,m,n,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep);
  MLPutFunction(stdlink, "Complex", 2);
  MLPutReal64(stdlink, result.real());
  MLPutReal64(stdlink, result.imag());
}

// ====================================================================

// extern "C" void rrinit_();
int main(int argc, char* argv[]) {

  return MLMain(argc, argv);
}
# line 368 "PJFry.cpp"


void fClearCache P(( void));

#if MLPROTOTYPES
static int _tr0( MLINK mlp)
#else
static int _tr0(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	if ( ! MLNewPacket(mlp) ) goto L0;
	if( !mlp) return res; /* avoid unused parameter warning */

	fClearCache();

	res = 1;

L0:	return res;
} /* _tr0 */


double fGetMu2 P(( void));

#if MLPROTOTYPES
static int _tr1( MLINK mlp)
#else
static int _tr1(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp0;
	if ( ! MLNewPacket(mlp) ) goto L0;

	_tp0 = fGetMu2();

	res = MLAbort ?
		MLPutFunction( mlp, "Abort", 0) : MLPutReal64( mlp, _tp0);

L0:	return res;
} /* _tr1 */


double fSetMu2 P(( double _tp1));

#if MLPROTOTYPES
static int _tr2( MLINK mlp)
#else
static int _tr2(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp0;
	double _tp1;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLNewPacket(mlp) ) goto L1;

	_tp0 = fSetMu2(_tp1);

	res = MLAbort ?
		MLPutFunction( mlp, "Abort", 0) : MLPutReal64( mlp, _tp0);
L1: 
L0:	return res;
} /* _tr2 */


void fA0v0 P(( double _tp1, int _tp2));

#if MLPROTOTYPES
static int _tr3( MLINK mlp)
#else
static int _tr3(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp1;
	int _tp2;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLNewPacket(mlp) ) goto L2;

	fA0v0(_tp1, _tp2);

	res = 1;
L2: L1: 
L0:	return res;
} /* _tr3 */


void fB0v0 P(( double _tp1, double _tp2, double _tp3, int _tp4));

#if MLPROTOTYPES
static int _tr4( MLINK mlp)
#else
static int _tr4(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp1;
	double _tp2;
	double _tp3;
	int _tp4;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLNewPacket(mlp) ) goto L4;

	fB0v0(_tp1, _tp2, _tp3, _tp4);

	res = 1;
L4: L3: L2: L1: 
L0:	return res;
} /* _tr4 */


void fB0v1 P(( int _tp1, double _tp2, double _tp3, double _tp4, int _tp5));

#if MLPROTOTYPES
static int _tr5( MLINK mlp)
#else
static int _tr5(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	int _tp5;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetInteger( mlp, &_tp5) ) goto L4;
	if ( ! MLNewPacket(mlp) ) goto L5;

	fB0v1(_tp1, _tp2, _tp3, _tp4, _tp5);

	res = 1;
L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr5 */


void fB0v2 P(( int _tp1, int _tp2, double _tp3, double _tp4, double _tp5, int _tp6));

#if MLPROTOTYPES
static int _tr6( MLINK mlp)
#else
static int _tr6(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	int _tp6;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetInteger( mlp, &_tp6) ) goto L5;
	if ( ! MLNewPacket(mlp) ) goto L6;

	fB0v2(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6);

	res = 1;
L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr6 */


void fC0v0 P(( double _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, int _tp7));

#if MLPROTOTYPES
static int _tr7( MLINK mlp)
#else
static int _tr7(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	int _tp7;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetInteger( mlp, &_tp7) ) goto L6;
	if ( ! MLNewPacket(mlp) ) goto L7;

	fC0v0(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7);

	res = 1;
L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr7 */


void fC0v1 P(( int _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, int _tp8));

#if MLPROTOTYPES
static int _tr8( MLINK mlp)
#else
static int _tr8(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	int _tp8;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetInteger( mlp, &_tp8) ) goto L7;
	if ( ! MLNewPacket(mlp) ) goto L8;

	fC0v1(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8);

	res = 1;
L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr8 */


void fC0v2 P(( int _tp1, int _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, int _tp9));

#if MLPROTOTYPES
static int _tr9( MLINK mlp)
#else
static int _tr9(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	int _tp9;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetInteger( mlp, &_tp9) ) goto L8;
	if ( ! MLNewPacket(mlp) ) goto L9;

	fC0v2(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9);

	res = 1;
L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr9 */


void fC0v3 P(( int _tp1, int _tp2, int _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, int _tp10));

#if MLPROTOTYPES
static int _tr10( MLINK mlp)
#else
static int _tr10(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	int _tp10;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetInteger( mlp, &_tp10) ) goto L9;
	if ( ! MLNewPacket(mlp) ) goto L10;

	fC0v3(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10);

	res = 1;
L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr10 */


void fD0v0 P(( double _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, int _tp11));

#if MLPROTOTYPES
static int _tr11( MLINK mlp)
#else
static int _tr11(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	int _tp11;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetInteger( mlp, &_tp11) ) goto L10;
	if ( ! MLNewPacket(mlp) ) goto L11;

	fD0v0(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11);

	res = 1;
L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr11 */


void fD0v1 P(( int _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, int _tp12));

#if MLPROTOTYPES
static int _tr12( MLINK mlp)
#else
static int _tr12(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	int _tp12;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetInteger( mlp, &_tp12) ) goto L11;
	if ( ! MLNewPacket(mlp) ) goto L12;

	fD0v1(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12);

	res = 1;
L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr12 */


void fD0v2 P(( int _tp1, int _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, int _tp13));

#if MLPROTOTYPES
static int _tr13( MLINK mlp)
#else
static int _tr13(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	int _tp13;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetInteger( mlp, &_tp13) ) goto L12;
	if ( ! MLNewPacket(mlp) ) goto L13;

	fD0v2(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13);

	res = 1;
L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr13 */


void fD0v3 P(( int _tp1, int _tp2, int _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, int _tp14));

#if MLPROTOTYPES
static int _tr14( MLINK mlp)
#else
static int _tr14(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	int _tp14;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetInteger( mlp, &_tp14) ) goto L13;
	if ( ! MLNewPacket(mlp) ) goto L14;

	fD0v3(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14);

	res = 1;
L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr14 */


void fD0v4 P(( int _tp1, int _tp2, int _tp3, int _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, int _tp15));

#if MLPROTOTYPES
static int _tr15( MLINK mlp)
#else
static int _tr15(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	int _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	int _tp15;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetInteger( mlp, &_tp15) ) goto L14;
	if ( ! MLNewPacket(mlp) ) goto L15;

	fD0v4(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15);

	res = 1;
L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr15 */


void fE0v0 P(( double _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, int _tp16));

#if MLPROTOTYPES
static int _tr16( MLINK mlp)
#else
static int _tr16(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	int _tp16;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetInteger( mlp, &_tp16) ) goto L15;
	if ( ! MLNewPacket(mlp) ) goto L16;

	fE0v0(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16);

	res = 1;
L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr16 */


void fE0v1 P(( int _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, int _tp17));

#if MLPROTOTYPES
static int _tr17( MLINK mlp)
#else
static int _tr17(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	int _tp17;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetInteger( mlp, &_tp17) ) goto L16;
	if ( ! MLNewPacket(mlp) ) goto L17;

	fE0v1(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17);

	res = 1;
L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr17 */


void fE0v2 P(( int _tp1, int _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, int _tp18));

#if MLPROTOTYPES
static int _tr18( MLINK mlp)
#else
static int _tr18(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	int _tp18;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetInteger( mlp, &_tp18) ) goto L17;
	if ( ! MLNewPacket(mlp) ) goto L18;

	fE0v2(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18);

	res = 1;
L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr18 */


void fE0v3 P(( int _tp1, int _tp2, int _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, int _tp19));

#if MLPROTOTYPES
static int _tr19( MLINK mlp)
#else
static int _tr19(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	int _tp19;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetInteger( mlp, &_tp19) ) goto L18;
	if ( ! MLNewPacket(mlp) ) goto L19;

	fE0v3(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19);

	res = 1;
L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr19 */


void fE0v4 P(( int _tp1, int _tp2, int _tp3, int _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, int _tp20));

#if MLPROTOTYPES
static int _tr20( MLINK mlp)
#else
static int _tr20(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	int _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	int _tp20;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetInteger( mlp, &_tp20) ) goto L19;
	if ( ! MLNewPacket(mlp) ) goto L20;

	fE0v4(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20);

	res = 1;
L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr20 */


void fE0v5 P(( int _tp1, int _tp2, int _tp3, int _tp4, int _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, int _tp21));

#if MLPROTOTYPES
static int _tr21( MLINK mlp)
#else
static int _tr21(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	int _tp4;
	int _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	int _tp21;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLGetInteger( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetInteger( mlp, &_tp21) ) goto L20;
	if ( ! MLNewPacket(mlp) ) goto L21;

	fE0v5(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21);

	res = 1;
L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr21 */


void fF0v0 P(( double _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, int _tp22));

#if MLPROTOTYPES
static int _tr22( MLINK mlp)
#else
static int _tr22(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	double _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	int _tp22;
	if ( ! MLGetReal64( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetInteger( mlp, &_tp22) ) goto L21;
	if ( ! MLNewPacket(mlp) ) goto L22;

	fF0v0(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22);

	res = 1;
L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr22 */


void fF0v1 P(( int _tp1, double _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, double _tp22, int _tp23));

#if MLPROTOTYPES
static int _tr23( MLINK mlp)
#else
static int _tr23(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	double _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	double _tp22;
	int _tp23;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetReal64( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetReal64( mlp, &_tp22) ) goto L21;
	if ( ! MLGetInteger( mlp, &_tp23) ) goto L22;
	if ( ! MLNewPacket(mlp) ) goto L23;

	fF0v1(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22, _tp23);

	res = 1;
L23: L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr23 */


void fF0v2 P(( int _tp1, int _tp2, double _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, double _tp22, double _tp23, int _tp24));

#if MLPROTOTYPES
static int _tr24( MLINK mlp)
#else
static int _tr24(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	double _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	double _tp22;
	double _tp23;
	int _tp24;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetReal64( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetReal64( mlp, &_tp22) ) goto L21;
	if ( ! MLGetReal64( mlp, &_tp23) ) goto L22;
	if ( ! MLGetInteger( mlp, &_tp24) ) goto L23;
	if ( ! MLNewPacket(mlp) ) goto L24;

	fF0v2(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22, _tp23, _tp24);

	res = 1;
L24: L23: L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr24 */


void fF0v3 P(( int _tp1, int _tp2, int _tp3, double _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, double _tp22, double _tp23, double _tp24, int _tp25));

#if MLPROTOTYPES
static int _tr25( MLINK mlp)
#else
static int _tr25(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	double _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	double _tp22;
	double _tp23;
	double _tp24;
	int _tp25;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetReal64( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetReal64( mlp, &_tp22) ) goto L21;
	if ( ! MLGetReal64( mlp, &_tp23) ) goto L22;
	if ( ! MLGetReal64( mlp, &_tp24) ) goto L23;
	if ( ! MLGetInteger( mlp, &_tp25) ) goto L24;
	if ( ! MLNewPacket(mlp) ) goto L25;

	fF0v3(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22, _tp23, _tp24, _tp25);

	res = 1;
L25: L24: L23: L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr25 */


void fF0v4 P(( int _tp1, int _tp2, int _tp3, int _tp4, double _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, double _tp22, double _tp23, double _tp24, double _tp25, int _tp26));

#if MLPROTOTYPES
static int _tr26( MLINK mlp)
#else
static int _tr26(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	int _tp4;
	double _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	double _tp22;
	double _tp23;
	double _tp24;
	double _tp25;
	int _tp26;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLGetReal64( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetReal64( mlp, &_tp22) ) goto L21;
	if ( ! MLGetReal64( mlp, &_tp23) ) goto L22;
	if ( ! MLGetReal64( mlp, &_tp24) ) goto L23;
	if ( ! MLGetReal64( mlp, &_tp25) ) goto L24;
	if ( ! MLGetInteger( mlp, &_tp26) ) goto L25;
	if ( ! MLNewPacket(mlp) ) goto L26;

	fF0v4(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22, _tp23, _tp24, _tp25, _tp26);

	res = 1;
L26: L25: L24: L23: L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr26 */


void fF0v5 P(( int _tp1, int _tp2, int _tp3, int _tp4, int _tp5, double _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, double _tp22, double _tp23, double _tp24, double _tp25, double _tp26, int _tp27));

#if MLPROTOTYPES
static int _tr27( MLINK mlp)
#else
static int _tr27(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	int _tp4;
	int _tp5;
	double _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	double _tp22;
	double _tp23;
	double _tp24;
	double _tp25;
	double _tp26;
	int _tp27;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLGetInteger( mlp, &_tp5) ) goto L4;
	if ( ! MLGetReal64( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetReal64( mlp, &_tp22) ) goto L21;
	if ( ! MLGetReal64( mlp, &_tp23) ) goto L22;
	if ( ! MLGetReal64( mlp, &_tp24) ) goto L23;
	if ( ! MLGetReal64( mlp, &_tp25) ) goto L24;
	if ( ! MLGetReal64( mlp, &_tp26) ) goto L25;
	if ( ! MLGetInteger( mlp, &_tp27) ) goto L26;
	if ( ! MLNewPacket(mlp) ) goto L27;

	fF0v5(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22, _tp23, _tp24, _tp25, _tp26, _tp27);

	res = 1;
L27: L26: L25: L24: L23: L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr27 */


void fF0v6 P(( int _tp1, int _tp2, int _tp3, int _tp4, int _tp5, int _tp6, double _tp7, double _tp8, double _tp9, double _tp10, double _tp11, double _tp12, double _tp13, double _tp14, double _tp15, double _tp16, double _tp17, double _tp18, double _tp19, double _tp20, double _tp21, double _tp22, double _tp23, double _tp24, double _tp25, double _tp26, double _tp27, int _tp28));

#if MLPROTOTYPES
static int _tr28( MLINK mlp)
#else
static int _tr28(mlp) MLINK mlp;
#endif
{
	int	res = 0;
	int _tp1;
	int _tp2;
	int _tp3;
	int _tp4;
	int _tp5;
	int _tp6;
	double _tp7;
	double _tp8;
	double _tp9;
	double _tp10;
	double _tp11;
	double _tp12;
	double _tp13;
	double _tp14;
	double _tp15;
	double _tp16;
	double _tp17;
	double _tp18;
	double _tp19;
	double _tp20;
	double _tp21;
	double _tp22;
	double _tp23;
	double _tp24;
	double _tp25;
	double _tp26;
	double _tp27;
	int _tp28;
	if ( ! MLGetInteger( mlp, &_tp1) ) goto L0;
	if ( ! MLGetInteger( mlp, &_tp2) ) goto L1;
	if ( ! MLGetInteger( mlp, &_tp3) ) goto L2;
	if ( ! MLGetInteger( mlp, &_tp4) ) goto L3;
	if ( ! MLGetInteger( mlp, &_tp5) ) goto L4;
	if ( ! MLGetInteger( mlp, &_tp6) ) goto L5;
	if ( ! MLGetReal64( mlp, &_tp7) ) goto L6;
	if ( ! MLGetReal64( mlp, &_tp8) ) goto L7;
	if ( ! MLGetReal64( mlp, &_tp9) ) goto L8;
	if ( ! MLGetReal64( mlp, &_tp10) ) goto L9;
	if ( ! MLGetReal64( mlp, &_tp11) ) goto L10;
	if ( ! MLGetReal64( mlp, &_tp12) ) goto L11;
	if ( ! MLGetReal64( mlp, &_tp13) ) goto L12;
	if ( ! MLGetReal64( mlp, &_tp14) ) goto L13;
	if ( ! MLGetReal64( mlp, &_tp15) ) goto L14;
	if ( ! MLGetReal64( mlp, &_tp16) ) goto L15;
	if ( ! MLGetReal64( mlp, &_tp17) ) goto L16;
	if ( ! MLGetReal64( mlp, &_tp18) ) goto L17;
	if ( ! MLGetReal64( mlp, &_tp19) ) goto L18;
	if ( ! MLGetReal64( mlp, &_tp20) ) goto L19;
	if ( ! MLGetReal64( mlp, &_tp21) ) goto L20;
	if ( ! MLGetReal64( mlp, &_tp22) ) goto L21;
	if ( ! MLGetReal64( mlp, &_tp23) ) goto L22;
	if ( ! MLGetReal64( mlp, &_tp24) ) goto L23;
	if ( ! MLGetReal64( mlp, &_tp25) ) goto L24;
	if ( ! MLGetReal64( mlp, &_tp26) ) goto L25;
	if ( ! MLGetReal64( mlp, &_tp27) ) goto L26;
	if ( ! MLGetInteger( mlp, &_tp28) ) goto L27;
	if ( ! MLNewPacket(mlp) ) goto L28;

	fF0v6(_tp1, _tp2, _tp3, _tp4, _tp5, _tp6, _tp7, _tp8, _tp9, _tp10, _tp11, _tp12, _tp13, _tp14, _tp15, _tp16, _tp17, _tp18, _tp19, _tp20, _tp21, _tp22, _tp23, _tp24, _tp25, _tp26, _tp27, _tp28);

	res = 1;
L28: L27: L26: L25: L24: L23: L22: L21: L20: L19: L18: L17: L16: L15: L14: L13: L12: L11: L10: L9: L8: L7: L6: L5: L4: L3: L2: L1: 
L0:	return res;
} /* _tr28 */


static struct func {
	int   f_nargs;
	int   manual;
	int   (*f_func)P((MLINK));
	const char  *f_name;
	} _tramps[29] = {
		{ 0, 0, _tr0, "fClearCache" },
		{ 0, 0, _tr1, "fGetMu2" },
		{ 1, 0, _tr2, "fSetMu2" },
		{ 2, 0, _tr3, "fA0v0" },
		{ 4, 0, _tr4, "fB0v0" },
		{ 5, 0, _tr5, "fB0v1" },
		{ 6, 0, _tr6, "fB0v2" },
		{ 7, 0, _tr7, "fC0v0" },
		{ 8, 0, _tr8, "fC0v1" },
		{ 9, 0, _tr9, "fC0v2" },
		{10, 0, _tr10, "fC0v3" },
		{11, 0, _tr11, "fD0v0" },
		{12, 0, _tr12, "fD0v1" },
		{13, 0, _tr13, "fD0v2" },
		{14, 0, _tr14, "fD0v3" },
		{15, 0, _tr15, "fD0v4" },
		{16, 0, _tr16, "fE0v0" },
		{17, 0, _tr17, "fE0v1" },
		{18, 0, _tr18, "fE0v2" },
		{19, 0, _tr19, "fE0v3" },
		{20, 0, _tr20, "fE0v4" },
		{21, 0, _tr21, "fE0v5" },
		{22, 0, _tr22, "fF0v0" },
		{23, 0, _tr23, "fF0v1" },
		{24, 0, _tr24, "fF0v2" },
		{25, 0, _tr25, "fF0v3" },
		{26, 0, _tr26, "fF0v4" },
		{27, 0, _tr27, "fF0v5" },
		{28, 0, _tr28, "fF0v6" }
		};

static const char* evalstrs[] = {
	"Print[\"PJFry MathLink\"];",
	(const char*)0,
	"Print[\"Type Names[\\\"PJFry`*\\\"] to show exported names\"];",
	(const char*)0,
	"BeginPackage[\"PJFry`\"]",
	(const char*)0,
	"GetMu2::usage = \"GetMu2[] returns the renormalization scale squa",
	"red\"",
	(const char*)0,
	"SetMu2::usage = \"SetMu2[mu^2] sets the renormalization scale squ",
	"ared\"",
	(const char*)0,
	"ClearCache::usage = \"ClearCache[] clears internal caches\"",
	(const char*)0,
	"A0v0::usage  = \"A0v0[m1,ep=0]\"",
	(const char*)0,
	"B0v0::usage  = \"B0v0[p1,m1,m2,ep=0]\"",
	(const char*)0,
	"B0v1::usage  = \"B0v1[i,p1,m1,m2,ep=0]\"",
	(const char*)0,
	"B0v2::usage  = \"B0v2[i,j,p1,m1,m2,ep=0]\"",
	(const char*)0,
	"C0v0::usage  = \"C0v0[p1,p2,p3,m1,m2,m3,ep=0]\"",
	(const char*)0,
	"C0v1::usage  = \"C0v1[i,p1,p2,p3,m1,m2,m3,ep=0]\"",
	(const char*)0,
	"C0v2::usage  = \"C0v2[i,j,p1,p2,p3,m1,m2,m3,ep=0]\"",
	(const char*)0,
	"C0v3::usage  = \"C0v3[i,j,k,p1,p2,p3,m1,m2,m3,ep=0]\"",
	(const char*)0,
	"D0v0::usage  = \"D0v0[p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep=0]\"",
	(const char*)0,
	"D0v1::usage  = \"D0v1[i,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep=0]\"",
	(const char*)0,
	"D0v2::usage  = \"D0v2[i,j,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep=0]\"",
	(const char*)0,
	"D0v3::usage  = \"D0v3[i,j,k,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep=0]",
	"\"",
	(const char*)0,
	"D0v4::usage  = \"D0v4[i,j,k,l,p1,p2,p3,p4,s12,s23,m1,m2,m3,m4,ep=",
	"0]\"",
	(const char*)0,
	"E0v0::usage  = \"E0v0[p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,m3",
	",m4,m5,ep=0]\"",
	(const char*)0,
	"E0v1::usage  = \"E0v1[i,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m2,",
	"m3,m4,m5,ep=0]\"",
	(const char*)0,
	"E0v2::usage  = \"E0v2[i,j,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1,m",
	"2,m3,m4,m5,ep=0]\"",
	(const char*)0,
	"E0v3::usage  = \"E0v3[i,j,k,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,m1",
	",m2,m3,m4,m5,ep=0]\"",
	(const char*)0,
	"E0v4::usage  = \"E0v4[i,j,k,l,p1,p2,p3,p4,p5,s12,s23,s34,s45,s15,",
	"m1,m2,m3,m4,m5,ep=0]\"",
	(const char*)0,
	"E0v5::usage  = \"E0v5[i,j,k,l,m,p1,p2,p3,p4,p5,s12,s23,s34,s45,s1",
	"5,m1,m2,m3,m4,m5,ep=0]\"",
	(const char*)0,
	"F0v0::usage  = \"F0v0[p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s",
	"234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"F0v1::usage  = \"F0v1[i,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16",
	",s234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"F0v2::usage  = \"F0v2[i,j,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s",
	"16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"F0v3::usage  = \"F0v3[i,j,k,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56",
	",s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"F0v4::usage  = \"F0v4[i,j,k,l,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s",
	"56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"F0v5::usage  = \"F0v5[i,j,k,l,m,p1,p2,p3,p4,p5,p6,s12,s23,s34,s45",
	",s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"F0v6::usage  = \"F0v6[i,j,k,l,m,n,p1,p2,p3,p4,p5,p6,s12,s23,s34,s",
	"45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6,ep=0]\"",
	(const char*)0,
	"Begin[\"`Private`\"]",
	(const char*)0,
	"SetAttributes[GetMu2, NumericFunction]",
	(const char*)0,
	"SetAttributes[SetMu2, NumericFunction]",
	(const char*)0,
	"SetAttributes[A0v0, NumericFunction]",
	(const char*)0,
	"SetAttributes[B0v0, NumericFunction]",
	(const char*)0,
	"SetAttributes[B0v1, NumericFunction]",
	(const char*)0,
	"SetAttributes[B0v2, NumericFunction]",
	(const char*)0,
	"SetAttributes[C0v0, NumericFunction]",
	(const char*)0,
	"SetAttributes[C0v1, NumericFunction]",
	(const char*)0,
	"SetAttributes[C0v2, NumericFunction]",
	(const char*)0,
	"SetAttributes[C0v3, NumericFunction]",
	(const char*)0,
	"SetAttributes[D0v0, NumericFunction]",
	(const char*)0,
	"SetAttributes[D0v1, NumericFunction]",
	(const char*)0,
	"SetAttributes[D0v2, NumericFunction]",
	(const char*)0,
	"SetAttributes[D0v3, NumericFunction]",
	(const char*)0,
	"SetAttributes[D0v4, NumericFunction]",
	(const char*)0,
	"SetAttributes[E0v0, NumericFunction]",
	(const char*)0,
	"SetAttributes[E0v1, NumericFunction]",
	(const char*)0,
	"SetAttributes[E0v2, NumericFunction]",
	(const char*)0,
	"SetAttributes[E0v3, NumericFunction]",
	(const char*)0,
	"SetAttributes[E0v4, NumericFunction]",
	(const char*)0,
	"SetAttributes[E0v5, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v0, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v1, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v2, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v3, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v4, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v5, NumericFunction]",
	(const char*)0,
	"SetAttributes[F0v6, NumericFunction]",
	(const char*)0,
	"End[]",
	(const char*)0,
	"EndPackage[]",
	(const char*)0,
	(const char*)0
};
#define CARDOF_EVALSTRS 63

static int _definepattern P(( MLINK, char*, char*, int));

static int _doevalstr P(( MLINK, int));

int  _MLDoCallPacket P(( MLINK, struct func[], int));


#if MLPROTOTYPES
int MLInstall( MLINK mlp)
#else
int MLInstall(mlp) MLINK mlp;
#endif
{
	int _res;
	_res = MLConnect(mlp);
	if (_res) _res = _doevalstr( mlp, 0);
	if (_res) _res = _doevalstr( mlp, 1);
	if (_res) _res = _doevalstr( mlp, 2);
	if (_res) _res = _doevalstr( mlp, 3);
	if (_res) _res = _doevalstr( mlp, 4);
	if (_res) _res = _doevalstr( mlp, 5);
	if (_res) _res = _doevalstr( mlp, 6);
	if (_res) _res = _doevalstr( mlp, 7);
	if (_res) _res = _doevalstr( mlp, 8);
	if (_res) _res = _doevalstr( mlp, 9);
	if (_res) _res = _doevalstr( mlp, 10);
	if (_res) _res = _doevalstr( mlp, 11);
	if (_res) _res = _doevalstr( mlp, 12);
	if (_res) _res = _doevalstr( mlp, 13);
	if (_res) _res = _doevalstr( mlp, 14);
	if (_res) _res = _doevalstr( mlp, 15);
	if (_res) _res = _doevalstr( mlp, 16);
	if (_res) _res = _doevalstr( mlp, 17);
	if (_res) _res = _doevalstr( mlp, 18);
	if (_res) _res = _doevalstr( mlp, 19);
	if (_res) _res = _doevalstr( mlp, 20);
	if (_res) _res = _doevalstr( mlp, 21);
	if (_res) _res = _doevalstr( mlp, 22);
	if (_res) _res = _doevalstr( mlp, 23);
	if (_res) _res = _doevalstr( mlp, 24);
	if (_res) _res = _doevalstr( mlp, 25);
	if (_res) _res = _doevalstr( mlp, 26);
	if (_res) _res = _doevalstr( mlp, 27);
	if (_res) _res = _doevalstr( mlp, 28);
	if (_res) _res = _doevalstr( mlp, 29);
	if (_res) _res = _doevalstr( mlp, 30);
	if (_res) _res = _doevalstr( mlp, 31);
	if (_res) _res = _doevalstr( mlp, 32);
	if (_res) _res = _doevalstr( mlp, 33);
	if (_res) _res = _doevalstr( mlp, 34);
	if (_res) _res = _doevalstr( mlp, 35);
	if (_res) _res = _doevalstr( mlp, 36);
	if (_res) _res = _doevalstr( mlp, 37);
	if (_res) _res = _doevalstr( mlp, 38);
	if (_res) _res = _doevalstr( mlp, 39);
	if (_res) _res = _doevalstr( mlp, 40);
	if (_res) _res = _doevalstr( mlp, 41);
	if (_res) _res = _doevalstr( mlp, 42);
	if (_res) _res = _doevalstr( mlp, 43);
	if (_res) _res = _doevalstr( mlp, 44);
	if (_res) _res = _doevalstr( mlp, 45);
	if (_res) _res = _doevalstr( mlp, 46);
	if (_res) _res = _doevalstr( mlp, 47);
	if (_res) _res = _doevalstr( mlp, 48);
	if (_res) _res = _doevalstr( mlp, 49);
	if (_res) _res = _doevalstr( mlp, 50);
	if (_res) _res = _doevalstr( mlp, 51);
	if (_res) _res = _doevalstr( mlp, 52);
	if (_res) _res = _doevalstr( mlp, 53);
	if (_res) _res = _doevalstr( mlp, 54);
	if (_res) _res = _doevalstr( mlp, 55);
	if (_res) _res = _doevalstr( mlp, 56);
	if (_res) _res = _doevalstr( mlp, 57);
	if (_res) _res = _doevalstr( mlp, 58);
	if (_res) _res = _doevalstr( mlp, 59);
	if (_res) _res = _doevalstr( mlp, 60);
	if (_res) _res = _definepattern(mlp, (char *)"ClearCache[]", (char *)"{}", 0);
	if (_res) _res = _definepattern(mlp, (char *)"GetMu2[]", (char *)"{}", 1);
	if (_res) _res = _definepattern(mlp, (char *)"SetMu2[mu2_?NumericQ]", (char *)"{N[mu2]}", 2);
	if (_res) _res = _definepattern(mlp, (char *)"A0v0[m1_?NumericQ,ep_Integer:0]", (char *)"{N[m1],ep}", 3);
	if (_res) _res = _definepattern(mlp, (char *)"B0v0[p1_?NumericQ,m1_?NumericQ,m2_?NumericQ,ep_Integer:0]", (char *)"{N[p1],N[m1],N[m2],ep}", 4);
	if (_res) _res = _definepattern(mlp, (char *)"B0v1[i_Integer,p1_?NumericQ,m1_?NumericQ,m2_?NumericQ,ep_Integer:0]", (char *)"{i,N[p1],N[m1],N[m2],ep}", 5);
	if (_res) _res = _definepattern(mlp, (char *)"B0v2[i_Integer,j_Integer,p1_?NumericQ,m1_?NumericQ,m2_?NumericQ,ep_Integer:0]", (char *)"{i,j,N[p1],N[m1],N[m2],ep}", 6);
	if (_res) _res = _definepattern(mlp, (char *)"C0v0[p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,ep_Integer:0]", (char *)"{N[p1],N[p2],N[p3],N[m1],N[m2],N[m3],ep}", 7);
	if (_res) _res = _definepattern(mlp, (char *)"C0v1[i_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,ep_Integer:0]", (char *)"{i,N[p1],N[p2],N[p3],N[m1],N[m2],N[m3],ep}", 8);
	if (_res) _res = _definepattern(mlp, (char *)"C0v2[i_Integer,j_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,ep_Integer:0]", (char *)"{i,j,N[p1],N[p2],N[p3],N[m1],N[m2],N[m3],ep}", 9);
	if (_res) _res = _definepattern(mlp, (char *)"C0v3[i_Integer,j_Integer,k_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,N[p1],N[p2],N[p3],N[m1],N[m2],N[m3],ep}", 10);
	if (_res) _res = _definepattern(mlp, (char *)"D0v0[p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,s12_?NumericQ,s23_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,ep_Integer:0]", (char *)"{N[p1],N[p2],N[p3],N[p4],N[s12],N[s23],N[m1],N[m2],N[m3],N[m4],ep}", 11);
	if (_res) _res = _definepattern(mlp, (char *)"D0v1[i_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,s12_?NumericQ,s23_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,ep_Integer:0]", (char *)"{i,N[p1],N[p2],N[p3],N[p4],N[s12],N[s23],N[m1],N[m2],N[m3],N[m4],ep}", 12);
	if (_res) _res = _definepattern(mlp, (char *)"D0v2[i_Integer,j_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,s12_?NumericQ,s23_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,ep_Integer:0]", (char *)"{i,j,N[p1],N[p2],N[p3],N[p4],N[s12],N[s23],N[m1],N[m2],N[m3],N[m4],ep}", 13);
	if (_res) _res = _definepattern(mlp, (char *)"D0v3[i_Integer,j_Integer,k_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,s12_?NumericQ,s23_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,N[p1],N[p2],N[p3],N[p4],N[s12],N[s23],N[m1],N[m2],N[m3],N[m4],ep}", 14);
	if (_res) _res = _definepattern(mlp, (char *)"D0v4[i_Integer,j_Integer,k_Integer,l_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,s12_?NumericQ,s23_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,l,N[p1],N[p2],N[p3],N[p4],N[s12],N[s23],N[m1],N[m2],N[m3],N[m4],ep}", 15);
	if (_res) _res = _definepattern(mlp, (char *)"E0v0[p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s15_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,ep_Integer:0]", (char *)"{N[p1],N[p2],N[p3],N[p4],N[p5],N[s12],N[s23],N[s34],N[s45],N[s15],N[m1],N[m2],N[m3],N[m4],N[m5],ep}", 16);
	if (_res) _res = _definepattern(mlp, (char *)"E0v1[i_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s15_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,ep_Integer:0]", (char *)"{i,N[p1],N[p2],N[p3],N[p4],N[p5],N[s12],N[s23],N[s34],N[s45],N[s15],N[m1],N[m2],N[m3],N[m4],N[m5],ep}", 17);
	if (_res) _res = _definepattern(mlp, (char *)"E0v2[i_Integer,j_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s15_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,ep_Integer:0]", (char *)"{i,j,N[p1],N[p2],N[p3],N[p4],N[p5],N[s12],N[s23],N[s34],N[s45],N[s15],N[m1],N[m2],N[m3],N[m4],N[m5],ep}", 18);
	if (_res) _res = _definepattern(mlp, (char *)"E0v3[i_Integer,j_Integer,k_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s15_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,N[p1],N[p2],N[p3],N[p4],N[p5],N[s12],N[s23],N[s34],N[s45],N[s15],N[m1],N[m2],N[m3],N[m4],N[m5],ep}", 19);
	if (_res) _res = _definepattern(mlp, (char *)"E0v4[i_Integer,j_Integer,k_Integer,l_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s15_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,l,N[p1],N[p2],N[p3],N[p4],N[p5],N[s12],N[s23],N[s34],N[s45],N[s15],N[m1],N[m2],N[m3],N[m4],N[m5],ep}", 20);
	if (_res) _res = _definepattern(mlp, (char *)"E0v5[i_Integer,j_Integer,k_Integer,l_Integer,m_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s15_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,l,m,N[p1],N[p2],N[p3],N[p4],N[p5],N[s12],N[s23],N[s34],N[s45],N[s15],N[m1],N[m2],N[m3],N[m4],N[m5],ep}", 21);
	if (_res) _res = _definepattern(mlp, (char *)"F0v0[p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 22);
	if (_res) _res = _definepattern(mlp, (char *)"F0v1[i_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{i,N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 23);
	if (_res) _res = _definepattern(mlp, (char *)"F0v2[i_Integer,j_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{i,j,N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 24);
	if (_res) _res = _definepattern(mlp, (char *)"F0v3[i_Integer,j_Integer,k_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 25);
	if (_res) _res = _definepattern(mlp, (char *)"F0v4[i_Integer,j_Integer,k_Integer,l_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,l,N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 26);
	if (_res) _res = _definepattern(mlp, (char *)"F0v5[i_Integer,j_Integer,k_Integer,l_Integer,m_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,l,m,N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 27);
	if (_res) _res = _definepattern(mlp, (char *)"F0v6[i_Integer,j_Integer,k_Integer,l_Integer,m_Integer,n_Integer,p1_?NumericQ,p2_?NumericQ,p3_?NumericQ,p4_?NumericQ,p5_?NumericQ,p6_?NumericQ,s12_?NumericQ,s23_?NumericQ,s34_?NumericQ,s45_?NumericQ,s56_?NumericQ,s16_?NumericQ,s234_?NumericQ,s345_?NumericQ,s456_?NumericQ,m1_?NumericQ,m2_?NumericQ,m3_?NumericQ,m4_?NumericQ,m5_?NumericQ,m6_?NumericQ,ep_Integer:0]", (char *)"{i,j,k,l,m,n,N[p1],N[p2],N[p3],N[p4],N[p5],N[p6],N[s12],N[s23],N[s34],N[s45],N[s56],N[s16],N[s234],N[s345],N[s456],N[m1],N[m2],N[m3],N[m4],N[m5],N[m6],ep}", 28);
	if (_res) _res = _doevalstr( mlp, 61);
	if (_res) _res = _doevalstr( mlp, 62);
	if (_res) _res = MLPutSymbol( mlp, "End");
	if (_res) _res = MLFlush( mlp);
	return _res;
} /* MLInstall */


#if MLPROTOTYPES
int MLDoCallPacket( MLINK mlp)
#else
int MLDoCallPacket( mlp) MLINK mlp;
#endif
{
	return _MLDoCallPacket( mlp, _tramps, 29);
} /* MLDoCallPacket */

/******************************* begin trailer ********************************/

#ifndef EVALSTRS_AS_BYTESTRINGS
#	define EVALSTRS_AS_BYTESTRINGS 1
#endif


#if CARDOF_EVALSTRS
#if MLPROTOTYPES
static int  _doevalstr( MLINK mlp, int n)
#else
static int  _doevalstr( mlp, n)
	 MLINK mlp; int n;
#endif
{
	long bytesleft, charsleft, bytesnow;
#if !EVALSTRS_AS_BYTESTRINGS
	long charsnow;
#endif
	char **s, **p;
	char *t;

	s = (char **)evalstrs;
	while( n-- > 0){
		if( *s == 0) break;
		while( *s++ != 0){}
	}
	if( *s == 0) return 0;
	bytesleft = 0;
	charsleft = 0;
	p = s;
	while( *p){
		t = *p; while( *t) ++t;
		bytesnow = t - *p;
		bytesleft += bytesnow;
		charsleft += bytesnow;
#if !EVALSTRS_AS_BYTESTRINGS
		t = *p;
		charsleft -= MLCharacterOffset( &t, t + bytesnow, bytesnow);
		/* assert( t == *p + bytesnow); */
#endif
		++p;
	}


	MLPutNext( mlp, MLTKSTR);
#if EVALSTRS_AS_BYTESTRINGS
	p = s;
	while( *p){
		t = *p; while( *t) ++t;
		bytesnow = t - *p;
		bytesleft -= bytesnow;
		MLPut8BitCharacters( mlp, bytesleft, (unsigned char*)*p, bytesnow);
		++p;
	}
#else
	MLPut7BitCount( mlp, charsleft, bytesleft);
	p = s;
	while( *p){
		t = *p; while( *t) ++t;
		bytesnow = t - *p;
		bytesleft -= bytesnow;
		t = *p;
		charsnow = bytesnow - MLCharacterOffset( &t, t + bytesnow, bytesnow);
		/* assert( t == *p + bytesnow); */
		charsleft -= charsnow;
		MLPut7BitCharacters(  mlp, charsleft, *p, bytesnow, charsnow);
		++p;
	}
#endif
	return MLError( mlp) == MLEOK;
}
#endif /* CARDOF_EVALSTRS */


#if MLPROTOTYPES
static int  _definepattern( MLINK mlp, char *patt, char *args, int func_n)
#else
static int  _definepattern( mlp, patt, args, func_n)
	MLINK  mlp;
	char  *patt, *args;
	int    func_n;
#endif
{
	MLPutFunction( mlp, "DefineExternal", (long)3);
	  MLPutString( mlp, patt);
	  MLPutString( mlp, args);
	  MLPutInteger( mlp, func_n);
	return !MLError(mlp);
} /* _definepattern */


#if MLPROTOTYPES
int _MLDoCallPacket( MLINK mlp, struct func functable[], int nfuncs)
#else
int _MLDoCallPacket( mlp, functable, nfuncs)
	MLINK mlp;
	struct func functable[];
	int nfuncs;
#endif
{
	long len;
	int n, res = 0;
	struct func* funcp;

	if( ! MLGetInteger( mlp, &n) ||  n < 0 ||  n >= nfuncs) goto L0;
	funcp = &functable[n];

	if( funcp->f_nargs >= 0
	&& ( ! MLCheckFunction(mlp, "List", &len)
	     || ( !funcp->manual && (len != funcp->f_nargs))
	     || (  funcp->manual && (len <  funcp->f_nargs))
	   )
	) goto L0;

	stdlink = mlp;
	res = (*funcp->f_func)( mlp);

L0:	if( res == 0)
		res = MLClearError( mlp) && MLPutSymbol( mlp, "$Failed");
	return res && MLEndPacket( mlp) && MLNewPacket( mlp);
} /* _MLDoCallPacket */


#if MLPROTOTYPES
mlapi_packet MLAnswer( MLINK mlp)
#else
mlapi_packet MLAnswer( mlp)
	MLINK mlp;
#endif
{
	mlapi_packet pkt = 0;

	while( !MLDone && !MLError(mlp) && (pkt = MLNextPacket(mlp), pkt) && pkt == CALLPKT){
		MLAbort = 0;
		if( !MLDoCallPacket(mlp)) pkt = 0;
	}
	MLAbort = 0;
	return pkt;
} /* MLAnswer */



/*
	Module[ { me = $ParentLink},
		$ParentLink = contents of RESUMEPKT;
		Message[ MessageName[$ParentLink, "notfe"], me];
		me]
*/

#if MLPROTOTYPES
static int refuse_to_be_a_frontend( MLINK mlp)
#else
static int refuse_to_be_a_frontend( mlp)
	MLINK mlp;
#endif
{
	int pkt;

	MLPutFunction( mlp, "EvaluatePacket", 1);
	  MLPutFunction( mlp, "Module", 2);
	    MLPutFunction( mlp, "List", 1);
		  MLPutFunction( mlp, "Set", 2);
		    MLPutSymbol( mlp, "me");
	        MLPutSymbol( mlp, "$ParentLink");
	  MLPutFunction( mlp, "CompoundExpression", 3);
	    MLPutFunction( mlp, "Set", 2);
	      MLPutSymbol( mlp, "$ParentLink");
	      MLTransferExpression( mlp, mlp);
	    MLPutFunction( mlp, "Message", 2);
	      MLPutFunction( mlp, "MessageName", 2);
	        MLPutSymbol( mlp, "$ParentLink");
	        MLPutString( mlp, "notfe");
	      MLPutSymbol( mlp, "me");
	    MLPutSymbol( mlp, "me");
	MLEndPacket( mlp);

	while( (pkt = MLNextPacket( mlp), pkt) && pkt != SUSPENDPKT)
		MLNewPacket( mlp);
	MLNewPacket( mlp);
	return MLError( mlp) == MLEOK;
}


#if MLPROTOTYPES
#if MLINTERFACE >= 3
int MLEvaluate( MLINK mlp, char *s)
#else
int MLEvaluate( MLINK mlp, charp_ct s)
#endif /* MLINTERFACE >= 3 */
#else
int MLEvaluate( mlp, s)
	MLINK mlp;
#if MLINTERFACE >= 3
	char *s;
#else
	charp_ct s;
#endif /* MLINTERFACE >= 3 */
#endif
{
	if( MLAbort) return 0;
	return MLPutFunction( mlp, "EvaluatePacket", 1L)
		&& MLPutFunction( mlp, "ToExpression", 1L)
		&& MLPutString( mlp, s)
		&& MLEndPacket( mlp);
} /* MLEvaluate */


#if MLPROTOTYPES
#if MLINTERFACE >= 3
int MLEvaluateString( MLINK mlp, char *s)
#else
int MLEvaluateString( MLINK mlp, charp_ct s)
#endif /* MLINTERFACE >= 3 */
#else
int MLEvaluateString( mlp, s)
	MLINK mlp;
#if MLINTERFACE >= 3
	char *s;
#else
	charp_ct s;
#endif /* MLINTERFACE >= 3 */
#endif
{
	int pkt;
	if( MLAbort) return 0;
	if( MLEvaluate( mlp, s)){
		while( (pkt = MLAnswer( mlp), pkt) && pkt != RETURNPKT)
			MLNewPacket( mlp);
		MLNewPacket( mlp);
	}
	return MLError( mlp) == MLEOK;
} /* MLEvaluateString */


#if MLINTERFACE >= 3
#if MLPROTOTYPES
void MLDefaultHandler( MLINK mlp, int message, int n)
#else
void MLDefaultHandler( mlp, message, n)
	MLINK mlp;
	int message, n;
#endif
#else
#if MLPROTOTYPES
void MLDefaultHandler( MLINK mlp, unsigned long message, unsigned long n)
#else
void MLDefaultHandler( mlp, message, n)
	MLINK mlp;
	unsigned long message, n;
#endif
#endif /* MLINTERFACE >= 3 */
{
	switch (message){
	case MLTerminateMessage:
		MLDone = 1;
	case MLInterruptMessage:
	case MLAbortMessage:
		MLAbort = 1;
	default:
		return;
	}
}

#if MLPROTOTYPES
#if MLINTERFACE >= 3
static int _MLMain( char **argv, char **argv_end, char *commandline)
#else
static int _MLMain( charpp_ct argv, charpp_ct argv_end, charp_ct commandline)
#endif /* MLINTERFACE >= 3 */
#else
static int _MLMain( argv, argv_end, commandline)
#if MLINTERFACE >= 3
  char **argv, argv_end;
  char *commandline;
#else
  charpp_ct argv, argv_end;
  charp_ct commandline;
#endif /* MLINTERFACE >= 3 */
#endif
{
	MLINK mlp;
#if MLINTERFACE >= 3
	int err;
#else
	long err;
#endif /* MLINTERFACE >= 3 */

	if( !stdenv)
		stdenv = MLInitialize( (MLParametersPointer)0);
	if( stdenv == (MLEnvironment)0) goto R0;

#if MLINTERFACE >= 3
	if( !stdhandler)
		stdhandler = (MLMessageHandlerObject)MLDefaultHandler;
#else
	if( !stdhandler)
		stdhandler = MLCreateMessageHandler( stdenv, MLDefaultHandler, 0);
#endif /* MLINTERFACE >= 3 */


	mlp = commandline
		? MLOpenString( stdenv, commandline, &err)
#if MLINTERFACE >= 3
		: MLOpenArgcArgv( stdenv, (int)(argv_end - argv), argv, &err);
#else
		: MLOpenArgv( stdenv, argv, argv_end, &err);
#endif
	if( mlp == (MLINK)0){
		MLAlert( stdenv, MLErrorString( stdenv, err));
		goto R1;
	}

	if( stdyielder) MLSetYieldFunction( mlp, stdyielder);
	if( stdhandler) MLSetMessageHandler( mlp, stdhandler);

	if( MLInstall( mlp))
		while( MLAnswer( mlp) == RESUMEPKT){
			if( ! refuse_to_be_a_frontend( mlp)) break;
		}

	MLClose( mlp);
R1:	MLDeinitialize( stdenv);
	stdenv = (MLEnvironment)0;
R0:	return !MLDone;
} /* _MLMain */


#if MLPROTOTYPES
#if MLINTERFACE >= 3
int MLMainString( char *commandline)
#else
int MLMainString( charp_ct commandline)
#endif /* MLINTERFACE >= 3 */
#else
#if MLINTERFACE >= 3
int MLMainString( commandline)  char *commandline;
#else
int MLMainString( commandline)  charp_ct commandline;
#endif /* MLINTERFACE >= 3 */
#endif
{
	return _MLMain( (charpp_ct)0, (charpp_ct)0, commandline);
}

#if MLPROTOTYPES
int MLMainArgv( char** argv, char** argv_end) /* note not FAR pointers */
#else
int MLMainArgv( argv, argv_end)  char **argv, **argv_end;
#endif
{   
	static char FAR * far_argv[128];
	int count = 0;
	
	while(argv < argv_end)
		far_argv[count++] = *argv++;
		 
	return _MLMain( far_argv, far_argv + count, (charp_ct)0);

}

#if MLPROTOTYPES
#if MLINTERFACE >= 3
int MLMain( int argc, char **argv)
#else
int MLMain( int argc, charpp_ct argv)
#endif /* MLINTERFACE >= 3 */
#else
#if MLINTERFACE >= 3
int MLMain( argc, argv) int argc; char **argv;
#else
int MLMain( argc, argv) int argc; charpp_ct argv;
#endif /* MLINTERFACE >= 3 */
#endif
{
#if MLINTERFACE >= 3
 	return _MLMain( argv, argv + argc, (char *)0);
#else
 	return _MLMain( argv, argv + argc, (charp_ct)0);
#endif /* MLINTERFACE >= 3 */
}
 
