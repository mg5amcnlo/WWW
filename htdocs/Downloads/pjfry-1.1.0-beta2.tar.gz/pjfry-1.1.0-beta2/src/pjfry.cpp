/*
 * pjfry.cpp - interface functions
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "common.h"
#include "icache.h"
#include "mcache.h"
#include "kinem.h"

#define PJFRY_NATIVE 1
#include "pjfry.h"

/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                Native interface section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
*/

Tensor::Ptr PJFry::Tensor2(double p1, double m1,  double m2)
{
  const Kinem2 kin(p1, m1, m2);
  return Tensor::Ptr(MCache::getMinor2(kin));
}

Tensor::Ptr PJFry::Tensor3(double p1,  double p2,  double p3,
                    double m1,  double m2,  double m3)
{
  const Kinem3 kin(p1, p2, p3, m1, m2, m3);
  return Tensor::Ptr(MCache::getMinor3(kin));
}

Tensor::Ptr PJFry::Tensor4(double p1,  double p2,  double p3,  double p4,
                    double s12, double s23,
                    double m1,  double m2,  double m3,  double m4)
{
  const Kinem4 kin(p1, p2, p3, p4, s12, s23, m1, m2, m3, m4);
  return Tensor::Ptr(MCache::getMinor4(kin));
}

Tensor::Ptr PJFry::Tensor5(double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return Tensor::Ptr(MCache::getMinor5(kin));
}

Tensor::Ptr PJFry::Tensor6(double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m1,  double m2,  double m3,  double m4,  double m5, double m6)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return Tensor::Ptr(MCache::getMinor6(kin));
}

/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                HEXAGON Integral section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
*/

// Masses shifted to the left to comply with LoopTools notation

pj_complex PJFry::F0v0(double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return MCache::getMinor6(kin)->evalF(abs(ep));
}

pj_complex PJFry::F0v1(int i,
                      double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return -MCache::getMinor6(kin)->evalF(abs(ep), i);
}

pj_complex PJFry::F0v2(int i, int j,
                      double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return MCache::getMinor6(kin)->evalF(abs(ep), i, j);
}

pj_complex PJFry::F0v3(int i, int j, int k,
                      double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return -MCache::getMinor6(kin)->evalF(abs(ep), i, j, k);
}

pj_complex PJFry::F0v4(int i, int j, int k, int l,
                      double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return MCache::getMinor6(kin)->evalF(abs(ep), i, j, k, l);
}

pj_complex PJFry::F0v5(int i, int j, int k, int l, int m,
                      double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return -MCache::getMinor6(kin)->evalF(abs(ep), i, j, k, l, m);
}

pj_complex PJFry::F0v6(int i, int j, int k, int l, int m, int n,
                      double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep)
{
  const Kinem6 kin(p1,p2,p3,p4,p5,p6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m1,m2,m3,m4,m5,m6);
  return MCache::getMinor6(kin)->evalF(abs(ep), i, j, k, l, m, n);
}


/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                PENTAGON Integral section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
*/

// Masses shifted to the left to comply with LoopTools notation

pj_complex PJFry::E0v0(const double p1,  const double p2,  const double p3,  const double p4,  const double p5,
                      const double s12, const double s23, const double s34, const double s45, const double s15,
                      const double m5,  const double m1,  const double m2,  const double m3,  const double m4, const int ep)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return MCache::getMinor5(kin)->evalE(abs(ep));
}

pj_complex PJFry::E0v1(const int i,
                      const double p1,  const double p2,  const double p3,  const double p4,  const double p5,
                      const double s12, const double s23, const double s34, const double s45, const double s15,
                      const double m5,  const double m1,  const double m2,  const double m3,  const double m4, const int ep)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return -MCache::getMinor5(kin)->evalE(abs(ep), i);
}

pj_complex PJFry::E0v2(const int i, const int j,
                      const double p1,  const double p2,  const double p3,  const double p4,  const double p5,
                      const double s12, const double s23, const double s34, const double s45, const double s15,
                      const double m5,  const double m1,  const double m2,  const double m3,  const double m4, const int ep)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return MCache::getMinor5(kin)->evalE(abs(ep), i, j);
}

pj_complex PJFry::E0v3(const int i, const int j, const int k,
                      const double p1,  const double p2,  const double p3,  const double p4,  const double p5,
                      const double s12, const double s23, const double s34, const double s45, const double s15,
                      const double m5,  const double m1,  const double m2,  const double m3,  const double m4, const int ep)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return -MCache::getMinor5(kin)->evalE(abs(ep), i, j, k);
}

pj_complex PJFry::E0v4(const int i, const int j, const int k, const int l,
                      const double p1,  const double p2,  const double p3,  const double p4,  const double p5,
                      const double s12, const double s23, const double s34, const double s45, const double s15,
                      const double m5,  const double m1,  const double m2,  const double m3,  const double m4, const int ep)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return MCache::getMinor5(kin)->evalE(abs(ep), i, j, k, l);
}

pj_complex PJFry::E0v5(const int i, const int j, const int k, const int l, const int m,
                      const double p1,  const double p2,  const double p3,  const double p4,  const double p5,
                      const double s12, const double s23, const double s34, const double s45, const double s15,
                      const double m5,  const double m1,  const double m2,  const double m3,  const double m4, const int ep)
{
  const Kinem5 kin(p1, p2, p3, p4, p5, s12, s23, s34, s45, s15, m1, m2, m3, m4, m5);
  return -MCache::getMinor5(kin)->evalE(abs(ep), i, j, k, l, m);
}

/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                BOX Integral section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
*/

// Masses shifted to the left to comply with LoopTools notation

pj_complex PJFry::D0v0(const double p1,  const double p2,  const double p3,  const double p4,
                      const double s12, const double s23,
                      const double m4,  const double m1,  const double m2,  const double m3, const int ep)
{
  const Kinem4 kin(p1, p2, p3, p4, s12, s23, m1, m2, m3, m4);
  return ICache::getI4(abs(ep), kin);
}

pj_complex PJFry::D0v1(const int i,
                      const double p1,  const double p2,  const double p3,  const double p4,
                      const double s12, const double s23,
                      const double m4,  const double m1,  const double m2,  const double m3, const int ep)
{
  const Kinem4 kin(p1, p2, p3, p4, s12, s23, m1, m2, m3, m4);
  return -MCache::getMinor4(kin)->evalD(abs(ep), i);
}

pj_complex PJFry::D0v2(const int i, const int j,
                      const double p1,  const double p2,  const double p3,  const double p4,
                      const double s12, const double s23,
                      const double m4,  const double m1,  const double m2,  const double m3, const int ep)
{
  const Kinem4 kin(p1, p2, p3, p4, s12, s23, m1, m2, m3, m4);
  return MCache::getMinor4(kin)->evalD(abs(ep), i, j);
}

pj_complex PJFry::D0v3(const int i, const int j, const int k,
                      const double p1,  const double p2,  const double p3,  const double p4,
                      const double s12, const double s23,
                      const double m4,  const double m1,  const double m2,  const double m3, const int ep)
{
  const Kinem4 kin(p1, p2, p3, p4, s12, s23, m1, m2, m3, m4);
  return -MCache::getMinor4(kin)->evalD(abs(ep), i, j, k);
}

pj_complex PJFry::D0v4(const int i, const int j, const int k, const int l,
                      const double p1,  const double p2,  const double p3,  const double p4,
                      const double s12, const double s23,
                      const double m4,  const double m1,  const double m2,  const double m3, const int ep)
{
  const Kinem4 kin(p1, p2, p3, p4, s12, s23, m1, m2, m3, m4);
  return MCache::getMinor4(kin)->evalD(abs(ep), i, j, k, l);
}


/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                TRIANGLE Integral section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
*/

// Masses shifted to the left to comply with LoopTools notation

pj_complex PJFry::C0v0(const double p1,  const double p2,  const double p3,
                      const double m3,  const double m1,  const double m2, const int ep)
{
  const Kinem3 kin(p1, p2, p3, m1, m2, m3);
  return ICache::getI3(abs(ep), kin);
}

// Masses shifted to the left to comply with LoopTools notation

pj_complex PJFry::C0v1(const int i,
                      const double p1,  const double p2,  const double p3,
                      const double m3,  const double m1,  const double m2, const int ep)
{
  const Kinem3 kin(p1, p2, p3, m1, m2, m3);
  return -MCache::getMinor3(kin)->evalC(abs(ep), i);
}

pj_complex PJFry::C0v2(const int i, const int j,
                      const double p1,  const double p2,  const double p3,
                      const double m3,  const double m1,  const double m2, const int ep)
{
  const Kinem3 kin(p1, p2, p3, m1, m2, m3);
  return MCache::getMinor3(kin)->evalC(abs(ep), i, j);
}

pj_complex PJFry::C0v3(const int i, const int j, const int k,
                      const double p1,  const double p2,  const double p3,
                      const double m3,  const double m1,  const double m2, const int ep)
{
  const Kinem3 kin(p1, p2, p3, m1, m2, m3);
  return -MCache::getMinor3(kin)->evalC(abs(ep), i, j, k);
}

/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                BUBBLE Integral section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
*/

// Masses shifted to the left to comply with LoopTools notation

pj_complex PJFry::B0v0(const double p1, const double m2, const double m1, const int ep)
{
  const Kinem2 kin(p1, m1, m2);
  return ICache::getI2(abs(ep), kin);
}

pj_complex PJFry::B0v1(const int i, const double p1, const double m2, const double m1, const int ep)
{
  const Kinem2 kin(p1, m1, m2);
  return -MCache::getMinor2(kin)->evalB(abs(ep), i);
}

pj_complex PJFry::B0v2(const int i, const int j, const double p1, const double m2, const double m1, const int ep)
{
  const Kinem2 kin(p1, m1, m2);
  return MCache::getMinor2(kin)->evalB(abs(ep), i, j);
}

/* ------------------------------------------------------------
* ------------------------------------------------------------
*                TADPOLE Integral section
* ------------------------------------------------------------
* ------------------------------------------------------------
*/

pj_complex PJFry::A0v0(const double m1, const int ep)
{
  return ICache::getI1(abs(ep), Kinem1(m1));
}

/* ------------------------------------------------------------
 * ------------------------------------------------------------
 *                MISC section
 * ------------------------------------------------------------
 * ------------------------------------------------------------
 */

double PJFry::GetMu2()
{
  return ICache::getMu2();
}


double PJFry::SetMu2(const double mu2)
{
  return ICache::setMu2(mu2);
}

void PJFry::ClearCache()
{
  // clear only minor cache
  // keep scalar integrals cache
  MCache::Clear();
}

// =============================================================
// =============================================================
// =============================================================

double pgetmusq_()
{
  return PJFry::GetMu2();
}

void psetmusq_(double *mu2)
{
  PJFry::SetMu2(*mu2);
}

void pclearcache_()
{
  PJFry::ClearCache();
}

#ifdef USE_F2C
/* f2c,g77,ifort calling convention section (result is the first parameter) */
void pe0_(pj_complex *rslt,
          double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
          double *s12, double *s23, double *s34, double *s45, double *s15,
          double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  *rslt=PJFry::E0v0(*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

void pe0i_(pj_complex *rslt,
           int *i,
           double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
           double *s12, double *s23, double *s34, double *s45, double *s15,
           double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  *rslt=PJFry::E0v1(*i,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

void pe0ij_(pj_complex *rslt,
            int *i, int *j,
            double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
            double *s12, double *s23, double *s34, double *s45, double *s15,
            double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  *rslt=PJFry::E0v2(*i,*j,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

void pe0ijk_(pj_complex *rslt,
             int *i, int *j, int *k,
             double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
             double *s12, double *s23, double *s34, double *s45, double *s15,
             double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  *rslt=PJFry::E0v3(*i,*j,*k,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

void pe0ijkl_(pj_complex *rslt,
              int *i, int *j, int *k, int *l,
              double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
              double *s12, double *s23, double *s34, double *s45, double *s15,
              double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  *rslt=PJFry::E0v4(*i,*j,*k,*l,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

void pe0ijklm_(pj_complex *rslt,
               int *i, int *j, int *k, int *l, int *m,
               double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  *rslt=PJFry::E0v5(*i,*j,*k,*l,*m,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

void pd0_(pj_complex *rslt,
          double *p1,  double *p2,  double *p3,  double *p4,
          double *s12, double *s23,
          double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  *rslt=PJFry::D0v0(*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

void pd0i_(pj_complex *rslt,
           int *i,
           double *p1,  double *p2,  double *p3,  double *p4,
           double *s12, double *s23,
           double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  *rslt=PJFry::D0v1(*i,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

void pd0ij_(pj_complex *rslt,
            int *i, int *j,
            double *p1,  double *p2,  double *p3,  double *p4,
            double *s12, double *s23,
            double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  *rslt=PJFry::D0v2(*i,*j,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

void pd0ijk_(pj_complex *rslt,
             int *i, int *j, int *k,
             double *p1,  double *p2,  double *p3,  double *p4,
             double *s12, double *s23,
             double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  *rslt=PJFry::D0v3(*i,*j,*k,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

void pd0ijkl_(pj_complex *rslt,
              int *i, int *j, int *k, int *l,
              double *p1,  double *p2,  double *p3,  double *p4,
              double *s12, double *s23,
              double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  *rslt=PJFry::D0v4(*i,*j,*k,*l,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

void pc0_(pj_complex *rslt,
          double *p1, double *p2, double *p3,
          double *m1, double *m2, double *m3, int *ep)
{
  *rslt=PJFry::C0v0(*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

void pc0i_(pj_complex *rslt,
           int *i,
           double *p1, double *p2, double *p3,
           double *m1, double *m2, double *m3, int *ep)
{
  *rslt=PJFry::C0v1(*i,*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

void pc0ij_(pj_complex *rslt,
            int *i, int *j,
            double *p1, double *p2, double *p3,
            double *m1, double *m2, double *m3, int *ep)
{
  *rslt=PJFry::C0v2(*i,*j,*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

void pc0ijk_(pj_complex *rslt,
             int *i, int *j, int *k,
             double *p1, double *p2, double *p3,
             double *m1, double *m2, double *m3, int *ep)
{
  *rslt=PJFry::C0v3(*i,*j,*k,*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

void pb0_(pj_complex *rslt,
          double *p1, double *m1, double *m2, int *ep)
{
  *rslt=PJFry::B0v0(*p1,*m1,*m2,*ep);
}

void pb0i_(pj_complex *rslt,
           int *i,
           double *p1, double *m1, double *m2, int *ep)
{
  *rslt=PJFry::B0v1(*i,*p1,*m1,*m2,*ep);
}

void pb0ij_(pj_complex *rslt,
            int *i, int *j,
            double *p1, double *m1, double *m2, int *ep)
{
  *rslt=PJFry::B0v2(*i,*j,*p1,*m1,*m2,*ep);
}

void pa0_(pj_complex *rslt, double *m1, int *ep)
{
  *rslt=PJFry::A0v0(*m1,*ep);
}
#else /* USE_F2C */
/* GNU calling convention section (result is a complex return value) */
pj_complex pe0_( double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  return PJFry::E0v0(*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

pj_complex pe0i_(int *i,
               double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  return PJFry::E0v1(*i,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

pj_complex pe0ij_(int *i, int *j,
               double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  return PJFry::E0v2(*i,*j,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

pj_complex pe0ijk_(int *i, int *j, int *k,
               double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  return PJFry::E0v3(*i,*j,*k,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

pj_complex pe0ijkl_(int *i, int *j, int *k, int *l,
               double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  return PJFry::E0v4(*i,*j,*k,*l,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

pj_complex pe0ijklm_(int *i, int *j, int *k, int *l, int *m,
               double *p1,  double *p2,  double *p3,  double *p4,  double *p5,
               double *s12, double *s23, double *s34, double *s45, double *s15,
               double *m1,  double *m2,  double *m3,  double *m4,  double *m5, int *ep)
{
  return PJFry::E0v5(*i,*j,*k,*l,*m,*p1,*p2,*p3,*p4,*p5,*s12,*s23,*s34,*s45,*s15,*m1,*m2,*m3,*m4,*m5,*ep);
}

pj_complex pd0_(double *p1,  double *p2,  double *p3,  double *p4,
              double *s12, double *s23,
              double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  return PJFry::D0v0(*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

pj_complex pd0i_(int *i,
               double *p1,  double *p2,  double *p3,  double *p4,
               double *s12, double *s23,
               double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  return PJFry::D0v1(*i,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

pj_complex pd0ij_(int *i, int *j,
               double *p1,  double *p2,  double *p3,  double *p4,
               double *s12, double *s23,
               double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  return PJFry::D0v2(*i,*j,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

pj_complex pd0ijk_(int *i, int *j, int *k,
               double *p1,  double *p2,  double *p3,  double *p4,
               double *s12, double *s23,
               double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  return PJFry::D0v3(*i,*j,*k,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

pj_complex pd0ijkl_(int *i, int *j, int *k, int *l,
               double *p1,  double *p2,  double *p3,  double *p4,
               double *s12, double *s23,
               double *m1,  double *m2,  double *m3,  double *m4, int *ep)
{
  return PJFry::D0v4(*i,*j,*k,*l,*p1,*p2,*p3,*p4,*s12,*s23,*m1,*m2,*m3,*m4,*ep);
}

pj_complex pc0_(double *p1, double *p2, double *p3,
              double *m1, double *m2, double *m3, int *ep)
{
  return PJFry::C0v0(*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

pj_complex pc0i_(int *i,
               double *p1, double *p2, double *p3,
               double *m1, double *m2, double *m3, int *ep)
{
  return PJFry::C0v1(*i,*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

pj_complex pc0ij_(int *i, int *j,
               double *p1, double *p2, double *p3,
               double *m1, double *m2, double *m3, int *ep)
{
  return PJFry::C0v2(*i,*j,*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

pj_complex pc0ijk_(int *i, int *j, int *k,
               double *p1, double *p2, double *p3,
               double *m1, double *m2, double *m3, int *ep)
{
  return PJFry::C0v3(*i,*j,*k,*p1,*p2,*p3,*m1,*m2,*m3,*ep);
}

pj_complex pb0_( double *p1, double *m1, double *m2, int *ep)
{
  return PJFry::B0v0(*p1,*m1,*m2,*ep);
}

pj_complex pb0i_(int *i,
               double *p1, double *m1, double *m2, int *ep)
{
  return PJFry::B0v1(*i,*p1,*m1,*m2,*ep);
}

pj_complex pb0ij_(int *i, int *j,
               double *p1, double *m1, double *m2, int *ep)
{
  return PJFry::B0v2(*i,*j,*p1,*m1,*m2,*ep);
}

pj_complex pa0_( double *m1, int *ep)
{
  return PJFry::A0v0(*m1,*ep);
}
#endif /* USE_F2C */
