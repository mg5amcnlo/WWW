/*
 * minor.cpp - hexagons
 *
 * this file is part of PJFry library
 * Copyright 2012 Valery Yundin
 */

#include "minor6.h"
#include "icache.h"
#include "mcache.h"

/* Define local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 * rrMi - matrix rank numbering
 */
#define pM1 rrM6
#define pM2 rrM5
#define pM3 rrM4
#define pM4 rrM3
#define evalM1 evalRM6
#define evalM2 evalRM5
#define evalM3 evalRM4
#define evalM4 evalRM3
#define DM1 RM6
#define DM2 RM5
#define DM3 RM4
#define DM4 RM3

/* --------------------------------------------------------
 *    Real 6-point kinematics
 * --------------------------------------------------------
 */
Minor6::Minor6(const Kinem6& k) : kinem(k)
{
  pID0[0] = Cache::sNAN.d64;
  pID0[1] = Cache::sNAN.d64;
  pID0[2] = Cache::sNAN.d64;

  const double p1=kinem.p1();
  const double p2=kinem.p2();
  const double p3=kinem.p3();
  const double p4=kinem.p4();
  const double p5=kinem.p5();
  const double p6=kinem.p6();
  const double s12=kinem.s12();
  const double s23=kinem.s23();
  const double s34=kinem.s34();
  const double s45=kinem.s45();
  const double s56=kinem.s56();
  const double s16=kinem.s16();
  const double s234=kinem.s234();
  const double s345=kinem.s345();
  const double s456=kinem.s456();
  const double m1=kinem.m1();
  const double m2=kinem.m2();
  const double m3=kinem.m3();
  const double m4=kinem.m4();
  const double m5=kinem.m5();
  const double m6=kinem.m6();

  // Pentagons
  const Kinem5 k5[] = {
    Kinem5(s12,p3,p4,p5,p6,s456,s34,s45,s56,s345,m2,m3,m4,m5,m6),
    Kinem5(p1,s23,p4,p5,p6,s456,s234,s45,s56,s16,m1,m3,m4,m5,m6),
    Kinem5(p1,p2,s34,p5,p6,s12,s234,s345,s56,s16,m1,m2,m4,m5,m6),
    Kinem5(p1,p2,p3,s45,p6,s12,s23,s345,s456,s16,m1,m2,m3,m5,m6),
    Kinem5(p1,p2,p3,p4,s56,s12,s23,s34,s456,s234,m1,m2,m3,m4,m6),
    Kinem5(s16,p2,p3,p4,p5,s345,s23,s34,s45,s234,m1,m2,m3,m4,m5)
  };
  MEntry5* ptrs5[N];
  for (int i=0; i<N; i++) {
    ptrs5[i] = &MCache::entry(k5[i]); // look-up or create empty element
    mnr5[i] = ptrs5[i]->val;
  }

  // do smth, initialize minors
  kinem.setcayley(Cay);
  evalM1();

  for (int i=0; i<N; i++) {
//     printf("mnr5[%d] = %lX ------------------\n", i, mnr5[i].operator->());
    if (mnr5[i] == 0) {
      if (ptrs5[i]->val == 0) {
        mnr5[i] = Minor5::create(k5[i]);
        ptrs5[i]->val = mnr5[i]; // MCache::insertMinor5(k5[i], mnr5[i]);
      } else {
        mnr5[i] = ptrs5[i]->val;
      }
    }
  }
}

/* --------------------------------------------------------
 *
 *                6-point signed minors
 *
 * --------------------------------------------------------
 */

/* --------------------------------------------------------
    Return one-index minor with proper sign
 * --------------------------------------------------------
 */
double Minor6::M1(int i, int l)
{
  return pM1[is(i,l)];
}

/* --------------------------------------------------------
    Return two-index minor with proper sign
 * --------------------------------------------------------
 */
double Minor6::M2(int i, int j, int l, int m)
{
  int sign=signM2ud(i,j,l,m);
  if (sign==0) return 0;

  int uidx=im2(i,j);
  int lidx=im2(l,m);

  return pM2[is(uidx,lidx)]*sign;
}

/* --------------------------------------------------------
  Return three-index minor with proper sign
* --------------------------------------------------------
*/
double Minor6::M3(int i, int j, int k, int l, int m, int n)
{
  int sign=signM3ud(i,j,k,l,m,n);
  if (sign==0) return 0;

  int uidx=im3(i,j,k);
  int lidx=im3(l,m,n);

  return pM3[is(uidx,lidx)]*sign;
}

/* --------------------------------------------------------
    Evaluate all one-index minors (need 2-idx minors)
 * --------------------------------------------------------
 */
void Minor6::evalM1()
{
  if (not fEval[E_M2] ) {
    evalM2();
  }
#ifndef NDEBUG
  for (int i=0; i<DM1*(DM1+1)/2; i++) { pM1[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif
  {
    const int i=0;
    const int j=1;
    {
      const int l=0; const int bl=1<<l;

      double m1ele = 0.;
      const int ui = 0; // idxtbl[bi|bj]
      for (int m=1; m<=DCay-1; m++) {
        const unsigned int tdi = (1<<m)|bl;
        m1ele += pM2[iss(ui,idxtbl[tdi])]*Cay[nss(j,m)];
      }
      pM1[is(i,l)] = m1ele;
    }
  }
  const int j=0;
  for (int i=1; i<=DCay-1; i++) {
    for (int l=0; l<=i; l++) {
      double m1ele = 0.;
      for (int m=1; m<=DCay-1; m++) {
        m1ele += M2(i,j,l,m);
      }
      pM1[iss(l,i)] = m1ele;
    }
  }
  fEval[E_M1] = true;
}

/* --------------------------------------------------------
    Evaluate all two-index minors (need 3-idx minors)
 * --------------------------------------------------------
 */
void Minor6::evalM2()
{
  evalM3();
#ifndef NDEBUG
  for (int i=0; i<DM2*(DM2+1)/2; i++) { pM2[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif

  const unsigned int mask = (1<<DCay)-1;
  {
  const int i=0;                    const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-1; j++) { const unsigned int bj = 1<<j;
    const int k = j==1 ? 2 : 1;     const unsigned int bk = 1<<k;
    const unsigned int uidx = idxtbl[bi|bj];
    const unsigned int bijk = bi|bj|bk;
    for (int l=0;   l<=DCay-2; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int blm = bl|bm;
      const unsigned int lidx = idxtbl[blm];
      if (lidx > uidx) continue;

      const unsigned int ui = idxtbl[bijk];
      int sign = (k<<1)-3; // k==1 ? -1 : 1;
      double m2ele = 0.;
      if (l==0) {
        sign = -sign;
      } else {
        m2ele = sign*pM3[is(ui,idxtbl[blm|1])];
      }
      for (int n=1; n<=DCay-1; n++) {
        const unsigned int tdi = (1<<n)|blm;
        if (tdi == blm) {
          sign = -sign;
        } else {
          m2ele += sign*pM3[is(ui,idxtbl[tdi])]*Cay[ns(k,n)];
        }
      }
      pM2[iss(lidx,uidx)] = m2ele;
    }
    }
  }
  }
  const int k=0;                    const unsigned int bk = 1<<k;
  for (int i=1;   i<=DCay-2; i++) { const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-1; j++) { const unsigned int bj = 1<<j;
    const unsigned int uidx = idxtbl[bi|bj];
    const unsigned int bijk = bi|bj|bk;
    for (int l=0;   l<=DCay-2; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int blm = bl|bm;
      const unsigned int lidx = idxtbl[blm];
      if (lidx > uidx) continue;

      const unsigned int ui = idxtbl[bijk];
      int sign = l==0 ? -1 : 1;
      double m2ele = 0.;
      for (int n=1; n<=DCay-1; n++) {
        const unsigned int tdi = (1<<n)|blm;
        if (tdi == blm) {
          sign = -sign;
        } else {
          m2ele += sign*pM3[is(ui,idxtbl[tdi])];
        }
      }
      pM2[iss(lidx,uidx)] = m2ele;
    }
    }
  }
  }
  fEval[E_M2] = true;
}

/* --------------------------------------------------------
    Evaluate all XXX three-index minors (need 4-idx minors)
 * --------------------------------------------------------
 */
void Minor6::evalM3()
{
  evalM4();
#ifndef NDEBUG
  for (int i=0; i<DM3*(DM3+1)/2; i++) { pM3[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif

  {
  const int i=0;                    const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-2; j++) { const unsigned int bj = 1<<j;
  for (int k=j+1; k<=DCay-1; k++) { const unsigned int bk = 1<<k;
    const int q = j==1 ? (k==2 ? 3 : 2) : 1; const unsigned int bq = 1<<q;
    const unsigned int uidx = idxtbl[bi|bj|bk]; //im3(i,j,k);
    const unsigned int bijkq = bi|bj|bk|bq;
    for (int l=0;   l<=DCay-3; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-2; m++) { const unsigned int bm = 1<<m;
    for (int n=m+1; n<=DCay-1; n++) { const unsigned int bn = 1<<n;
      const unsigned int blmn = bl|bm|bn;
      const unsigned int lidx = idxtbl[blmn]; //im3(l,m,n);
      if (lidx > uidx) continue;

      const unsigned int ui = idxtbl[bijkq];
      int sign = (q==1 || q==3) ? -1 : 1;
      double m3ele = 0.;
      if (l==0) {
        sign = -sign;
      } else {
        m3ele = sign*pM4[is(ui,idxtbl[blmn|1])];
      }
      for (int p=1; p<=DCay-1; p++) {
        const unsigned int tdi = (1<<p)|blmn; //bp|blmn;
        if (tdi == blmn) {
          sign = -sign;
        } else {
          m3ele += sign*pM4[is(ui,idxtbl[tdi])]*Cay[ns(q,p)];
        }
      }
      pM3[is(uidx,lidx)] = m3ele;
    }
    }
    }
  }
  }
  }
  const int q=0;                    const unsigned int bq = 1<<q;
  for (int i=1;   i<=DCay-3; i++) { const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-2; j++) { const unsigned int bj = 1<<j;
  for (int k=j+1; k<=DCay-1; k++) { const unsigned int bk = 1<<k;
    const unsigned int uidx = idxtbl[bi|bj|bk]; //im3(i,j,k);
    const unsigned int bijkq = bi|bj|bk|bq;
    for (int l=0;   l<=DCay-3; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-2; m++) { const unsigned int bm = 1<<m;
    for (int n=m+1; n<=DCay-1; n++) { const unsigned int bn = 1<<n;
      const unsigned int blmn = bl|bm|bn;
      const unsigned int lidx = idxtbl[blmn]; //im3(l,m,n);
      if (lidx > uidx) continue;

      const unsigned int ui = idxtbl[bijkq];
      int sign = l==0 ? -1 : 1;
      double m3ele = 0.;
      for (int p=1; p<=DCay-1; p++) {
        const unsigned int tdi = (1<<p)|blmn; //bp|blmn;
        if (tdi == blmn) {
          sign = -sign;
        } else {
          m3ele += sign*pM4[is(ui,idxtbl[tdi])];
        }
      }
      pM3[is(uidx,lidx)] = m3ele;
    }
    }
    }
  }
  }
  }
  fEval[E_M3] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-0 functions
 *
 * --------------------------------------------------------
 */

void Minor6::ID0Eval(int ep)
{
  ncomplex sum1 = 0.;
  for (int s=1; s<=N; s++) {
    sum1 += M1(0, s)*I5s(ep, s);
  }
  pID0[ep] = sum1/M1(0, 0);
}

/* --------------------------------------------------------
 *
 *                Rank-1 functions
 *
 * --------------------------------------------------------
 */
ncomplex Minor6::IDi(int ep, int i)
{
  assert(ep<=2);
  if (not fEval[E_Di+ep]) {
    IDiEval(ep);
  }
  return pIDi[ep][i-1];
}

void Minor6::IDiEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
//       printf("Minor[yf6, {0, %d}, {0, %d}] - (%.15e),\n", i, s, M2(0,i,0,s));
      sum1 += M2(0, i, 0, s)*I5s(ep, s);
    }
    pIDi[ep][i-1] = sum1/M1(0, 0);
  }
//   printf("Minor[yf6, {0}, {0}] - (%.15e),\n", M1(0,0));
  fEval[E_Di+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-2 functions
 *
 * --------------------------------------------------------
 */

ncomplex Minor6::ID2ij(int ep, int i, int j)
{
  assert(ep<=2);
  if (not fEval[E_D2ij+ep]) {
    ID2ijEval(ep);
  }
  return pID2ij[ep][ns(i,j)];
}

void Minor6::ID2ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
      sum1 += M2(0, j, 0, s)*I5Dsi(ep, s, i);
    }
    pID2ij[ep][nss(i,j)] = sum1/M1(0, 0);
  }
  }
  fEval[E_D2ij+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-3 functions
 *
 * --------------------------------------------------------
 */

ncomplex Minor6::ID3ijk(int ep, int i, int j, int k)
{
  assert(ep<=2);
  if (not fEval[E_D3ijk+ep]) {
    ID3ijkEval(ep);
  }
  return pID3ijk[ep][is(i-1,j-1,k-1)];
}

void Minor6::ID3ijkEval(int ep)
{
  // symmetric in 'i,j,k'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  /*
    ncomplex sum1 = 0.;
    ncomplex sumX = 0.;
    ncomplex sumY = 0.;
    if (i == j) {
      for (int s=1; s<=N; s++) {
      }
      if (i != k) {
        for (int s=1; s<=N; s++) {
        }
        sum1 = (sum1+2.*sumX)/3.;
      }
    } else { // i!=j
      for (int s=1; s<=N; s++) {
      }
      if (i != k) {
        for (int s=1; s<=N; s++) {
        }
      }
      else { sumX = sum1; }
      if (j != k) {
        for (int s=1; s<=N; s++) {
        }
      }
      else { sumY = sum1; }
      sum1 = (sum1+sumX+sumY)/3.;
    }
    */
    ncomplex sum1 = 0.;
    ncomplex sum00 = 0.;
    // TODO maybe optimize averaging
    for (int s=1; s<=N; s++) {
      sum00 += ( M2(0, k, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, k))*I5Ds(ep, s);
      sum1 += M2(0, k, 0, s)*I5D2sij(ep, s, i, j)
             +M2(0, i, 0, s)*I5D2sij(ep, s, j, k)
             +M2(0, j, 0, s)*I5D2sij(ep, s, i, k);
    }
    const double d00 = M1(0, 0);
    pID3ijk[ep][iss(i-1,j-1,k-1)] = (sum1-sum00/d00)/(3.*d00);
  }
  }
  }
  fEval[E_D3ijk+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-4 functions
 *
 * --------------------------------------------------------
 */

ncomplex Minor6::ID4ijkl(int ep, int i, int j, int k, int l)
{
  assert(ep<=2);
  if (not fEval[E_D4ijkl+ep]) {
    ID4ijklEval(ep);
  }
  return pID4ijkl[ep][is(i-1,j-1,k-1,l-1)];
}

void Minor6::ID4ijklEval(int ep)
{
  // symmetric in 'i,j,k,l'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  for (int l=k; l<=CIDX; l++) {
    /*
    ncomplex sum1234 = 0.;
    for (int s=1; s<=N; s++) {
      ncomplex sum1 = ...;
      ncomplex sum2 = sum1;
      if (l!=k) {
        sum2 = ...;
      }
      ncomplex sum3 = sum1;
      if (j==k) {
        sum3 = sum2;
      } else if (l!=j) {
        sum3 = ...;
      }
      ncomplex sum4 = sum1;
      if (i==j) {
        sum4 = sum3;
      } else if (l!=i) {
        sum4 = ...;
      }
      sum1234 += sum1+sum2+sum3+sum4;
    }
    */
    ncomplex sum1 = 0.;
    ncomplex sum00 = 0.;
    // TODO maybe optimize averaging
    for (int s=1; s<=N; s++) {
      if (s != l)
      sum00 += ( M2(0, k, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, k))*I5D2si(ep, s, l);
      if (s != k)
      sum00 += ( M2(0, l, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, l, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, l))*I5D2si(ep, s, k);
      if (s != j)
      sum00 += ( M2(0, k, 0, s)*M2(0, l, 0, i)
                +M2(0, l, 0, s)*M2(0, i, 0, k)
                +M2(0, i, 0, s)*M2(0, k, 0, l))*I5D2si(ep, s, j);
      if (s != i)
      sum00 += ( M2(0, k, 0, s)*M2(0, l, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, l)
                +M2(0, l, 0, s)*M2(0, j, 0, k))*I5D2si(ep, s, i);

      sum1 += M2(0, l, 0, s)*I5D3sijk(ep, s, i, j, k)
             +M2(0, i, 0, s)*I5D3sijk(ep, s, j, k, l)
             +M2(0, j, 0, s)*I5D3sijk(ep, s, i, k, l)
             +M2(0, k, 0, s)*I5D3sijk(ep, s, i, j, l);
    }
    const double d00 = M1(0, 0);
    pID4ijkl[ep][iss(i-1,j-1,k-1,l-1)] = (sum1-sum00/d00)/(4.*d00);
  }
  }
  }
  }
  fEval[E_D4ijkl+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-5 functions
 *
 * --------------------------------------------------------
 */

ncomplex Minor6::ID5ijklm(int ep, int i, int j, int k, int l, int m)
{
  assert(ep<=2);
  if (not fEval[E_D5ijklm+ep]) {
    ID5ijklmEval(ep);
  }
  return pID5ijklm[ep][iss(i-1,j-1,k-1,l-1,m-1)];
}

void Minor6::ID5ijklmEval(int ep)
{
  // symmetric in 'i,j,k,lm'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  for (int l=k; l<=CIDX; l++) {
  for (int m=l; m<=CIDX; m++) {
    /*
    ncomplex sum12345 = 0.;
    for (int s=1; s<=N; s++) {
      ncomplex sum1 = ...;
      ncomplex sum2 = sum1;
      if (m!=l) {
        sum2 = ...;
      }
      ncomplex sum3 = sum1;
      if (k==l) {
        sum3 = sum2;
      }
      else if (m!=k) {
        sum3 = ...;
      }
      ncomplex sum4 = sum1;
      if (j==k) {
        sum4 = sum3;
      }
      else if (m!=j) {
        sum4 = ...;
      }
      ncomplex sum5 = sum1;
      if (i==j) {
        sum5 = sum4;
      }
      else if (m!=i) {
        sum5 = ...;
      }
      sum12345 += sum1+sum2+sum3+sum4+sum5;
    }
    */
    ncomplex sum1 = 0.;
    ncomplex sum00 = 0.;
    ncomplex sum0000 = 0.;
    // TODO maybe optimize averaging
    for (int s=1; s<=N; s++) {
      sum0000 += ( M2(0, m, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, l)
                  +M2(0, m, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, l)
                  +M2(0, m, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, k)
                  +M2(0, l, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, m)
                  +M2(0, l, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, m)
                  +M2(0, l, 0, s)*M2(0, j, 0, m)*M2(0, i, 0, k)
                  +M2(0, k, 0, s)*M2(0, i, 0, j)*M2(0, m, 0, l)
                  +M2(0, k, 0, s)*M2(0, m, 0, j)*M2(0, i, 0, l)
                  +M2(0, k, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, m)
                  +M2(0, j, 0, s)*M2(0, i, 0, m)*M2(0, k, 0, l)
                  +M2(0, j, 0, s)*M2(0, k, 0, m)*M2(0, i, 0, l)
                  +M2(0, j, 0, s)*M2(0, m, 0, l)*M2(0, i, 0, k)
                  +M2(0, i, 0, s)*M2(0, m, 0, j)*M2(0, k, 0, l)
                  +M2(0, i, 0, s)*M2(0, k, 0, j)*M2(0, m, 0, l)
                  +M2(0, i, 0, s)*M2(0, j, 0, l)*M2(0, m, 0, k))*I5D2s(ep, s);
      sum00 += ( M2(0, k, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, k))*I5D3sij(ep, s, l, m);
      sum00 += ( M2(0, l, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, l, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, l))*I5D3sij(ep, s, k, m);
      sum00 += ( M2(0, k, 0, s)*M2(0, l, 0, i)
                +M2(0, l, 0, s)*M2(0, i, 0, k)
                +M2(0, i, 0, s)*M2(0, k, 0, l))*I5D3sij(ep, s, j, m);
      sum00 += ( M2(0, k, 0, s)*M2(0, l, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, l)
                +M2(0, l, 0, s)*M2(0, j, 0, k))*I5D3sij(ep, s, i, m);
      sum00 += ( M2(0, m, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, m, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, m))*I5D3sij(ep, s, k, l);
      sum00 += ( M2(0, k, 0, s)*M2(0, m, 0, i)
                +M2(0, m, 0, s)*M2(0, i, 0, k)
                +M2(0, i, 0, s)*M2(0, k, 0, m))*I5D3sij(ep, s, j, l);
      sum00 += ( M2(0, k, 0, s)*M2(0, m, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, m)
                +M2(0, m, 0, s)*M2(0, j, 0, k))*I5D3sij(ep, s, i, l);
      sum00 += ( M2(0, l, 0, s)*M2(0, m, 0, i)
                +M2(0, m, 0, s)*M2(0, i, 0, l)
                +M2(0, i, 0, s)*M2(0, l, 0, m))*I5D3sij(ep, s, j, k);
      sum00 += ( M2(0, l, 0, s)*M2(0, m, 0, j)
                +M2(0, j, 0, s)*M2(0, l, 0, m)
                +M2(0, m, 0, s)*M2(0, j, 0, l))*I5D3sij(ep, s, i, k);
      sum00 += ( M2(0, l, 0, s)*M2(0, m, 0, k)
                +M2(0, k, 0, s)*M2(0, l, 0, m)
                +M2(0, m, 0, s)*M2(0, k, 0, l))*I5D3sij(ep, s, i, j);

      sum1 += M2(0, m, 0, s)*I5D4sijkl(ep, s, i, j, k, l)
             +M2(0, l, 0, s)*I5D4sijkl(ep, s, i, j, k, m)
             +M2(0, k, 0, s)*I5D4sijkl(ep, s, i, j, l, m)
             +M2(0, j, 0, s)*I5D4sijkl(ep, s, i, k, l, m)
             +M2(0, i, 0, s)*I5D4sijkl(ep, s, j, k, l, m);
    }
    const double d00 = M1(0, 0);
    pID5ijklm[ep][iss(i-1,j-1,k-1,l-1,m-1)] = (sum1-(sum00-sum0000/d00)/d00)/(5.*d00);
  }
  }
  }
  }
  }
  fEval[E_D5ijklm+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-6 functions
 *
 * --------------------------------------------------------
 */

ncomplex Minor6::ID6ijklmn(int ep, int i, int j, int k, int l, int m, int n)
{
  assert(ep<=2);
  if (not fEval[E_D6ijklmn+ep]) {
    ID6ijklmnEval(ep);
  }
  return pID6ijklmn[ep][iss(i-1,j-1,k-1,l-1,m-1,n-1)];
}

void Minor6::ID6ijklmnEval(int ep)
{
  // symmetric in 'i,j,k,lm'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  for (int l=k; l<=CIDX; l++) {
  for (int m=l; m<=CIDX; m++) {
  for (int n=m; n<=CIDX; n++) {
    /*
    ncomplex sum12345 = 0.;
    for (int s=1; s<=N; s++) {
      ncomplex sum1 = ...;
      ncomplex sum2 = sum1;
      if (m!=l) {
        sum2 = ...;
      }
      ncomplex sum3 = sum1;
      if (k==l) {
        sum3 = sum2;
      }
      else if (m!=k) {
        sum3 = ...;
      }
      ncomplex sum4 = sum1;
      if (j==k) {
        sum4 = sum3;
      }
      else if (m!=j) {
        sum4 = ...;
      }
      ncomplex sum5 = sum1;
      if (i==j) {
        sum5 = sum4;
      }
      else if (m!=i) {
        sum5 = ...;
      }
      sum12345 += sum1+sum2+sum3+sum4+sum5;
    }
    */
    ncomplex sum1 = 0.;
    ncomplex sum00 = 0.;
    ncomplex sum0000 = 0.;
    // TODO maybe optimize averaging
    for (int s=1; s<=N; s++) {
      if (s != n)
      sum0000 += ( M2(0, m, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, l)
                  +M2(0, m, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, l)
                  +M2(0, m, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, k)
                  +M2(0, l, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, m)
                  +M2(0, l, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, m)
                  +M2(0, l, 0, s)*M2(0, j, 0, m)*M2(0, i, 0, k)
                  +M2(0, k, 0, s)*M2(0, i, 0, j)*M2(0, m, 0, l)
                  +M2(0, k, 0, s)*M2(0, m, 0, j)*M2(0, i, 0, l)
                  +M2(0, k, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, m)
                  +M2(0, j, 0, s)*M2(0, i, 0, m)*M2(0, k, 0, l)
                  +M2(0, j, 0, s)*M2(0, k, 0, m)*M2(0, i, 0, l)
                  +M2(0, j, 0, s)*M2(0, m, 0, l)*M2(0, i, 0, k)
                  +M2(0, i, 0, s)*M2(0, m, 0, j)*M2(0, k, 0, l)
                  +M2(0, i, 0, s)*M2(0, k, 0, j)*M2(0, m, 0, l)
                  +M2(0, i, 0, s)*M2(0, j, 0, l)*M2(0, m, 0, k))*I5D3si(ep, s, n);
      if (s != m)
      sum0000 += ( M2(0, n, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, l)
                  +M2(0, n, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, l)
                  +M2(0, n, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, k)
                  +M2(0, l, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, n)
                  +M2(0, l, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, n)
                  +M2(0, l, 0, s)*M2(0, j, 0, n)*M2(0, i, 0, k)
                  +M2(0, k, 0, s)*M2(0, i, 0, j)*M2(0, n, 0, l)
                  +M2(0, k, 0, s)*M2(0, n, 0, j)*M2(0, i, 0, l)
                  +M2(0, k, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, n)
                  +M2(0, j, 0, s)*M2(0, i, 0, n)*M2(0, k, 0, l)
                  +M2(0, j, 0, s)*M2(0, k, 0, n)*M2(0, i, 0, l)
                  +M2(0, j, 0, s)*M2(0, n, 0, l)*M2(0, i, 0, k)
                  +M2(0, i, 0, s)*M2(0, n, 0, j)*M2(0, k, 0, l)
                  +M2(0, i, 0, s)*M2(0, k, 0, j)*M2(0, n, 0, l)
                  +M2(0, i, 0, s)*M2(0, j, 0, l)*M2(0, n, 0, k))*I5D3si(ep, s, m);
      if (s != l)
      sum0000 += ( M2(0, m, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, n)
                  +M2(0, m, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, n)
                  +M2(0, m, 0, s)*M2(0, j, 0, n)*M2(0, i, 0, k)
                  +M2(0, n, 0, s)*M2(0, i, 0, j)*M2(0, k, 0, m)
                  +M2(0, n, 0, s)*M2(0, k, 0, j)*M2(0, i, 0, m)
                  +M2(0, n, 0, s)*M2(0, j, 0, m)*M2(0, i, 0, k)
                  +M2(0, k, 0, s)*M2(0, i, 0, j)*M2(0, m, 0, n)
                  +M2(0, k, 0, s)*M2(0, m, 0, j)*M2(0, i, 0, n)
                  +M2(0, k, 0, s)*M2(0, j, 0, n)*M2(0, i, 0, m)
                  +M2(0, j, 0, s)*M2(0, i, 0, m)*M2(0, k, 0, n)
                  +M2(0, j, 0, s)*M2(0, k, 0, m)*M2(0, i, 0, n)
                  +M2(0, j, 0, s)*M2(0, m, 0, n)*M2(0, i, 0, k)
                  +M2(0, i, 0, s)*M2(0, m, 0, j)*M2(0, k, 0, n)
                  +M2(0, i, 0, s)*M2(0, k, 0, j)*M2(0, m, 0, n)
                  +M2(0, i, 0, s)*M2(0, j, 0, n)*M2(0, m, 0, k))*I5D3si(ep, s, l);
      if (s != k)
      sum0000 += ( M2(0, m, 0, s)*M2(0, i, 0, j)*M2(0, n, 0, l)
                  +M2(0, m, 0, s)*M2(0, n, 0, j)*M2(0, i, 0, l)
                  +M2(0, m, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, n)
                  +M2(0, l, 0, s)*M2(0, i, 0, j)*M2(0, n, 0, m)
                  +M2(0, l, 0, s)*M2(0, n, 0, j)*M2(0, i, 0, m)
                  +M2(0, l, 0, s)*M2(0, j, 0, m)*M2(0, i, 0, n)
                  +M2(0, n, 0, s)*M2(0, i, 0, j)*M2(0, m, 0, l)
                  +M2(0, n, 0, s)*M2(0, m, 0, j)*M2(0, i, 0, l)
                  +M2(0, n, 0, s)*M2(0, j, 0, l)*M2(0, i, 0, m)
                  +M2(0, j, 0, s)*M2(0, i, 0, m)*M2(0, n, 0, l)
                  +M2(0, j, 0, s)*M2(0, n, 0, m)*M2(0, i, 0, l)
                  +M2(0, j, 0, s)*M2(0, m, 0, l)*M2(0, i, 0, n)
                  +M2(0, i, 0, s)*M2(0, m, 0, j)*M2(0, n, 0, l)
                  +M2(0, i, 0, s)*M2(0, n, 0, j)*M2(0, m, 0, l)
                  +M2(0, i, 0, s)*M2(0, j, 0, l)*M2(0, m, 0, n))*I5D3si(ep, s, k);
      if (s != j)
      sum0000 += ( M2(0, m, 0, s)*M2(0, i, 0, n)*M2(0, k, 0, l)
                  +M2(0, m, 0, s)*M2(0, k, 0, n)*M2(0, i, 0, l)
                  +M2(0, m, 0, s)*M2(0, n, 0, l)*M2(0, i, 0, k)
                  +M2(0, l, 0, s)*M2(0, i, 0, n)*M2(0, k, 0, m)
                  +M2(0, l, 0, s)*M2(0, k, 0, n)*M2(0, i, 0, m)
                  +M2(0, l, 0, s)*M2(0, n, 0, m)*M2(0, i, 0, k)
                  +M2(0, k, 0, s)*M2(0, i, 0, n)*M2(0, m, 0, l)
                  +M2(0, k, 0, s)*M2(0, m, 0, n)*M2(0, i, 0, l)
                  +M2(0, k, 0, s)*M2(0, n, 0, l)*M2(0, i, 0, m)
                  +M2(0, n, 0, s)*M2(0, i, 0, m)*M2(0, k, 0, l)
                  +M2(0, n, 0, s)*M2(0, k, 0, m)*M2(0, i, 0, l)
                  +M2(0, n, 0, s)*M2(0, m, 0, l)*M2(0, i, 0, k)
                  +M2(0, i, 0, s)*M2(0, m, 0, n)*M2(0, k, 0, l)
                  +M2(0, i, 0, s)*M2(0, k, 0, n)*M2(0, m, 0, l)
                  +M2(0, i, 0, s)*M2(0, n, 0, l)*M2(0, m, 0, k))*I5D3si(ep, s, j);
      if (s != i)
      sum0000 += ( M2(0, m, 0, s)*M2(0, n, 0, j)*M2(0, k, 0, l)
                  +M2(0, m, 0, s)*M2(0, k, 0, j)*M2(0, n, 0, l)
                  +M2(0, m, 0, s)*M2(0, j, 0, l)*M2(0, n, 0, k)
                  +M2(0, l, 0, s)*M2(0, n, 0, j)*M2(0, k, 0, m)
                  +M2(0, l, 0, s)*M2(0, k, 0, j)*M2(0, n, 0, m)
                  +M2(0, l, 0, s)*M2(0, j, 0, m)*M2(0, n, 0, k)
                  +M2(0, k, 0, s)*M2(0, n, 0, j)*M2(0, m, 0, l)
                  +M2(0, k, 0, s)*M2(0, m, 0, j)*M2(0, n, 0, l)
                  +M2(0, k, 0, s)*M2(0, j, 0, l)*M2(0, n, 0, m)
                  +M2(0, j, 0, s)*M2(0, n, 0, m)*M2(0, k, 0, l)
                  +M2(0, j, 0, s)*M2(0, k, 0, m)*M2(0, n, 0, l)
                  +M2(0, j, 0, s)*M2(0, m, 0, l)*M2(0, n, 0, k)
                  +M2(0, n, 0, s)*M2(0, m, 0, j)*M2(0, k, 0, l)
                  +M2(0, n, 0, s)*M2(0, k, 0, j)*M2(0, m, 0, l)
                  +M2(0, n, 0, s)*M2(0, j, 0, l)*M2(0, m, 0, k))*I5D3si(ep, s, i);
      sum00 += ( M2(0, k, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, k))*I5D4sijk(ep, s, l, m, n);
      sum00 += ( M2(0, l, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, l, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, l))*I5D4sijk(ep, s, k, m, n);
      sum00 += ( M2(0, m, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, m, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, m))*I5D4sijk(ep, s, k, l, n);
      sum00 += ( M2(0, n, 0, s)*M2(0, i, 0, j)
                +M2(0, j, 0, s)*M2(0, n, 0, i)
                +M2(0, i, 0, s)*M2(0, j, 0, n))*I5D4sijk(ep, s, k, l, m);
      sum00 += ( M2(0, l, 0, s)*M2(0, i, 0, k)
                +M2(0, k, 0, s)*M2(0, l, 0, i)
                +M2(0, i, 0, s)*M2(0, k, 0, l))*I5D4sijk(ep, s, j, m, n);
      sum00 += ( M2(0, m, 0, s)*M2(0, i, 0, k)
                +M2(0, k, 0, s)*M2(0, m, 0, i)
                +M2(0, i, 0, s)*M2(0, k, 0, m))*I5D4sijk(ep, s, j, l, n);
      sum00 += ( M2(0, n, 0, s)*M2(0, i, 0, k)
                +M2(0, k, 0, s)*M2(0, n, 0, i)
                +M2(0, i, 0, s)*M2(0, k, 0, n))*I5D4sijk(ep, s, j, l, m);
      sum00 += ( M2(0, m, 0, s)*M2(0, i, 0, l)
                +M2(0, l, 0, s)*M2(0, m, 0, i)
                +M2(0, i, 0, s)*M2(0, l, 0, m))*I5D4sijk(ep, s, j, k, n);
      sum00 += ( M2(0, n, 0, s)*M2(0, i, 0, l)
                +M2(0, l, 0, s)*M2(0, n, 0, i)
                +M2(0, i, 0, s)*M2(0, l, 0, n))*I5D4sijk(ep, s, j, k, m);
      sum00 += ( M2(0, n, 0, s)*M2(0, i, 0, m)
                +M2(0, m, 0, s)*M2(0, n, 0, i)
                +M2(0, i, 0, s)*M2(0, m, 0, n))*I5D4sijk(ep, s, j, k, l);
      sum00 += ( M2(0, l, 0, s)*M2(0, j, 0, k)
                +M2(0, k, 0, s)*M2(0, l, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, l))*I5D4sijk(ep, s, i, m, n);
      sum00 += ( M2(0, m, 0, s)*M2(0, j, 0, k)
                +M2(0, k, 0, s)*M2(0, m, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, m))*I5D4sijk(ep, s, i, l, n);
      sum00 += ( M2(0, n, 0, s)*M2(0, j, 0, k)
                +M2(0, k, 0, s)*M2(0, n, 0, j)
                +M2(0, j, 0, s)*M2(0, k, 0, n))*I5D4sijk(ep, s, i, l, m);
      sum00 += ( M2(0, m, 0, s)*M2(0, j, 0, l)
                +M2(0, l, 0, s)*M2(0, m, 0, j)
                +M2(0, j, 0, s)*M2(0, l, 0, m))*I5D4sijk(ep, s, i, k, n);
      sum00 += ( M2(0, n, 0, s)*M2(0, j, 0, l)
                +M2(0, l, 0, s)*M2(0, n, 0, j)
                +M2(0, j, 0, s)*M2(0, l, 0, n))*I5D4sijk(ep, s, i, k, m);
      sum00 += ( M2(0, n, 0, s)*M2(0, j, 0, m)
                +M2(0, m, 0, s)*M2(0, n, 0, j)
                +M2(0, j, 0, s)*M2(0, m, 0, n))*I5D4sijk(ep, s, i, k, l);
      sum00 += ( M2(0, m, 0, s)*M2(0, k, 0, l)
                +M2(0, l, 0, s)*M2(0, m, 0, k)
                +M2(0, k, 0, s)*M2(0, l, 0, m))*I5D4sijk(ep, s, i, j, n);
      sum00 += ( M2(0, n, 0, s)*M2(0, k, 0, l)
                +M2(0, l, 0, s)*M2(0, n, 0, k)
                +M2(0, k, 0, s)*M2(0, l, 0, n))*I5D4sijk(ep, s, i, j, m);
      sum00 += ( M2(0, n, 0, s)*M2(0, k, 0, m)
                +M2(0, m, 0, s)*M2(0, n, 0, k)
                +M2(0, k, 0, s)*M2(0, m, 0, n))*I5D4sijk(ep, s, i, j, l);
      sum00 += ( M2(0, n, 0, s)*M2(0, l, 0, m)
                +M2(0, m, 0, s)*M2(0, n, 0, l)
                +M2(0, l, 0, s)*M2(0, m, 0, n))*I5D4sijk(ep, s, i, j, k);

      sum1 += M2(0, n, 0, s)*I5D5sijklm(ep, s, i, j, k, l, m)
             +M2(0, m, 0, s)*I5D5sijklm(ep, s, i, j, k, l, n)
             +M2(0, l, 0, s)*I5D5sijklm(ep, s, i, j, k, m, n)
             +M2(0, k, 0, s)*I5D5sijklm(ep, s, i, j, l, m, n)
             +M2(0, j, 0, s)*I5D5sijklm(ep, s, i, k, l, m, n)
             +M2(0, i, 0, s)*I5D5sijklm(ep, s, j, k, l, m, n);
    }
    const double d00 = M1(0, 0);
    pID6ijklmn[ep][iss(i-1,j-1,k-1,l-1,m-1,n-1)] = (sum1-(sum00-sum0000/d00)/d00)/(6.*d00);
  }
  }
  }
  }
  }
  }
  fEval[E_D6ijklmn+ep] = true;
}

/* Undefine local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 */

#undef pM1
#undef pM2
#undef pM3
#undef pM4
#undef evalM1
#undef evalM2
#undef evalM3
#undef evalM4
#undef DM1
#undef DM2
#undef DM3
#undef DM4
