/*
 * minor6.h - signed minors classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_MINOR6_H
#define QUL_MINOR6_H

#include "minor.h"
#include "minor5.h"
#include "entry.h"
#include "cache.h"

class Minor6 : public Minor<6>
{
  friend class Golem;
  public:
    friend class SPtr<Minor6>;
    typedef SPtr<Minor6> Ptr;
    static Ptr create(const Kinem6 &k) { return Ptr(new Minor6(k)); }

    virtual Tensor::Ptr Sub(int s) { assert(0<s && s<=N); return Tensor::Ptr(mnr5[s-1]); };

    ncomplex evalF(int ep);
    ncomplex evalF(int ep, int i);
    ncomplex evalF(int ep, int i, int j);
    ncomplex evalF(int ep, int i, int j, int k);
    ncomplex evalF(int ep, int i, int j, int k, int l);
    ncomplex evalF(int ep, int i, int j, int k, int l, int m);
    ncomplex evalF(int ep, int i, int j, int k, int l, int m, int n);

    virtual ncomplex A(int ep) { return ID0(ep); }
    virtual ncomplex A(int ep, int i) { return -IDi(ep, i); }
    virtual ncomplex A(int ep, int i, int j) { return ID2ij(ep, i, j); }
    virtual ncomplex A(int ep, int i, int j, int k) { return -ID3ijk(ep, i, j, k); }
    virtual ncomplex A(int ep, int i, int j, int k, int l) { return ID4ijkl(ep, i, j, k, l); }
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m) { return -ID5ijklm(ep, i, j, k, l, m); }
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m, int n) { return ID6ijklmn(ep, i, j, k, l, m, n); }

    virtual ncomplex B(int ep) { return 0.; }
    virtual ncomplex B(int ep, int k) { return 0.; }
    virtual ncomplex B(int ep, int k, int l) { return 0.; }
    virtual ncomplex B(int ep, int k, int l, int m) { return 0.; }
    virtual ncomplex B(int ep, int k, int l, int m, int n) { return 0.; }
    virtual ncomplex C(int ep) { return 0.; }
    virtual ncomplex C(int ep, int m) { return 0.; }
    virtual ncomplex C(int ep, int m, int n) { return 0.; }
    virtual ncomplex D(int ep) { return 0.; }

    virtual const ncomplex* Ai(int ep) { if (not fEval[E_Di+ep]) { IDiEval(ep); } return pIDi[ep]; }
    virtual const ncomplex* Aij(int ep) { if (not fEval[E_D2ij+ep]) { ID2ijEval(ep); } return pID2ij[ep]; }
    virtual const ncomplex* Aijk(int ep) { if (not fEval[E_D3ijk+ep]) { ID3ijkEval(ep); } return pID3ijk[ep]; }
    virtual const ncomplex* Aijkl(int ep) { if (not fEval[E_D4ijkl+ep]) { ID4ijklEval(ep); } return pID4ijkl[ep]; }
    virtual const ncomplex* Aijklm(int ep) { if (not fEval[E_D5ijklm+ep]) { ID5ijklmEval(ep); } return pID5ijklm[ep]; }
    virtual const ncomplex* Aijklmn(int ep) { if (not fEval[E_D6ijklmn+ep]) { ID6ijklmnEval(ep); } return pID6ijklmn[ep]; }

    ncomplex ID0(int ep) { if (pID0[ep].real() == Cache::sNAN) ID0Eval(ep); return pID0[ep]; }

    ncomplex IDi(int ep, int i);
    ncomplex ID2ij(int ep, int i, int j);
    ncomplex ID3ijk(int ep, int i, int j, int k);
    ncomplex ID4ijkl(int ep, int i, int j, int k, int l);
    ncomplex ID5ijklm(int ep, int i, int j, int k, int l, int m);
    ncomplex ID6ijklmn(int ep, int i, int j, int k, int l, int m, int n);

    double M1(int i, int l) PURE;
    double M2(int i, int j, int l, int m) PURE;
    double M3(int i, int j, int k, int l, int m, int n) PURE;

#define ix(i) (i<s ? i : i-1)
    inline ncomplex I5s(int ep, int s) { return mnr5[s-1]->ID0(ep); }
    inline ncomplex I5Ds(int ep, int s) { return mnr5[s-1]->ID1(ep); }
    inline ncomplex I5D2s(int ep, int s) { return mnr5[s-1]->ID2(ep); }
    inline ncomplex I5Dsi(int ep, int s, int i) { return s==i ? 0. : mnr5[s-1]->IDi(ep, ix(i)); }
    inline ncomplex I5D2si(int ep, int s, int i) { return s==i ? 0. : mnr5[s-1]->ID2i(ep, ix(i)); }
    inline ncomplex I5D3si(int ep, int s, int i) { return s==i ? 0. : mnr5[s-1]->ID3i(ep, ix(i)); }
    inline ncomplex I5D2sij(int ep, int s, int i, int j)
      { return (s==i || s==j) ? 0. : mnr5[s-1]->ID2ij(ep, ix(i), ix(j)); }
    inline ncomplex I5D3sij(int ep, int s, int i, int j)
      { return (s==i || s==j) ? 0. : mnr5[s-1]->ID3ij(ep, ix(i), ix(j)); }
    inline ncomplex I5D3sijk(int ep, int s, int i, int j, int k)
      { return (s==i || s==j || s==k) ? 0. : mnr5[s-1]->ID3ijk(ep, ix(i), ix(j), ix(k)); }
    inline ncomplex I5D4sijk(int ep, int s, int i, int j, int k)
      { return (s==i || s==j || s==k) ? 0. : mnr5[s-1]->ID4ijk(ep, ix(i), ix(j), ix(k)); }
    inline ncomplex I5D4sijkl(int ep, int s, int i, int j, int k, int l)
      { return (s==i || s==j || s==k || s==l) ? 0. : mnr5[s-1]->ID4ijkl(ep, ix(i), ix(j), ix(k), ix(l)); }
    inline ncomplex I5D5sijklm(int ep, int s, int i, int j, int k, int l, int m)
      { return (s==i || s==j || s==k || s==l || s==m) ? 0. : mnr5[s-1]->ID5ijklm(ep, ix(i), ix(j), ix(k), ix(l), ix(m)); }
#undef ix

  private:
    Minor6(const Kinem6 &k);                        // prevent direct creation
    Minor6(const Minor6 &m) { assert(0); }   // prevent copy-constructing
    Minor6& operator= (const Minor6& m) { assert(0); } // prevent reassignment

    Kinem6 kinem;

    // flags marking evuation steps
    enum EvalM {E_None=0,
                E_M1, E_M2, E_M3,
                                                                                   E_D6ijklmn,
                                                                         E_D5ijklm=E_D6ijklmn+3,
                                                                E_D4ijkl=E_D5ijklm+3,
                                                        E_D4ijk=E_D4ijkl+3,
                                                 E_D4ij=E_D4ijk+3,
                                         E_D3ijk=E_D4ij+3,
                                  E_D3ij=E_D3ijk+3,
                            E_D3i=E_D3ij+3,
                     E_D2ij=E_D3i+3,
               E_D2i=E_D2ij+3,
          E_Di=E_D2i+3,
    E_DUM=E_Di+3,
    E_LEN};
    std::bitset<E_LEN> fEval;

    // internally we use rank-notation, ranks 2 and 3 are defined in Minor<N>
    void evalRM4();
    void evalRM5();
    void evalRM6();
    static const int RM4=35;   // Binomial[DCay,DCay-R] = Binomial[7,3]
    static const int RM5=21;   // Binomial[DCay,DCay-R] = Binomial[7,2]
    static const int RM6=7;    // Binomial[DCay,DCay-R] = Binomial[7,1]
    double rrM4[RM4*(RM4+1)/2];
    double rrM5[RM5*(RM5+1)/2];
    double rrM6[RM6*(RM6+1)/2];

    void ID0Eval(int ep);
    void IDiEval(int ep);
    void ID2ijEval(int ep);
    void ID3ijkEval(int ep);
    void ID4ijklEval(int ep);
    void ID5ijklmEval(int ep);
    void ID6ijklmnEval(int ep);

    // Integral values
    ncomplex pID0[3];
    ncomplex pIDi[3][CIDX];
    ncomplex pID2ij[3][CIDX*(CIDX+1)/2];                                            // symm 6x6
    ncomplex pID3ijk[3][CIDX*(CIDX+1)*(CIDX+2)/6];                                  // symm 6x6x6
    ncomplex pID4ijkl[3][CIDX*(CIDX+1)*(CIDX+2)*(CIDX+3)/24];                       // symm 6x6x6x6
    ncomplex pID5ijklm[3][CIDX*(CIDX+1)*(CIDX+2)*(CIDX+3)*(CIDX+4)/120];            // symm 6x6x6x6x6
    ncomplex pID6ijklmn[3][CIDX*(CIDX+1)*(CIDX+2)*(CIDX+3)*(CIDX+4)*(CIDX+5)/720];  // symm 6x6x6x6x6x6

    Minor5::Ptr mnr5[N];
};

typedef Entry< Kinem6, Minor6::Ptr > MEntry6;

#endif /* QUL_MINOR6_H */
