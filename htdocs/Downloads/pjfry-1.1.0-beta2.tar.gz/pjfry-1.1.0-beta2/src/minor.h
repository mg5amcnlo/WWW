/*
 * minor.h - signed minors classes
 *
 * this file is part of PJFry library
 * Copyright 2012 Valery Yundin
 */

#ifndef QUL_MINORN_H
#define QUL_MINORN_H

#include "common.h"
#include "tensor.h"
#include "pointer.h"
#include "kinem.h"

#include <bitset>

#define EPSCAP(expr) (ep < 2 ? (expr) : 0.)

// one step of Wynn epsilon improvement
#define stepWynn(n) \
  sum[(2+n)%3]=sum1; \
  { \
    const ncomplex s2=sum[(2+n)%3]; \
    const ncomplex s1=sum[(1+n)%3]; \
    const ncomplex s10=s21; \
    s21=s2-s1; \
    if (   s21==s10 \
        || (   fabs(s2.real()*heps)>=fabs(s21.real()) \
            && fabs(s2.imag()*heps)>=fabs(s21.imag()) ) ) \
        break; \
    dv=sump; \
    sump=s1+1./(1./s21-1./s10); \
  } \
  if (   fabs(sump.real()*teps)>=fabs(sump.real()-dv.real()) \
      && fabs(sump.imag()*teps)>=fabs(sump.imag()-dv.imag()) ) \
      break;
// -------------


#ifndef USE_ZERO_CHORD
/* if zero chord is not used - calculate only 4 form factors for 5-point */
#   define CIDX (N-1)
#else
/* else calculate all (including coefficient of 0'th chord) */
#   define CIDX (N)
#endif

template<int N>
struct MinorLEN {
  // DMi = Binomial[N,N-i]
};

template<>
struct MinorLEN<6> {
  static const int RM2=21; // Binomial[7,5] = 21
  static const int RM3=35; // Binomial[7,4] = 35
//   static const int RM4=35; // Binomial[7,3] = 7*6*5/3! = 35
//   static const int RM5=21; // Binomial[7,2] = 21
//   static const int RM6=7;  // Binomial[7,1] = 7
};

template<>
struct MinorLEN<5> {
  static const int RM2=15; // Binomial[6,4] = 15
  static const int RM3=20; // Binomial[6,3] = 6*5*4/3! = 20
//   static const int RM4=15; // Binomial[6,2] = 15
//   static const int RM5=6;  // Binomial[6,1] = 6
//   static const int RM6=1;  // Binomial[6,0]
};


template<>
struct MinorLEN<4> {
  static const int RM2=10;  // Binomial[5,3]
  static const int RM3=10;  // Binomial[5,2]
//   static const int RM4=5;  // Binomial[5,1]
//   static const int RM5=1;  // Binomial[5,0]
//   static const int RM6=1;  // Binomial[5,0]
};

template<>
struct MinorLEN<3> {
  static const int RM2=6;  // Binomial[4,2]
  static const int RM3=4;  // Binomial[4,1]
//   static const int RM4=1;  // Binomial[4,0]
//   static const int RM5=1;  // Binomial[4,0]
//   static const int RM6=1;  // Binomial[4,0]
};

template<>
struct MinorLEN<2> {
  static const int RM2=3;  // Binomial[3,1]
  static const int RM3=1;  // Binomial[3,0]
//   static const int RM4=1;  // Binomial[3,0]
//   static const int RM5=1;  // Binomial[3,0]
//   static const int RM6=1;  // Binomial[3,0]
};

class MinorBase : public Tensor
{
  public:
    MinorBase() {}

#define EVALUNDEF return std::numeric_limits<double>::signaling_NaN();
    virtual ncomplex A(int ep) { EVALUNDEF }
    virtual ncomplex A(int ep, int i) { EVALUNDEF }
    virtual ncomplex A(int ep, int i, int j) { EVALUNDEF }
    virtual ncomplex A(int ep, int i, int j, int k) { EVALUNDEF }
    virtual ncomplex A(int ep, int i, int j, int k, int l) { EVALUNDEF }
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m) { EVALUNDEF }
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m, int n) { EVALUNDEF }
    virtual ncomplex B(int ep) { EVALUNDEF }
    virtual ncomplex B(int ep, int i) { EVALUNDEF; }
    virtual ncomplex B(int ep, int i, int j) { EVALUNDEF }
    virtual ncomplex B(int ep, int i, int j, int k) { EVALUNDEF }
    virtual ncomplex B(int ep, int i, int j, int k, int l) { EVALUNDEF }
    virtual ncomplex C(int ep) { EVALUNDEF }
    virtual ncomplex C(int ep, int i) { EVALUNDEF }
    virtual ncomplex C(int ep, int i, int j) { EVALUNDEF }
    virtual ncomplex D(int ep) { EVALUNDEF }
#undef EVALUNDEF

    virtual const ncomplex* Ai(int ep) { return 0; }
    virtual const ncomplex* Aij(int ep) { return 0; }
    virtual const ncomplex* Aijk(int ep) { return 0; }
    virtual const ncomplex* Aijkl(int ep) { return 0; }
    virtual const ncomplex* Aijklm(int ep) { return 0; }
    virtual const ncomplex* Aijklmn(int ep) { return 0; }
    virtual const ncomplex* Bi(int ep) { return 0; }
    virtual const ncomplex* Bij(int ep) { return 0; }
    virtual const ncomplex* Bijk(int ep) { return 0; }
    virtual const ncomplex* Bijkl(int ep) { return 0; }
    virtual const ncomplex* Ci(int ep) { return 0; }
    virtual const ncomplex* Cij(int ep) { return 0; }

    // TODO: move index classes to a namespace
    // Symmetric index - start from 1
    inline static int ns(int i, int j) CONST {
      return ( i<=j ? (i-1)+((j-1)*j)/2 : (j-1)+((i-1)*i)/2 );
    }

    inline static int nss(int i, int j) CONST { // ordered
      assert(i<=j);
      assert(i>=1 && j>=1);
      return (i-1)+((j-1)*j)/2;
    }

    // Symmetric index - generic
    inline static int is(int i, int j) CONST {
      return ( i<=j ? i+j*(j+1)/2 : j+i*(i+1)/2 );
    }

    inline static int is(int i, int j, int k) CONST {
      if (i <= j) {
        return (j <= k ? i+ti2[j]+ti3[k] : is(i,k)+ti3[j]);
      }
      else {
        return (i >  k ? is(j,k)+ti3[i] : j+ti2[i]+ti3[k]);
      }
    }

    inline static int is(int i, int j, int k, int l) CONST {
      if (i <= j) {
        if (j <= k) {
          return (k <= l ? i+ti2[j]+ti3[k]+ti4[l]
                         : is(i,j,l)+ti4[k]  );
        }
        else {
          return (j >  l ? is(i,k,l)+ti4[j]
                         : is(i,k)+ti3[j]+ti4[l]  );
        }
      }
      else {
        if (i > k) {
          return (i >  l ? is(j,k,l)+ti4[i]
                         : is(j,k)+ti3[i]+ti4[l]  );
        }
        else {
          return (k <= l ? j+ti2[i]+ti3[k]+ti4[l]
                         : is(i,j,l)+ti4[k]  );
        }
      }
    }

    inline static int iss(int i, int j) CONST { // ordered
      assert(i<=j);
      return i+j*(j+1)/2;
    }

    inline static int iss(int i, int j, int k) CONST { // ordered
      assert(i <= j && j <= k);
      return i+ti2[j]+ti3[k];
    }

    inline static int iss(int i, int j, int k, int l) CONST { // ordered
      assert(i <= j && j <= k && k <= l);
      return i+ti2[j]+ti3[k]+ti4[l];
    }

    inline static int iss(int i, int j, int k, int l, int m) CONST { // ordered
      assert(i <= j && j <= k && k <= l && l <= m);
      return i+ti2[j]+ti3[k]+ti4[l]+ti5[m];
    }

    inline static int iss(int i, int j, int k, int l, int m, int n) CONST { // ordered
      assert(i <= j && j <= k && k <= l && l <= m && m <= n);
      return i+ti2[j]+ti3[k]+ti4[l]+ti5[m]+ti6[n];
    }

    inline static double getmeps() {
      return meps;
    }

    static const unsigned char idxtbl[128];

    // Utility functions
    static int im4(const int i, const int j,
                   const int k, const int l) CONST; // Antisymmetric index (0-based)
    static int im3(const int i, const int j,
                   const int k) CONST;              // Antisymmetric index (0-based)
    static int im2(const int i, const int j) CONST; // Antisymmetric index (0-based)
    static int in4(const int i, const int j,
                   const int k, const int l) CONST; // Antisymmetric index (1-based)
    static int in3(const int i, const int j,
                   const int k) CONST;              // Antisymmetric index (1-based)
    static int in2(const int i, const int j) CONST; // Antisymmetric index (1-based)
    static int trisign(const int n) CONST;
    static int signM3ud(const int i, const int j,
                        const int k, const int l,
                        const int m, const int n) CONST; // Signature[{i,j,k}]*Signature[{l,m,n}]
    static int signM2ud(const int i, const int j,
                        const int l, const int m) CONST; // Signature[{i,j}]*Signature[{l,m}]

    static void Rescale(double factor);

  private:
    static const int ti2[8];
    static const int ti3[8];
    static const int ti4[8];
    static const int ti5[8];
    static const int ti6[8];
    static const int ti7[8];

  protected:
    static const double teps; // expansion target accuracy
    static const double heps; // near double precision eps

    static const double ceps;

    static const double deps1;
    static const double deps2;
    static const double deps3;

    static const double seps1; // two-point cutoff
    static const double seps2; // two-point cutoff

    static const double epsirt; // 3-point IR thresh
    static const double epsiru; // 3-point IR cutoff

    static const double epsir1; // 3-point quasi IR cutoff
    static const double epsir2; // 3-point quasi IR cutoff

    static double deps;
    static double meps; // onshell cutoff
    static double m3eps; // I3 IR cutoff
};

template <int NN>
class Minor : public MinorBase
{
  public:
    Minor() {}

    inline double Kay(int i, int j) PURE {
      if (i==0) {
        return j==0 ? 0. : 1.;
      } else {
        return j==0 ? 1. : Cay[ns(i,j)];
      }
    }

  protected:
    // Cayley matrix (symmetric)
    static const int N = NN;
    static const int DCay = N+1;
    double Cay[(DCay-1)*(DCay)/2];

    void evalRM2();
    void evalRM3();

    static const int RM2 = MinorLEN<NN>::RM2;
    static const int RM3 = MinorLEN<NN>::RM3;

    double rrM2[RM2*(RM2+1)/2];
    double rrM3[RM3*(RM3+1)/2];
};


/* ===============================================
 *
 *               Utility functions
 *
 * ===============================================
 */

// Completely antisymmetric i,j,k,l matrix index (0-based)
inline
int MinorBase::im4(const int i, const int j, const int k, const int l)
{
  assert( i!=j && i!=k && i!=l && j!=k && j!=l && k!=l );
  return idxtbl[(1<<i)|(1<<j)|(1<<k)|(1<<l)];
}

// Completely antisymmetric i,j,k matrix index (0-based)
inline
int MinorBase::im3(const int i, const int j, const int k)
{
  assert( i!=j && i!=k && j!=k );
  return idxtbl[(1<<i)|(1<<j)|(1<<k)];
}

// Completely antisymmetric i,j matrix index (0-based)
inline
int MinorBase::im2(const int i, const int j)
{
  assert( i!=j );
  return idxtbl[(1<<i)|(1<<j)];
}

// Completely antisymmetric i,j,k,l matrix index (1-based)
inline
int MinorBase::in4(const int i, const int j, const int k, const int l)
{
  assert( i!=j && i!=k && i!=l && j!=k && j!=l && k!=l );
  return idxtbl[((1<<i)|(1<<j)|(1<<k)|(1<<l))>>1];
}

// Completely antisymmetric i,j,k matrix index (1-based)
inline
int MinorBase::in3(const int i, const int j, const int k)
{
  assert( i!=j && i!=k && j!=k && i>0 && j>0 && k>0 );
  return idxtbl[((1<<i)|(1<<j)|(1<<k))>>1];
}

// Completely antisymmetric i,j matrix index (1-based)
inline
int MinorBase::in2(const int i, const int j)
{
  assert( i!=j && i>0 && j>0 );
  return idxtbl[((1<<i)|(1<<j))>>1];
}

// n == 0 -> 0, n > 0 -> 1, n < 0 -> -1
inline
int MinorBase::trisign(const int n)
{
  const int shift = sizeof(unsigned int)*8-1;
  return 1-(((unsigned int)n)>>shift)-(((unsigned int)(n-1))>>shift);
}

// Signature[{i,j,k}]*Signature[{l,m,n}]
inline
int MinorBase::signM3ud(const int i, const int j, const int k,
                        const int l, const int m, const int n)
{
  const int t=(j-i)*(k-j)*(k-i)*(m-l)*(n-m)*(n-l);
  return trisign(t);
}

// Signature[{i,j}]*Signature[{l,m}]
inline
int MinorBase::signM2ud(const int i, const int j, const int l, const int m)
{
  const int t=(j-i)*(m-l);
  return trisign(t);
}

#endif /* QUL_MINORN_H */
