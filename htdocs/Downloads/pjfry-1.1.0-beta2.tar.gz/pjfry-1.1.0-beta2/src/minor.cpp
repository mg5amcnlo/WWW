/*
 * minor.cpp - constructors, signed minors and integrals
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "minor.h"

// tiN[K] = (N+K-1)!/N!/(K-1)!
const int MinorBase::ti2[8] = {0, 1, 3, 6, 10, 15, 21, 28};
const int MinorBase::ti3[8] = {0, 1, 4, 10, 20, 35, 56, 84};
const int MinorBase::ti4[8] = {0, 1, 5, 15, 35, 70, 126, 210};
const int MinorBase::ti5[8] = {0, 1, 6, 21, 56, 126, 252, 462};
const int MinorBase::ti6[8] = {0, 1, 7, 28, 84, 210, 462, 924};
const int MinorBase::ti7[8] = {0, 1, 8, 36, 120, 330, 792, 1716};

const double MinorBase::teps=1e-14;  // wynn eps-algo safety threshold
const double MinorBase::heps=1e-15;  // wynn eps-algo safety threshold

const double MinorBase::ceps=5e-2;

const double MinorBase::deps1=5e-2;
const double MinorBase::deps2=5e-2;
const double MinorBase::deps3=5e-2;

const double MinorBase::seps1=1e-8;
const double MinorBase::seps2=1e-5;

double MinorBase::deps=1e-14;
double MinorBase::meps=1e-10;
double MinorBase::m3eps=1;

void MinorBase::Rescale(double factor)
{
  meps*=factor;
  m3eps*=factor*factor;
}

const unsigned char MinorBase::idxtbl[128]={
    0,  //   0         0b0
    0,  //   1         0b1
    1,  //   2        0b10
    0,  //   3        0b11
    2,  //   4       0b100
    1,  //   5       0b101
    2,  //   6       0b110
    0,  //   7       0b111
    3,  //   8      0b1000
    3,  //   9      0b1001
    4,  //  10      0b1010
    1,  //  11      0b1011
    5,  //  12      0b1100
    2,  //  13      0b1101
    3,  //  14      0b1110
    0,  //  15      0b1111
    4,  //  16     0b10000
    6,  //  17     0b10001
    7,  //  18     0b10010
    4,  //  19     0b10011
    8,  //  20     0b10100
    5,  //  21     0b10101
    6,  //  22     0b10110
    1,  //  23     0b10111
    9,  //  24     0b11000
    7,  //  25     0b11001
    8,  //  26     0b11010
    2,  //  27     0b11011
    9,  //  28     0b11100
    3,  //  29     0b11101
    4,  //  30     0b11110
    0,  //  31     0b11111
    5,  //  32    0b100000
   10,  //  33    0b100001
   11,  //  34    0b100010
   10,  //  35    0b100011
   12,  //  36    0b100100
   11,  //  37    0b100101
   12,  //  38    0b100110
    5,  //  39    0b100111
   13,  //  40    0b101000
   13,  //  41    0b101001
   14,  //  42    0b101010
    6,  //  43    0b101011
   15,  //  44    0b101100
    7,  //  45    0b101101
    8,  //  46    0b101110
    1,  //  47    0b101111
   14,  //  48    0b110000
   16,  //  49    0b110001
   17,  //  50    0b110010
    9,  //  51    0b110011
   18,  //  52    0b110100
   10,  //  53    0b110101
   11,  //  54    0b110110
    2,  //  55    0b110111
   19,  //  56    0b111000
   12,  //  57    0b111001
   13,  //  58    0b111010
    3,  //  59    0b111011
   14,  //  60    0b111100
    4,  //  61    0b111101
    5,  //  62    0b111110
    0,  //  63    0b111111
    6,  //  64   0b1000000
   15,  //  65   0b1000001
   16,  //  66   0b1000010
   20,  //  67   0b1000011
   17,  //  68   0b1000100
   21,  //  69   0b1000101
   22,  //  70   0b1000110
   15,  //  71   0b1000111
   18,  //  72   0b1001000
   23,  //  73   0b1001001
   24,  //  74   0b1001010
   16,  //  75   0b1001011
   25,  //  76   0b1001100
   17,  //  77   0b1001101
   18,  //  78   0b1001110
    6,  //  79   0b1001111
   19,  //  80   0b1010000
   26,  //  81   0b1010001
   27,  //  82   0b1010010
   19,  //  83   0b1010011
   28,  //  84   0b1010100
   20,  //  85   0b1010101
   21,  //  86   0b1010110
    7,  //  87   0b1010111
   29,  //  88   0b1011000
   22,  //  89   0b1011001
   23,  //  90   0b1011010
    8,  //  91   0b1011011
   24,  //  92   0b1011100
    9,  //  93   0b1011101
   10,  //  94   0b1011110
    1,  //  95   0b1011111
   20,  //  96   0b1100000
   30,  //  97   0b1100001
   31,  //  98   0b1100010
   25,  //  99   0b1100011
   32,  // 100   0b1100100
   26,  // 101   0b1100101
   27,  // 102   0b1100110
   11,  // 103   0b1100111
   33,  // 104   0b1101000
   28,  // 105   0b1101001
   29,  // 106   0b1101010
   12,  // 107   0b1101011
   30,  // 108   0b1101100
   13,  // 109   0b1101101
   14,  // 110   0b1101110
    2,  // 111   0b1101111
   34,  // 112   0b1110000
   31,  // 113   0b1110001
   32,  // 114   0b1110010
   15,  // 115   0b1110011
   33,  // 116   0b1110100
   16,  // 117   0b1110101
   17,  // 118   0b1110110
    3,  // 119   0b1110111
   34,  // 120   0b1111000
   18,  // 121   0b1111001
   19,  // 122   0b1111010
    4,  // 123   0b1111011
   20,  // 124   0b1111100
    5,  // 125   0b1111101
    6,  // 126   0b1111110
    0,  // 127   0b1111111
};

template <int NN>
void Minor<NN>::evalRM2()
{
#ifndef NDEBUG
  for (int i=0; i<RM2*(RM2+1)/2; i++) { rrM2[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif
  const unsigned int mask = (1<<DCay)-1;
  { const int i=0;                  const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-1; j++) { const unsigned int bj = 1<<j;
    const unsigned int uidx = idxtbl[mask&(~(bi|bj))];
    { const int l=0;                  const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int lidx = idxtbl[mask&(~(bl|bm))];
      if (lidx > uidx) continue;
      rrM2[iss(lidx,uidx)] = -1.;
    }
    }
    for (int l=1;   l<=DCay-2; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int lidx = idxtbl[mask&(~(bl|bm))];
      if (lidx > uidx) continue;
      rrM2[iss(lidx,uidx)] = Cay[ns(j,m)] - Cay[ns(j,l)];
    }
    }
  }
  }
  for (int i=1;   i<=DCay-2; i++) { const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-1; j++) { const unsigned int bj = 1<<j;
    const unsigned int uidx = idxtbl[mask&(~(bi|bj))];
    { const int l=0;                  const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int lidx = idxtbl[mask&(~(bl|bm))];
      if (lidx > uidx) continue;
      rrM2[iss(lidx,uidx)] = Cay[ns(j,m)] - Cay[ns(i,m)];
    }
    }
    for (int l=1;   l<=DCay-2; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int lidx = idxtbl[mask&(~(bl|bm))];
      if (lidx > uidx) continue;
      rrM2[iss(lidx,uidx)] = Cay[ns(i,l)]*Cay[ns(j,m)] - Cay[ns(j,l)]*Cay[ns(i,m)];
    }
    }
  }
  }
}

template <int NN>
void Minor<NN>::evalRM3()
{
  evalRM2();
#ifndef NDEBUG
  for (int i=0; i<RM3*(RM3+1)/2; i++) { rrM3[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif

  const unsigned int mask = (1<<DCay)-1;
  for (int i=0;   i<=DCay-3; i++) { const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-2; j++) { const unsigned int bj = 1<<j;
  for (int k=j+1; k<=DCay-1; k++) { const unsigned int bk = 1<<k;
    const unsigned int uidx = idxtbl[mask&(~(bi|bj|bk))];
    for (int l=0;   l<=DCay-3; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-2; m++) { const unsigned int bm = 1<<m;
    for (int n=m+1; n<=DCay-1; n++) { const unsigned int bn = 1<<n;
      const unsigned int lidx = idxtbl[mask&(~(bl|bm|bn))];
      if (lidx > uidx) continue;

      double m3ele;
      if (i==0) {
        const int ui = idxtbl[mask&(~(bj|bk))];
        m3ele = l==0 ? 0. : rrM2[is(ui,idxtbl[mask&(~(bm|bn))])];
        m3ele += + rrM2[is(ui,idxtbl[mask&(~(bl|bm))])]
                 - rrM2[is(ui,idxtbl[mask&(~(bl|bn))])];
      } else if (l==0) {
        const int di = idxtbl[mask&(~(bm|bn))];
        m3ele = rrM2[is(di,idxtbl[mask&(~(bi|bj))])]
              - rrM2[is(di,idxtbl[mask&(~(bi|bk))])]
              + rrM2[is(di,idxtbl[mask&(~(bj|bk))])];
      } else {
        // i!=0 && l!=0 using Cay instead of Kay
        const int ui = idxtbl[mask&(~(bj|bk))];
        m3ele = Cay[ns(i,n)]*rrM2[is(ui,idxtbl[mask&(~(bl|bm))])]
              - Cay[ns(i,m)]*rrM2[is(ui,idxtbl[mask&(~(bl|bn))])]
              + Cay[ns(i,l)]*rrM2[is(ui,idxtbl[mask&(~(bm|bn))])];
      }
      int powsign = -2*((i+j+k+l+m+n)&0x1)+1;
      rrM3[iss(lidx,uidx)] = powsign*m3ele;
    }
    }
    }
  }
  }
  }
}

template class Minor<6>;
template class Minor<5>;
template class Minor<4>;
template class Minor<3>;
template class Minor<2>;
