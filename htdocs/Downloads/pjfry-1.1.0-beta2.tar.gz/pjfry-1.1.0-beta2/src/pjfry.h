/*
 * pjfry.h - interface header
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_PJFRY_H
#define QUL_PJFRY_H

/* if language is C++ use standard complex template type */
#ifdef __cplusplus
#   include <complex>
#   define QUL_DEFINE_COMPLEX(R, C) typedef std::complex<R> C
#else
/* if <complex.h> is included, use the C99 complex type.
 * else define a type bit-compatible with C99 complex */
#   if defined(_Complex_I) && defined(complex) && defined(I)
#       define QUL_DEFINE_COMPLEX(R, C) typedef R _Complex C
#   else
#       define QUL_DEFINE_COMPLEX(R, C) typedef struct { R re,im; } C
#   endif
#endif

QUL_DEFINE_COMPLEX(double, pj_complex);

#ifdef __cplusplus

#ifdef PJFRY_NATIVE
#include "tensor.h"
namespace PJFry {
  Tensor::Ptr Tensor1(double m1);
  Tensor::Ptr Tensor2(double p1, double m1,  double m2);
  Tensor::Ptr Tensor3(double p1,  double p2,  double p3,
                      double m1,  double m2,  double m3);
  Tensor::Ptr Tensor4(double p1,  double p2,  double p3,  double p4,
                      double s12, double s23,
                      double m1,  double m2,  double m3,  double m4);
  Tensor::Ptr Tensor5(double p1,  double p2,  double p3,  double p4,  double p5,
                      double s12, double s23, double s34, double s45, double s15,
                      double m1,  double m2,  double m3,  double m4,  double m5);
  Tensor::Ptr Tensor6(double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                      double s12, double s23, double s34, double s45, double s56, double s16,
                      double s234, double s345, double s456,
                      double m1,  double m2,  double m3,  double m4,  double m5,  double m6);
}
#endif

namespace PJFry {
    // Functions without explicit epsilon default to eps=0
    pj_complex F0v0(double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex F0v1(int i,
                    double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex F0v2(int i, int j,
                    double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex F0v3(int i, int j, int k,
                    double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex F0v4(int i, int j, int k, int l,
                    double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex F0v5(int i, int j, int k, int l, int m,
                    double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex F0v6(int i, int j, int k, int l, int m, int n,
                    double p1,  double p2,  double p3,  double p4,  double p5,  double p6,
                    double s12, double s23, double s34, double s45, double s56, double s16,
                    double s234, double s345, double s456,
                    double m6,  double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);

    pj_complex E0v0(double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex E0v1(int i,
                    double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex E0v2(int i, int j,
                    double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex E0v3(int i, int j, int k,
                    double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex E0v4(int i, int j, int k, int l,
                    double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);
    pj_complex E0v5(int i, int j, int k, int l, int m,
                    double p1,  double p2,  double p3,  double p4,  double p5,
                    double s12, double s23, double s34, double s45, double s15,
                    double m1,  double m2,  double m3,  double m4,  double m5, int ep=0);

    pj_complex D0v0(double p1,  double p2,  double p3,  double p4,
                    double s12, double s23,
                    double m1,  double m2,  double m3,  double m4, int ep=0);
    pj_complex D0v1(int i,
                    double p1,  double p2,  double p3,  double p4,
                    double s12, double s23,
                    double m1,  double m2,  double m3,  double m4, int ep=0);
    pj_complex D0v2(int i, int j,
                    double p1,  double p2,  double p3,  double p4,
                    double s12, double s23,
                    double m1,  double m2,  double m3,  double m4, int ep=0);
    pj_complex D0v3(int i, int j, int k,
                    double p1,  double p2,  double p3,  double p4,
                    double s12, double s23,
                    double m1,  double m2,  double m3,  double m4, int ep=0);
    pj_complex D0v4(int i, int j, int k, int l,
                    double p1,  double p2,  double p3,  double p4,
                    double s12, double s23,
                    double m1,  double m2,  double m3,  double m4, int ep=0);

    pj_complex C0v0(double p1, double p2, double p3,
                    double m1, double m2, double m3, int ep=0);
    pj_complex C0v1(int i,
                    double p1, double p2, double p3,
                    double m1, double m2, double m3, int ep=0);
    pj_complex C0v2(int i, int j,
                    double p1, double p2, double p3,
                    double m1, double m2, double m3, int ep=0);
    pj_complex C0v3(int i, int j, int k,
                    double p1, double p2, double p3,
                    double m1, double m2, double m3, int ep=0);

    pj_complex B0v0(double p1, double m1, double m2, int ep=0);
    pj_complex B0v1(int i,
                    double p1, double m1, double m2, int ep=0);
    pj_complex B0v2(int i, int j,
                    double p1, double m1, double m2, int ep=0);
    pj_complex B0v3(int i, int j, int k,
                    double p1, double m1, double m2, int ep=0);

    pj_complex A0v0(double m1, int ep=0);

    double GetMu2();
    double SetMu2(double newmu2);
    void ClearCache();
}
#endif /* __cplusplus */


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void pmloop_(int *n, int *rank, double *pl, double *pden, double *m2l, double *mur,
             pj_complex *coefs, bool *stable);

double pgetmusq_();
void psetmusq_(double *mu2);
void pclearcache_();

#ifdef USE_F2C
/* f2c,g77,ifort calling convention section (result is the first parameter) */
void pa0_(pj_complex *rslt, double *m1, int *ep);

void pb0_(pj_complex *rslt, double *p1, double *m1, double *m2, int *ep);
void pb0i_(pj_complex *rslt, int *i,
                double *p1, double *m1, double *m2, int *ep);
void pb0ij_(pj_complex *rslt, int *i, int *j,
                double *p1, double *m1, double *m2, int *ep);

void pc0_(pj_complex *rslt, double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);
void pc0i_(pj_complex *rslt, int *i,
                double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);
void pc0ij_(pj_complex *rslt, int *i, int *j,
                double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);
void pc0ijk_(pj_complex *rslt, int *i, int *j, int *k,
                double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);

void pd0_(pj_complex *rslt, double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
void pd0i_(pj_complex *rslt, int *i,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
void pd0ij_(pj_complex *rslt, int *i, int *j,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
void pd0ijk_(pj_complex *rslt, int *i, int *j, int *k,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
void pd0ijkl_(pj_complex *rslt, int *i, int *j, int *k, int *l,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);

void pe0_(pj_complex *rslt, double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
void pe0i_(pj_complex *rslt, int *i,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
void pe0ij_(pj_complex *rslt, int *i, int *j,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
void pe0ijk_(pj_complex *rslt, int *i, int *j, int *k,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
void pe0ijkl_(pj_complex *rslt, int *i, int *j, int *k, int *l,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
void pe0ijklm_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *m,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
#else /* USE_F2C */
/* GNU calling convention section (result is a complex return value) */
pj_complex pa0_(double *m1, int *ep);

pj_complex pb0_(double *p1, double *m1, double *m2, int *ep);
pj_complex pb0i_(int *i,
                double *p1, double *m1, double *m2, int *ep);
pj_complex pb0ij_(int *i, int *j,
                double *p1, double *m1, double *m2, int *ep);

pj_complex pc0_(double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);
pj_complex pc0i_(int *i,
                double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);
pj_complex pc0ij_(int *i, int *j,
                double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);
pj_complex pc0ijk_(int *i, int *j, int *k,
                double *p1, double *p2, double *p3, double *m1, double *m2, double *m3, int *ep);

pj_complex pd0_(double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
pj_complex pd0i_(int *i,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
pj_complex pd0ij_(int *i, int *j,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
pj_complex pd0ijk_(int *i, int *j, int *k,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);
pj_complex pd0ijkl_(int *i, int *j, int *k, int *l,
                double *p1, double *p2, double *p3, double *p4, double *s12, double *s23, double *m1, double *m2, double *m3, double *m4, int *ep);

pj_complex pe0_(double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
pj_complex pe0i_(int *i,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
pj_complex pe0ij_(int *i, int *j,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
pj_complex pe0ijk_(int *i, int *j, int *k,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
pj_complex pe0ijkl_(int *i, int *j, int *k, int *l,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
pj_complex pe0ijklm_(int *i, int *j, int *k, int *l, int *m,
                double *p1, double *p2, double *p3, double *p4, double *p5, double *s12, double *s23, double *s34, double *s45, double *s15, double *m1, double *m2, double *m3, double *m4, double *m5, int *ep);
#endif /* USE_F2C */

  double pggetmusq_();
  void pgsetmusq_(double *mu2);

  void pginitgolem95_(int *n);
  double pggetmat_(int *i, int *j);
  void pgpreparesmatrix_();
  void pgsetmat_(int *i, int *j, double *val);


#ifdef USE_F2C
/* f2c,g77,ifort calling convention section (result is the first parameter) */
  void pga0_(pj_complex *rslt, int *s, int *ep);
  void pga1_(pj_complex *rslt, int *i, int *s, int *ep);
  void pga2_(pj_complex *rslt, int *i, int *j, int *s, int *ep);
  void pgb2_(pj_complex *rslt, int *s, int *ep);
  void pga3_(pj_complex *rslt, int *i, int *j, int *k, int *s, int *ep);
  void pgb3_(pj_complex *rslt, int *i, int *s, int *ep);
  void pga4_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *s, int *ep);
  void pgb4_(pj_complex *rslt, int *i, int *j, int *s, int *ep);
  void pgc4_(pj_complex *rslt, int *s, int *ep);
  void pga5_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *m, int *s, int *ep);
  void pgb5_(pj_complex *rslt, int *i, int *j, int *k, int *s, int *ep);
  void pgc5_(pj_complex *rslt, int *i, int *s, int *ep);
  void pga6_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *m, int *n, int *s, int *ep);
  void pgb6_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *s, int *ep);
  void pgc6_(pj_complex *rslt, int *i, int *j, int *s, int *ep);
#else /* USE_F2C */
/* GNU calling convention section (result is a complex return value) */
  pj_complex pga0_(int *s, int *ep);
  pj_complex pga1_(int *i, int *s, int *ep);
  pj_complex pga2_(int *i, int *j, int *s, int *ep);
  pj_complex pgb2_(int *s, int *ep);
  pj_complex pga3_(int *i, int *j, int *k, int *s, int *ep);
  pj_complex pgb3_(int *i, int *s, int *ep);
  pj_complex pga4_(int *i, int *j, int *k, int *l, int *s, int *ep);
  pj_complex pgb4_(int *i, int *j, int *s, int *ep);
  pj_complex pgc4_(int *s, int *ep);
  pj_complex pga5_(int *i, int *j, int *k, int *l, int *m, int *s, int *ep);
  pj_complex pgb5_(int *i, int *j, int *k, int *s, int *ep);
  pj_complex pgc5_(int *i, int *s, int *ep);
  pj_complex pga6_(int *i, int *j, int *k, int *l, int *m, int *n, int *s, int *ep);
  pj_complex pgb6_(int *i, int *j, int *k, int *l, int *s, int *ep);
  pj_complex pgc6_(int *i, int *j, int *s, int *ep);
#endif /* USE_F2C */

#ifdef __cplusplus
}
#endif

#endif /* QUL_PJFRY_H */
