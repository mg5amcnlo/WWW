/*
 * minoreval.cpp - integral coefficient functions
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "minor6.h"
#include "minor5.h"
#include "minor4.h"
#include "minor3.h"
#include "minor2.h"
#include "icache.h"
#include "mcache.h"

#define EVALR2(ep, i, j) \
  if (i==0 && j==0) { \
    return B(ep); \
  } else { \
    assert(i!=0 && j!=0); \
    return A(ep, i, j); \
  }

#define EVALR3(ep, i, j, k) \
  if (i==0 && j==0) { \
    assert(k!=0); \
    return B(ep, k); \
  } else { \
    assert(i!=0 && j!=0 && k!=0); \
    return A(ep, i, j, k); \
  }

#define EVALR4(ep, i, j, k, l) \
  if (i==0 && j==0) { \
    if (k==0 && l==0) { \
      return C(ep); \
    } else { \
      assert(k!=0 && l!=0); \
      return B(ep, k, l); \
    } \
  } else { \
    assert(i!=0 && j!=0 && k!=0 && l!=0); \
    return A(ep, i, j, k, l); \
  }

#define EVALR5(ep, i, j, k, l, m) \
  if (i==0 && j==0) { \
    if (k==0 && l==0) { \
      assert(m!=0); \
      return C(ep, m); \
    } else { \
      assert(k!=0 && l!=0 && m!=0); \
      return B(ep, k, l, m); \
    } \
  } else { \
    assert(i!=0 && j!=0 && k!=0 && l!=0 && m!=0); \
    return A(ep, i, j, k, l, m); \
  }

#define EVALR6(ep, i, j, k, l, m, n) \
  if (i==0 && j==0) { \
    if (k==0 && l==0) { \
      if (m==0 && n==0) { \
        return D(ep); \
      } else { \
        assert(m!=0 && n==0); \
        return C(ep, m, n); \
      } \
    } else { \
      assert(k!=0 && l!=0 && m!=0 && n!=0); \
      return B(ep, k, l, m, n); \
    } \
  } else { \
    assert(i!=0 && j!=0 && k!=0 && l!=0 && m!=0 && n!=0); \
    return A(ep, i, j, k, l, m, n); \
  }

/* ========================================================
 * ========================================================
 *
 *                HEXAGON coefficients - 6 point
 *
 * ========================================================
 * ========================================================
 */
ncomplex Minor6::evalF(int ep)
{
  return A(ep);
}

ncomplex Minor6::evalF(int ep, int i)
{
  return A(ep, i);
}

ncomplex Minor6::evalF(int ep, int i, int j)
{
  EVALR2(ep, i, j)
}

ncomplex Minor6::evalF(int ep, int i, int j, int k)
{
  EVALR3(ep, i, j, k)
}

ncomplex Minor6::evalF(int ep, int i, int j, int k, int l)
{
  EVALR4(ep, i, j, k, l)
}

ncomplex Minor6::evalF(int ep, int i, int j, int k, int l, int m)
{
  EVALR5(ep, i, j, k, l, m)
}

ncomplex Minor6::evalF(int ep, int i, int j, int k, int l, int m, int n)
{
  EVALR6(ep, i, j, k, l, m, n)
}

/* ========================================================
 * ========================================================
 *
 *                PENTAGON coefficients - 5 point
 *
 * ========================================================
 * ========================================================
 */

ncomplex Minor5::evalE(int ep)
{
  return A(ep);
}

ncomplex Minor5::evalE(int ep, int i)
{
  return A(ep, i);
}

ncomplex Minor5::evalE(int ep, int i, int j)
{
  EVALR2(ep, i, j)
}

ncomplex Minor5::evalE(int ep, int i, int j, int k)
{
  EVALR3(ep, i, j, k)
}

ncomplex Minor5::evalE(int ep, int i, int j, int k, int l)
{
  EVALR4(ep, i, j, k, l)
}

ncomplex Minor5::evalE(int ep, int i, int j, int k, int l, int m)
{
  EVALR5(ep, i, j, k, l, m)
}

/* ========================================================
 * ========================================================
 *
 *                BOX coefficients - 4 point
 *
 * ========================================================
 * ========================================================
 */

ncomplex Minor4::evalD(int ep)
{
  return A(ep);
}

ncomplex Minor4::evalD(int ep, int i)
{
  return A(ep, i);
}

ncomplex Minor4::evalD(int ep, int i, int j)
{
  EVALR2(ep, i, j)
}

ncomplex Minor4::evalD(int ep, int i, int j, int k)
{
  EVALR3(ep, i, j, k)
}

ncomplex Minor4::evalD(int ep, int i, int j, int k, int l)
{
  EVALR4(ep, i, j, k, l)
}

/* ========================================================
 * ========================================================
 *
 *                TRIANGLE coefficients - 3 point
 *
 * ========================================================
 * ========================================================
 */
ncomplex Minor3::evalC(int ep)
{
  return A(ep);
}

ncomplex Minor3::evalC(int ep, int i)
{
  return A(ep, i);
}

ncomplex Minor3::evalC(int ep, int i, int j)
{
  EVALR2(ep, i, j)
}

ncomplex Minor3::evalC(int ep, int i, int j, int k)
{
  EVALR3(ep, i, j, k)
}

/* ========================================================
 * ========================================================
 *
 *             BUBBLE coefficients - 2 point
 *
 * ========================================================
 * ========================================================
 */

ncomplex Minor2::evalB(int ep)
{
  return A(ep);
}

ncomplex Minor2::evalB(int ep, int i)
{
  return A(ep, i);
}

ncomplex Minor2::evalB(int ep, int i, int j)
{
  EVALR2(ep, i, j)
}

#undef EVALR2
#undef EVALR3
#undef EVALR4
#undef EVALR5
#undef EVALR6
