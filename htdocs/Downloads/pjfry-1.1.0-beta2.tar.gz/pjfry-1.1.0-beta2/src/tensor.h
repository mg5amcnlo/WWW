/*
 * tensor.h - signed minor interface class
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_TENSOR_H
#define QUL_TENSOR_H

#include "common.h"
#include "pointer.h"

class Tensor : public SRefCnt
{
  public:
    friend class SPtr<Tensor>;
    typedef SPtr<Tensor> Ptr;

    Tensor() {}

    virtual Ptr Sub(int s)=0;

    virtual ncomplex A(int ep)=0;
    virtual ncomplex A(int ep, int i)=0;
    virtual ncomplex A(int ep, int i, int j)=0;
    virtual ncomplex A(int ep, int i, int j, int k)=0;
    virtual ncomplex A(int ep, int i, int j, int k, int l)=0;
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m)=0;
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m, int n)=0;
    virtual ncomplex B(int ep)=0;
    virtual ncomplex B(int ep, int i)=0;
    virtual ncomplex B(int ep, int i, int j)=0;
    virtual ncomplex B(int ep, int i, int j, int k)=0;
    virtual ncomplex B(int ep, int i, int j, int k, int l)=0;
    virtual ncomplex C(int ep)=0;
    virtual ncomplex C(int ep, int i)=0;
    virtual ncomplex C(int ep, int i, int j)=0;
    virtual ncomplex D(int ep)=0;

    virtual const ncomplex* Ai(int ep)=0;
    virtual const ncomplex* Aij(int ep)=0;
    virtual const ncomplex* Aijk(int ep)=0;
    virtual const ncomplex* Aijkl(int ep)=0;
    virtual const ncomplex* Aijklm(int ep)=0;
    virtual const ncomplex* Aijklmn(int ep)=0;
    virtual const ncomplex* Bi(int ep)=0;
    virtual const ncomplex* Bij(int ep)=0;
    virtual const ncomplex* Bijk(int ep)=0;
    virtual const ncomplex* Bijkl(int ep)=0;
    virtual const ncomplex* Ci(int ep)=0;
    virtual const ncomplex* Cij(int ep)=0;
};


#endif /* QUL_TENSOR_H */
