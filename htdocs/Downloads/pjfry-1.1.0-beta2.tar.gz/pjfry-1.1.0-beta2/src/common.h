/*
 * common.h - common includes and parameters
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_COMMON_H
#define QUL_COMMON_H

#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif /* HAVE_CONFIG_H */

#include <complex>
#include <limits>
#include <inttypes.h>
// #include <stdint.h>

#include <cassert>
#ifndef NDEBUG
#include <cstdio> // DEBUG
#endif
#include <iostream>

#ifdef DOUBLE
#include <qd/qd_real.h>
  #define EXTENDED_PREC
#else
  #define ndouble double
#endif

typedef std::complex<ndouble> ncomplex;

// PJFRY namespace macro
#define SUF_double _sd
#define SUF_dd_real _dd
#define SUF_qd_real _qd
#define CONCAT_(A, B) A ## B
#define CONCAT(A, B) CONCAT_(A, B)
#define SUF CONCAT(SUF_, DOUBLE)
#define PJFRY CONCAT(PJFry, SUF)

#define PJFRY_USE using namespace PJFRY;
#define PJFRY_BEGIN namespace PJFRY {
#define PJFRY_END } // namespace PJFRY
// PJFRY namespace macro

// Forward declarations
class ICache;
class MCache;

class Minor6;
class Minor5;
class Minor4;
class Minor3;
class Minor2;

class Minor6ptr;
class Minor5ptr;
class Minor4ptr;
class Minor3ptr;
class Minor2ptr;

class Kinem6;
class Kinem5;
class Kinem4;
class Kinem3;
class Kinem2;

class Golem;

#define CONST __attribute__ ((const))
#define PURE __attribute__ ((pure))

#ifdef USE_GOLEM_MODE
#   define USE_ZERO_CHORD        1  /* calculate formfactors for zero-chord */
#else
//  Approx 1% slowdown, does not work with golem mode
#   define USE_SMART_INSERT      1  /* before adding new, delete same old entries in MCache2,3 */
#endif

// #define USE_DIRTY_RESET          1  /* when told to clear caches, just set len=0 */

#define DBL_SLOPPY_CMP           1  /* use eps-tolerance double comparison */
#ifndef DBL_SLOPPY_CMP
//   #define DBL_ULP_CMP            1  /* use ulp-binary double comparison */
#endif

#endif /* QUL_COMMON_H */

