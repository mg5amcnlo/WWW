/*
 * pointer.h - smart pointer class
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_POINTER_H
#define QUL_POINTER_H

#include <algorithm>

class SRefCnt
{
  public:
    SRefCnt() : count(0) { }

  protected:
    int count;
};

template <typename T>
class SPtr
{
  public:
    T* operator-> () const { return pObj; }
    bool operator== (const T* pobj) const { return pobj==pObj; }
    bool operator!= (const T* pobj) const { return pobj!=pObj; }

    bool operator== (const SPtr<T>& spobj) const { return spobj.pObj==pObj; }
    bool operator!= (const SPtr<T>& spobj) const { return spobj.pObj!=pObj; }

    inline
    SPtr(T* pobj=0) : pObj(pobj) {
      if (pObj) { pObj->count++; }
    }
    inline
    SPtr(const SPtr& ptr) : pObj(ptr.pObj) {
      if (pObj) { pObj->count++; }
    }

    // type-conversion copy-constructor
    template <class U>
    SPtr(const SPtr<U>& ptr) : pObj(static_cast<T*>(ptr.operator->())) {
      if (pObj) { pObj->count++; }
    }

    // copy-and-swap assignment
    SPtr& operator= (SPtr ptr) {
      swap(*this, ptr);
      return *this;
    }

    ~SPtr() {
      if (pObj && --(pObj->count) == 0) { delete pObj; }
    }

  private:
    void swap(SPtr& a, SPtr& b) { std::swap(a.pObj, b.pObj); }
    T* pObj;
};

#endif /* QUL_POINTER_H */
