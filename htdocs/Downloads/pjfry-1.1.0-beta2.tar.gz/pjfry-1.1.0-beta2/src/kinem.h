/*
 * kinem.h - kinematics classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_KINEM_H
#define QUL_KINEM_H

#include "common.h"
#include "cache.h"

template <int R>
class Kinem
{
  public:
    bool operator==(const Kinem& kinem) const;

    inline
    double mass(int i) const {
      return kdata[(i-1)*(i+2)/2];
    }

#ifndef NDEBUG
    void print() const {
      printf("K%d", R);
      for (int i=0; i<KLEN; i++) {
        printf(" %e", kdata[i]);
      }
      printf("\n");
    }
#endif

  protected:
    Kinem() {}

    void zero(); // initialize to zero

    static const int KLEN=R*(R+1)/2;
    enum Invar {im1=0,
                ip1, im2,
                ip2, ip3, im3,
                ip4, is12, is23, im4,
                ip5, is34, is45, is15, im5,
                ip6, is16, is234, is345, is456, im6};

    double kdata[KLEN];
};

template <int R>
bool Kinem<R>::operator==(const Kinem<R>& kinem) const
{
  for (int i=0; i<KLEN; i++) {
    if (Cache::neq(kdata[i], kinem.kdata[i])) return false;
  }
  return true;
}

template <int R>
void Kinem<R>::zero()
{
  for (int i=0; i<KLEN; i++) {
    kdata[i]=0.;
  }
}

// 1-point kinematics
class Kinem1 : public Kinem<1>
{
  public:
    Kinem1() { zero(); }
    Kinem1(double xm1) {
      kdata[im1]=xm1;
    }

    Kinem1(const double Cay[]) {
      kdata[im1] = 0.5*Cay[ 0];
    }

    inline double m1()  const { return kdata[im1];  }
};

// 2-point kinematics
class Kinem2 : public Kinem<2>
{
  public:
    Kinem2() { zero(); }
    Kinem2(double xp1,
           double xm1,  double xm2)
    {
      kdata[ip1]=xp1;
      kdata[im1]=xm1;
      kdata[im2]=xm2;
    }

    Kinem2(const double Cay[]) {
      kdata[im1] = 0.5*Cay[ 0];
      kdata[im2] = 0.5*Cay[ 2];
      kdata[ip1] = m1()+m2()-Cay[ 1];
    }

    void setcayley(double Cay[]) const {
      Cay[ 0]=2.*m1();
      Cay[ 1]=m1()+m2()-p1(); Cay[ 2]=2.*m2();
    }

    inline double p1()  const { return kdata[ip1];  }
    inline double m1()  const { return kdata[im1];  }
    inline double m2()  const { return kdata[im2];  }
};

// 3-point kinematics
class Kinem3 : public Kinem<3>
{
  public:
    Kinem3() { zero(); }
    Kinem3(double xp1,  double xp2,  double xp3,
           double xm1,  double xm2,  double xm3)
    {
      kdata[ip1]=xp1;
      kdata[ip2]=xp2;
      kdata[ip3]=xp3;
      kdata[im1]=xm1;
      kdata[im2]=xm2;
      kdata[im3]=xm3;
    }

    Kinem3(const double Cay[]) {
      kdata[im1] = 0.5*Cay[ 0];
      kdata[im2] = 0.5*Cay[ 2];
      kdata[im3] = 0.5*Cay[ 5];
      kdata[ip1] = m1()+m3()-Cay[ 3];
      kdata[ip2] = m1()+m2()-Cay[ 1];
      kdata[ip3] = m2()+m3()-Cay[ 4];
    }

    void setcayley(double Cay[]) const {
      Cay[ 0]=2.*m1();
      Cay[ 1]=m1()+m2()-p2(); Cay[ 2]=2.*m2();
      Cay[ 3]=m1()+m3()-p1(); Cay[ 4]=m2()+m3()-p3();  Cay[ 5]=2.*m3();
    }

    inline double p1()  const { return kdata[ip1];  }
    inline double p2()  const { return kdata[ip2];  }
    inline double p3()  const { return kdata[ip3];  }
    inline double m1()  const { return kdata[im1];  }
    inline double m2()  const { return kdata[im2];  }
    inline double m3()  const { return kdata[im3];  }
};

// 4-point kinematics
class Kinem4 : public Kinem<4>
{
  public:
    Kinem4() { zero(); }
    Kinem4(double xp1,  double xp2,  double xp3,  double xp4,
           double xs12, double xs23,
           double xm1,  double xm2,  double xm3,  double xm4)
    {
      kdata[ip1]=xp1;
      kdata[ip2]=xp2;
      kdata[ip3]=xp3;
      kdata[ip4]=xp4;
      kdata[is12]=xs12;
      kdata[is23]=xs23;
      kdata[im1]=xm1;
      kdata[im2]=xm2;
      kdata[im3]=xm3;
      kdata[im4]=xm4;
    }

    Kinem4(const double Cay[]) {
      kdata[im1] = 0.5*Cay[ 0];
      kdata[im2] = 0.5*Cay[ 2];
      kdata[im3] = 0.5*Cay[ 5];
      kdata[im4] = 0.5*Cay[ 9];
      kdata[ip1] = m1()+m4()-Cay[ 6];
      kdata[ip2] = m1()+m2()-Cay[ 1];
      kdata[ip3] = m2()+m3()-Cay[ 4];
      kdata[ip4] = m3()+m4()-Cay[ 8];
      kdata[is12] = m2()+m4()-Cay[ 7];
      kdata[is23] = m1()+m3()-Cay[ 3];
    }

    void setcayley(double Cay[]) const {
      Cay[ 0]=2.*m1();
      Cay[ 1]=m1()+m2()-p2();  Cay[ 2]=2.*m2();
      Cay[ 3]=m1()+m3()-s23(); Cay[ 4]=m2()+m3()-p3();  Cay[ 5]=2.*m3();
      Cay[ 6]=m1()+m4()-p1();  Cay[ 7]=m2()+m4()-s12(); Cay[ 8]=m3()+m4()-p4();  Cay[ 9]=2.*m4();
    }

    inline double p1()  const { return kdata[ip1];  }
    inline double p2()  const { return kdata[ip2];  }
    inline double p3()  const { return kdata[ip3];  }
    inline double p4()  const { return kdata[ip4];  }
    inline double m1()  const { return kdata[im1];  }
    inline double m2()  const { return kdata[im2];  }
    inline double m3()  const { return kdata[im3];  }
    inline double m4()  const { return kdata[im4];  }
    inline double s12() const { return kdata[is12]; }
    inline double s23() const { return kdata[is23]; }
};

// 5-point kinematics
class Kinem5 : public Kinem<5>
{
  public:
    Kinem5() { zero(); }
    Kinem5(double xp1,  double xp2,  double xp3,  double xp4,  double xp5,
           double xs12, double xs23, double xs34, double xs45, double xs15,
           double xm1,  double xm2,  double xm3,  double xm4,  double xm5)
    {
      kdata[ip1]=xp1;
      kdata[ip2]=xp2;
      kdata[ip3]=xp3;
      kdata[ip4]=xp4;
      kdata[ip5]=xp5;
      kdata[is12]=xs12;
      kdata[is23]=xs23;
      kdata[is34]=xs34;
      kdata[is45]=xs45;
      kdata[is15]=xs15;
      kdata[im1]=xm1;
      kdata[im2]=xm2;
      kdata[im3]=xm3;
      kdata[im4]=xm4;
      kdata[im5]=xm5;
    }

    Kinem5(const double Cay[]) {
      kdata[im1] = 0.5*Cay[ 0];
      kdata[im2] = 0.5*Cay[ 2];
      kdata[im3] = 0.5*Cay[ 5];
      kdata[im4] = 0.5*Cay[ 9];
      kdata[im5] = 0.5*Cay[14];
      kdata[ip1] = m1()+m5()-Cay[10];
      kdata[ip2] = m1()+m2()-Cay[ 1];
      kdata[ip3] = m2()+m3()-Cay[ 4];
      kdata[ip4] = m3()+m4()-Cay[ 8];
      kdata[ip5] = m4()+m5()-Cay[13];
      kdata[is12] = m2()+m5()-Cay[11];
      kdata[is23] = m1()+m3()-Cay[ 3];
      kdata[is34] = m2()+m4()-Cay[ 7];
      kdata[is45] = m3()+m5()-Cay[12];
      kdata[is15] = m1()+m4()-Cay[ 6];
    }

    void setcayley(double Cay[]) const {
      Cay[ 0]=2.*m1();
      Cay[ 1]=m1()+m2()-p2();  Cay[ 2]=2.*m2();
      Cay[ 3]=m1()+m3()-s23(); Cay[ 4]=m2()+m3()-p3();  Cay[ 5]=2.*m3();
      Cay[ 6]=m1()+m4()-s15(); Cay[ 7]=m2()+m4()-s34(); Cay[ 8]=m3()+m4()-p4();  Cay[ 9]=2.*m4();
      Cay[10]=m1()+m5()-p1();  Cay[11]=m2()+m5()-s12(); Cay[12]=m3()+m5()-s45(); Cay[13]=m4()+m5()-p5(); Cay[14]=2.*m5();
    }

    inline double p1()  const { return kdata[ip1];  }
    inline double p2()  const { return kdata[ip2];  }
    inline double p3()  const { return kdata[ip3];  }
    inline double p4()  const { return kdata[ip4];  }
    inline double p5()  const { return kdata[ip5];  }
    inline double m1()  const { return kdata[im1];  }
    inline double m2()  const { return kdata[im2];  }
    inline double m3()  const { return kdata[im3];  }
    inline double m4()  const { return kdata[im4];  }
    inline double m5()  const { return kdata[im5];  }
    inline double s12() const { return kdata[is12]; }
    inline double s23() const { return kdata[is23]; }
    inline double s34() const { return kdata[is34]; }
    inline double s45() const { return kdata[is45]; }
    inline double s15() const { return kdata[is15]; }
};

// 6-point kinematics
class Kinem6 : public Kinem<6>
{
  public:
    Kinem6() { zero(); }
    Kinem6(double xp1,  double xp2,  double xp3,  double xp4,  double xp5,  double xp6,
           double xs12, double xs23, double xs34, double xs45, double xs56, double xs16,
           double xs234, double xs345, double xs456,
           double xm1,  double xm2,  double xm3,  double xm4,  double xm5,  double xm6)
    {
      kdata[ip1]=xp1;
      kdata[ip2]=xp2;
      kdata[ip3]=xp3;
      kdata[ip4]=xp4;
      kdata[ip5]=xp5;
      kdata[ip6]=xp6;
      kdata[is12]=xs12;
      kdata[is23]=xs23;
      kdata[is34]=xs34;
      kdata[is45]=xs45;
      kdata[is15]=xs56; // NB!
      kdata[is16]=xs16;
      kdata[is234]=xs234;
      kdata[is345]=xs345;
      kdata[is456]=xs456;
      kdata[im1]=xm1;
      kdata[im2]=xm2;
      kdata[im3]=xm3;
      kdata[im4]=xm4;
      kdata[im5]=xm5;
      kdata[im6]=xm6;
    }

    Kinem6(const double Cay[]) {
      kdata[im1] = 0.5*Cay[ 0];
      kdata[im2] = 0.5*Cay[ 2];
      kdata[im3] = 0.5*Cay[ 5];
      kdata[im4] = 0.5*Cay[ 9];
      kdata[im5] = 0.5*Cay[14];
      kdata[im6] = 0.5*Cay[20];
      kdata[ip1] = m1()+m6()-Cay[15];
      kdata[ip2] = m1()+m2()-Cay[ 1];
      kdata[ip3] = m2()+m3()-Cay[ 4];
      kdata[ip4] = m3()+m4()-Cay[ 8];
      kdata[ip5] = m4()+m5()-Cay[13];
      kdata[ip6] = m4()+m6()-Cay[19];
      kdata[is12] = m2()+m6()-Cay[16];
      kdata[is23] = m1()+m3()-Cay[ 3];
      kdata[is34] = m2()+m4()-Cay[ 7];
      kdata[is45] = m3()+m5()-Cay[12];
      kdata[is15] = m4()+m6()-Cay[18]; // NB!
      kdata[is16] = m1()+m5()-Cay[10];
      kdata[is234] = m1()+m4()-Cay[ 6];
      kdata[is345] = m2()+m5()-Cay[11];
      kdata[is456] = m3()+m6()-Cay[17];
    }

    void setcayley(double Cay[]) const {
      Cay[ 0]=2.*m1();
      Cay[ 1]=m1()+m2()-p2();  Cay[ 2]=2.*m2();
      Cay[ 3]=m1()+m3()-s23(); Cay[ 4]=m2()+m3()-p3();  Cay[ 5]=2.*m3();
      Cay[ 6]=m1()+m4()-s234();Cay[ 7]=m2()+m4()-s34(); Cay[ 8]=m3()+m4()-p4();  Cay[ 9]=2.*m4();
      Cay[10]=m1()+m5()-s16(); Cay[11]=m2()+m5()-s345();Cay[12]=m3()+m5()-s45(); Cay[13]=m4()+m5()-p5();  Cay[14]=2.*m5();
      Cay[15]=m1()+m6()-p1();  Cay[16]=m2()+m6()-s12(); Cay[17]=m3()+m6()-s456();Cay[18]=m4()+m6()-s56(); Cay[19]=m4()+m6()-p6(); Cay[20]=2.*m6();
    }

    inline double p1()  const { return kdata[ip1];  }
    inline double p2()  const { return kdata[ip2];  }
    inline double p3()  const { return kdata[ip3];  }
    inline double p4()  const { return kdata[ip4];  }
    inline double p5()  const { return kdata[ip5];  }
    inline double p6()  const { return kdata[ip6];  }
    inline double m1()  const { return kdata[im1];  }
    inline double m2()  const { return kdata[im2];  }
    inline double m3()  const { return kdata[im3];  }
    inline double m4()  const { return kdata[im4];  }
    inline double m5()  const { return kdata[im5];  }
    inline double m6()  const { return kdata[im6];  }
    inline double s12() const { return kdata[is12]; }
    inline double s23() const { return kdata[is23]; }
    inline double s34() const { return kdata[is34]; }
    inline double s45() const { return kdata[is45]; }
    inline double s56() const { return kdata[is15]; } // NB!
    inline double s16() const { return kdata[is16]; }
    inline double s234() const { return kdata[is234]; }
    inline double s345() const { return kdata[is345]; }
    inline double s456() const { return kdata[is456]; }
};

#endif /* QUL_KINEM_H */
