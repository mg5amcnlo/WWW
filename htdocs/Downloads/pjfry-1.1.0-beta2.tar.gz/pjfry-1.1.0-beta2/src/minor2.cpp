/*
 * minor2.cpp - bubbles
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "minor2.h"
#include "icache.h"

/* Define local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 * rrMi - matrix rank numbering
 */
#define pM0 rrM3
#define pM1 rrM2
#define evalM1 evalRM2
#define DM1 RM2

// Constructor
Minor1::Minor1(const Kinem1 &k)
  : kinem(k)
{
  pID0 = ICache::getI1(kinem);
}

// Constructor
Minor2::Minor2(const Kinem2 &k)
  : kinem(k),
    pIDi(), pID2ij()  // zero-init externally accessible uv-div parts

{
  pID0 = ICache::getI2(kinem);  // UV-div
  if (pID0[1] != ncomplex(0.)) {
    qZeroALL = false;
    pID1[0] = Cache::sNAN.d64;    // UV-div
    pID1[1] = Cache::sNAN.d64;
    pID1[2] = 0.;
    pID2[0] = Cache::sNAN.d64;
    pID2[1] = Cache::sNAN.d64;
    pID2[2] = 0.;
    pID3[0] = Cache::sNAN.d64;
    pID3[1] = Cache::sNAN.d64;
    pID3[2] = 0.;
    pID4[0] = Cache::sNAN.d64;
    pID4[1] = Cache::sNAN.d64;
    pID4[2] = 0.;
    pID5[0] = Cache::sNAN.d64;
    pID5[1] = Cache::sNAN.d64;
    pID5[2] = 0.;
    pID6[0] = Cache::sNAN.d64;
    pID6[1] = Cache::sNAN.d64;
    pID6[2] = 0.;

    const double msq1 = kinem.m1();
    const double psq1 = kinem.p1();
    const double msq2 = kinem.m2();

    kinem.setcayley(Cay);
    evalM1();
    pM0[0] = -2.*psq1;

    // make 2x2 minors signed
    pM1[iss(0,1)] = -pM1[iss(0,1)];
    pM1[iss(1,2)] = -pM1[iss(1,2)];

    mnr1[0] = Minor1::create(Kinem1(msq1));
    mnr1[1] = Minor1::create(Kinem1(msq2));

    // Analyze
    // find maximal Cayley matrix element
    pmaxCay = 0.;
    for (int i=0; i < (DCay-1)*(DCay)/2; i++) {
      const double abscay = fabs(Cay[i]);
      if (abscay > pmaxCay) pmaxCay = abscay;
    }
    // find maximal mass
    const double maxM = msq1 > msq2 ? msq1 : msq2;
    // set conditions
    const double s_cutoff = seps1*(maxM > meps ? maxM : Cache::getMu2()); // if mass<meps use mu2
    qZeroS  = fabs(M0()) <= s_cutoff;    // test for s==0
    qEqMass = fabs(msq1 - msq2) <= meps; // test for equal mass // TODO maybe use smth other than meps, like cutoff*Max(s,mur)
  } else {
    qZeroALL = true;
    pmaxCay = 0.;
    pID1[0] = 0.;
    pID1[1] = 0.;
    pID1[2] = 0.;
    pID2[0] = 0.;
    pID2[1] = 0.;
    pID2[2] = 0.;
    pID3[0] = 0.;
    pID3[1] = 0.;
    pID3[2] = 0.;
    pID4[0] = 0.;
    pID4[1] = 0.;
    pID4[2] = 0.;
    pID5[0] = 0.;
    pID5[1] = 0.;
    pID5[2] = 0.;
    pID6[0] = 0.;
    pID6[1] = 0.;
    pID6[2] = 0.;
  }
}

/* --------------------------------------------------------
 *   bubble in D+2 dim
 * --------------------------------------------------------
 */
void Minor2::ID1Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = -I1v(ep, 1);
      } else {
        ivalue = -0.25*(msq1 + msq2)
                 +0.5*(-msq1*I1v(ep, 1) + msq2*I1v(ep, 2))/(mm12);
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*(3.*I1v(ep, 2)+2.*msq2);
      sum1 -= M1(0, 2)*(3.*I1v(ep, 1)+2.*msq1);
      sum1 += M1(0, 0)*(3.*ID0(ep)+2.*ID0(ep+1));
      ivalue = sum1/(9.*M0());
    }
  } else { assert(ep==1);
//     ivalue = -(Cay[nss(1,1)]+Cay[nss(1,2)]+Cay[nss(2,2)])/6.;
    ivalue = -(3.*(msq1+msq2)-psq1)/6.;
  }
  pID1[ep] = ivalue;
}

/* --------------------------------------------------------
 *   bubble in D+4 dim
 * --------------------------------------------------------
 */
void Minor2::ID2Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = 0.25*msq1*(msq1 + 2.*I1v(ep, 1));
      } else {
        ivalue =  5.*(msq1*msq1 + msq1*msq2 + msq2*msq2)/36.
              + ( + msq1*msq1*I1v(ep, 1)
                  - msq2*msq2*I1v(ep, 2)
                  )/(6.*mm12);
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*(-0.25*msq2*(10.*I1v(ep, 2)+9.*msq2));
      sum1 -= M1(0, 2)*(-0.25*msq1*(10.*I1v(ep, 1)+9.*msq1));
      sum1 += M1(0, 0)*(5.*ID1(ep)+2.*ID1(ep+1));
      ivalue = sum1/(25.*M0());
    }
  } else { assert(ep==1);
    const double y11 = Cay[nss(1,1)];
    const double y12 = Cay[nss(1,2)];
    const double y22 = Cay[nss(2,2)];
    ivalue = ( 3.*( y11*(y11+y12)+(y12+y22)*y22)+2.*y12*y12+y11*y22 )/120.;
  }
  pID2[ep] = ivalue;
}

/* --------------------------------------------------------
 *   IDi bubble in D+2 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor2::IDi(int ep, int i)
{
  if (ep>=2 || qZeroALL) return 0.;
  if (not fEval[E_Di+ep]) {
    IDiEval(ep);
  }
  return pIDi[ep][i-1];
}

void Minor2::IDiEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    const int ip = i%2 + 1; // i==1 ? 2 : 1;
    ncomplex ivalue = 0.;
    if (ep==0) {
      const double msq1 = kinem.mass(i);
      const double msq2 = kinem.mass(ip);

      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          ivalue = (msq1 - I1v(ep, i))/(2.*msq1);
        } else {
          ivalue = (msq1 + msq2)/(4.*msq1 - 4.*msq2)
                  -( (msq1 - 2.*msq2)*I1v(ep, i)
                    + msq2*I1v(ep, ip) )/(2.*mm12*mm12);
        }
      } else {
        ncomplex sum1 = 0.;
        sum1 -=  M1(0, i)*ID0(ep);
        sum1 +=  I1v(ep, i);
        sum1 += -I1v(ep, ip);
        ivalue = sum1/M0();
      }
    } else { assert(ep==1);
      ivalue = -0.5;//*ID0(1);  // ID0(1) == 1 unless all scales are zero (when it is == 0)
    }
    pIDi[ep][i-1] = ivalue;
  }
  fEval[E_Di+ep] = true;
}

/* --------------------------------------------------------
 *   ID2i bubble in D+4 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor2::ID2i(int ep, int i)
{
  if (ep>=2 || qZeroALL) return 0.;
  if (not fEval[E_D2i+ep]) {
    ID2iEval(ep);
  }
  return pID2i[ep][i-1];
}

void Minor2::ID2iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    const int ip = i%2 + 1; // i==1 ? 2 : 1;
    ncomplex ivalue = 0.;
    if (ep==0) {
      const double msq1 = kinem.mass(i);
      const double msq2 = kinem.mass(ip);

      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          ivalue = 0.5*I1v(ep, i);
        } else {
          ivalue = (4*msq1*msq1-5*(msq1+msq2)*msq2)/(36*mm12)
                  +( msq1*(2*msq1 - 3*msq2)*I1v(ep, i)
                    +msq2*msq2*I1v(ep, ip) )/(6*mm12*mm12);
        }
      } else {
        ncomplex sum1 = 0.;
        sum1 -=  M1(0, i)*ID1(ep);
        sum1 += -0.5*msq1*(I1v(ep, i)+0.5*msq1);
        sum1 +=  0.5*msq2*(I1v(ep, ip)+0.5*msq2);
        ivalue = sum1/M0();
      }
    } else { assert(ep==1);
//       if ( ID0(1) == 0. ) {
//         ivalue = 0.;
//       } else {
        ivalue = (3.*Cay[nss(i,i)] + 2.*Cay[ns(i,ip)] + Cay[nss(ip,ip)])/24.;
//       }
    }
    pID2i[ep][i-1] = ivalue;
  }
}

/* --------------------------------------------------------
 *   I2D2ij bubble in D+4 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor2::ID2ij(int ep, int i, int j)
{
  if (ep>=2 || qZeroALL) return 0.;
  if (not fEval[E_D2ij+ep]) {
    ID2ijEval(ep);
  }
  return pID2ij[ep][ns(i,j)];
}

void Minor2::ID2ijEval(int ep)
{
  // i==j
  for (int i=1; i<=CIDX; i++) {
    const int ip = i%2 + 1; // i==1 ? 2 : 1;
    ncomplex sum0 = 0.;
    if (ep==0) {
      const double msq1 = kinem.mass(i);
      const double msq2 = kinem.mass(ip);

      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          sum0 = 2.*(I1v(ep, i) - msq1)/(6.*msq1);
        } else {
          sum0 = 2.*( (-4*msq1*msq1 + 5*msq1*msq2 + 5*msq2*msq2)/6.
                    + ( (msq1*msq1 - 3*msq1*msq2 + 3*msq2*msq2)*I1v(ep, i)
                      - msq2*msq2*I1v(ep, ip))/mm12
                    )/(6.*mm12*mm12);
        }
      } else {
        sum0 -=  M1(0, i)*IDi(ep, i);
        sum0 += -I1v(ep, i);
        sum0 += -ID1(ep);
        sum0/=M0();
      }
    } else { assert(ep==1);
      sum0 = ndouble(2.)/6.;//*ID0(1);
    }
    pID2ij[ep][nss(i,i)] = sum0;
  }
  // i!=j
  for (int i=1; i<=CIDX; i++) {
  const int ip = i==1 ? 2 : 1;
  for (int j=i+1; j<=CIDX; j++) {
    ncomplex sum1 = 0.;
    if (ep==0) {
      const double msq1 = kinem.mass(i);
      const double msq2 = kinem.mass(ip);

      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          sum1 = (I1v(ep, i) - msq1)/(6.*msq1);
        } else {
          sum1 = (-(msq1*msq1 + 10*msq1*msq2 + msq2*msq2)/6. +
                    ( msq1*(msq1 - 3*msq2)*I1v(ep, i)
                    + (3*msq1 - msq2)*msq2*I1v(ep, ip) )/mm12
                  )/(6.*mm12*mm12);
        }
      } else {
        sum1 += (Cay[nss(i,i)]-Cay[ns(i,ip)])*IDi(ep, i);
        sum1 += I1v(ep, i);
        sum1 += ID1(ep);
        sum1/=M0();
      }
    } else { assert(ep==1);
      sum1 = ndouble(1.)/6.;//*ID0(1);
    }
    pID2ij[ep][nss(i,j)] = sum1;
  }
  }
  fEval[E_D2ij+ep] = true;
}


/* ========================================================
 *               IR triangles
 * ========================================================
 */

/* --------------------------------------------------------
 *   I2mDstu bubble in D-2 dim
 * --------------------------------------------------------
 */
void Minor2::IDm1Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = 1./msq1;
      } else {
        ivalue = ( - (msq1>meps ? I1v(ep, 1)/msq1 : 1.)
                   + (msq2>meps ? I1v(ep, 2)/msq2 : 1.)
                 )/(mm12);
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*(msq2>meps ? 1.-I1v(ep, 2)/msq2 : 0.);
      sum1 -= M1(0, 2)*(msq1>meps ? 1.-I1v(ep, 1)/msq1 : 0.);
      sum1 += M1(0, 0)*(ID0(ep)-2.*ID0(ep+1));
      ivalue = sum1/M0();
    }
  } else if (ep==1) {
    if (fabs(msq1) < meps) {
      if (fabs(msq2) < meps) {
        ivalue = 2./psq1;//*ID0(1)          // I(s,0,0)
      } else {
        ivalue = 1./(psq1-msq2);            // I(s,0,msq2)
      }
    } else if (fabs(msq2) < meps) {
        ivalue = 1./(psq1-msq1);            // I(s,msq1,0)
    }
  }
  pIDm1[ep] = ivalue;
}

/* --------------------------------------------------------
 *   Ii bubble in D dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor2::Ii(int ep, int i)
{
  if (ep>=2 || qZeroALL) return 0.;
  if (not fEval[E_i+ep]) {
    IiEval(ep);
  }
  return pIi[ep][i-1];
}

void Minor2::IiEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    const int ip = i%2 + 1; // i==1 ? 2 : 1;
    const double msq1 = kinem.mass(i);
    const double msq2 = kinem.mass(ip);
    ncomplex ivalue = 0.;
    if (ep==0) {
      if (qZeroS) {
        if (qEqMass) {
          ivalue = -1./(2.*msq1);
        } else {
          if (msq1 > meps) {
            const double mm12 = msq1 - msq2;
            ivalue = -1./mm12
                      - ( + msq2*I1v(ep, i )
                          - msq1*I1v(ep, ip)
                        )/(msq1*mm12*mm12);
          } else {
            ivalue = I1v(ep, ip)/(msq2*msq2);
          }
        }
      } else {
        ncomplex sum1 = 0.;
        sum1 -=  M1(0, i)*IDm1(ep);
        sum1 += msq1>meps ? 1.-I1v(ep, i )/msq1 : 0.;
        sum1 -= msq2>meps ? 1.-I1v(ep, ip)/msq2 : 0.;
        ivalue = sum1/M0();
      }
    } else { assert(ep==1);
      if (fabs(msq1) < meps) {
        if (not qZeroS) {
          const double psq1 = kinem.p1();
          if (fabs(msq2) < meps) {
            ivalue = -1./psq1;            // I(s,0,0)
          } else {
            ivalue = -1./(psq1-msq2);     // I(s,0,msq2)
          }
        } else if (msq2 > meps) {
          ivalue = 1./msq2;               // I(0,0,msq2)
        }
      }
    }
    pIi[ep][i-1] = ivalue;
  }
}

/* --------------------------------------------------------
 *   I2Dij bubble in D+2 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor2::IDij(int ep, int i, int j)
{
  if (ep>=2 || qZeroALL) return 0.;
  if (not fEval[E_Dij+ep]) {
    IDijEval(ep);
  }
  return pIDij[ep][ns(i,j)];
}

void Minor2::IDijEval(int ep)
{
  // i==j
  for (int i=1; i<=CIDX; i++) {
    const int ip = i%2 + 1; // i==1 ? 2 : 1;
    ncomplex sum0 = 0.;
    const double msq1 = kinem.mass(i);
    const double msq2 = kinem.mass(ip);
    if (ep==0) {
      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          sum0 = 1./(3*msq1);
        } else {
          sum0 = ( (msq1 - 3*msq2)
                  + 2.*msq2*( -msq2*I1v(ep, i)
                             + msq1*I1v(ep, ip)
                        )/(msq1*mm12)
                  )/(2.*mm12*mm12);
        }
      } else {
        sum0 -=  M1(0, i)*Ii(ep, i);
        sum0 += (msq1>meps ? I1v(ep, i)/msq1 - 1. : 0.);
        sum0 += -ID0(ep);
        sum0/=M0();
      }
    } else { assert(ep==1);
      if (fabs(msq1) < meps) {
        if (not qZeroS) {
          const double psq1 = kinem.p1();
          sum0 = 1./(psq1-msq2);
        }
      }
    }
    pIDij[ep][nss(i,i)] = sum0;
  }
  // i!=j
  for (int i=1; i<=CIDX; i++) {
  const int ip = i==1 ? 2 : 1;
  for (int j=i+1; j<=CIDX; j++) {
    ncomplex sum1 = 0.;
    if (ep==0) {
      const double msq1 = kinem.mass(i);
      const double msq2 = kinem.mass(ip);

      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          if (msq1 > meps) {
            sum1 = 1./(6.*msq1);
          }
        } else {
          sum1 = ((msq1 + msq2)
                   + 2.*(  msq2*I1v(ep, i)
                         - msq1*I1v(ep, ip)
                        )/mm12
                  )/(2.*mm12*mm12);
        }
      } else {
        sum1 += (Cay[nss(i ,i )]-Cay[ns(i,ip)])*Ii(ep, i);
        sum1 += -(msq1>meps ? I1v(ep, i)/msq1 - 1. : 0.);
        sum1 += ID0(ep);
        sum1/=M0();
      }
    }/* else { assert(ep==1);
      sum1=0;
    }*/
    pIDij[ep][nss(i,j)] = sum1;
  }
  }
  fEval[E_Dij+ep] = true;
}

/* --------------------------------------------------------
 *   I2D2stuijk bubble in D+4 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor2::ID2ijk(int ep, int i, int j, int k)
{
  ncomplex sum1 = 0.;
  const int ip = i%2 + 1; // i==1 ? 2 : 1;
  const double msq1 = kinem.mass(i);
  const double msq2 = kinem.mass(ip);
  if (i==j && j==k) {
    if (ep==0) {
      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          if (msq1 > meps) {
            sum1=-1./(4*msq1);
          }
        } else {
          sum1=( (-2*msq1*msq1 + 7*msq1*msq2 - 11*msq2*msq2)/6
                + msq2*msq2*( -msq2*I1v(ep, i)
                             + msq1*I1v(ep, ip)
                      )/(msq1*mm12)
                )/(mm12*mm12*mm12);
        }
      } else {
//         sum1+=+(Cay[nss(ip,ip)]-Cay[ns(i,ip)])*IDij(ep, i, j);
        sum1 -=  M1(0, i)*IDij(ep, i, j);
        sum1 += -(msq1>meps ? I1v(ep, i)/msq1 - 1. : 0.);
        sum1 += -2.*IDi(ep, i);
        sum1/=M0();
      }
    } else if (ep==1) {
      if (fabs(msq1) < meps) {
        if (fabs(M0()) > meps) {
          const double psq1 = kinem.p1();
          sum1 = -1./(psq1-msq2);
        }
      }
    }
  } else if (i==j || i==k) {
    if (ep==0) {
      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          if (msq1 > meps) {
            sum1=-1./(12*msq1);
          }
        } else {
          sum1=( (-msq1*msq1 + 5*msq1*msq2 + 2*msq2*msq2)/6
                + msq2*( msq2*I1v(ep, i)
                       - msq1*I1v(ep, ip)
                      )/(mm12)
                )/(mm12*mm12*mm12);
        }
      } else {
        if (i==k) {
//           sum1+=+(Cay[nss(ip,ip)]-Cay[ns(i,ip)])*I2Dstuij(ep,s,t,u,i,j);
          sum1 -=  M1(0, i)*IDij(ep, i, j);
          sum1 += IDi(ep, i) - IDi(ep, j);
          sum1/=M0();
        } else { // i==j != k
          sum1 += (Cay[nss(i ,i )]-Cay[ns(i,ip)])*IDij(ep, i, j);
          sum1 += (msq1>meps ? I1v(ep, i)/msq1 - 1. : 0.);
          sum1 += 2.*IDi(ep, i);
          sum1/=M0();
        }
      }
    }
  } else if ( j==k ) {
    if (ep==0) {
      if (qZeroS) {
        const double mm12 = msq1 - msq2;
        if (qEqMass) {
          if (msq1 > meps) {
            sum1=-1./(12*msq1);
          }
        } else {
          sum1=( (-2*msq1*msq1 - 5*msq1*msq2 + msq2*msq2)/6
                + msq1*( -msq2*I1v(ep, i)
                        + msq1*I1v(ep, ip)
                      )/(mm12)
                )/(mm12*mm12*mm12);
        }
      } else {
        sum1 += (Cay[nss(i ,i )]-Cay[ns(i,ip)])*IDij(ep, i, j);
        sum1 += -IDi(ep, i) + IDi(ep, j);
        sum1/=M0();
      }
    }
  }
  return sum1;
}

/* ========================================================
 *               SMALL Gram4 expansion
 * ========================================================
 */

/* --------------------------------------------------------
 *   bubble in D+6 dim
 * --------------------------------------------------------
 */
void Minor2::ID3Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = -(5.*msq1 + 6.*I1v(ep, 1))*msq1*msq1/36.;
      } else {
        ivalue = -13.*((msq1+msq2)*(msq1*msq1+msq2*msq2))/288.
                  + ( - msq1*msq1*msq1*I1v(ep, 1)
                      + msq2*msq2*msq2*I1v(ep, 2)
                    )/(24.*mm12);
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*((42.*I1v(ep, 2)+47.*msq2)*msq2*msq2/36.);
      sum1 -= M1(0, 2)*((42.*I1v(ep, 1)+47.*msq1)*msq1*msq1/36.);
      sum1 += M1(0, 0)*(7.*ID2(ep)+2.*ID2(ep+1));
      ivalue = sum1/(49.*M0());
    }
  } else { assert(ep==1);
    const double y11 = Cay[nss(1,1)];
    const double y12 = Cay[nss(1,2)];
    const double y22 = Cay[nss(2,2)];
    ivalue = -(+ y11*y11*(y22 + 5.*(y11 + y12))
               + y22*y22*(y11 + 5.*(y22 + y12))
               + 2.*y12*y12*(y12 + 2.*(y11 + y22))
               + 3.*y11*y22*y12
              )/1680.;
  }
  pID3[ep] = ivalue;
}

/* --------------------------------------------------------
 *   bubble in D+8 dim
 * --------------------------------------------------------
 */
void Minor2::ID4Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = (13.*msq1 + 12.*I1v(ep, 1))*msq1*msq1*msq1/288.;
      } else {
        const double m1p4 = (msq1*msq1)*(msq1*msq1);
        const double m2p4 = (msq2*msq2)*(msq2*msq2);
        ivalue = (77.*(msq1*m1p4-msq2*m2p4)/7200.
                 + ( + m1p4*I1v(ep, 1)
                     - m2p4*I1v(ep, 2)
                     )/120.)/mm12;
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*(-(36.*I1v(ep, 2)+47.*msq2)*msq2*msq2*msq2/96.);
      sum1 -= M1(0, 2)*(-(36.*I1v(ep, 1)+47.*msq1)*msq1*msq1*msq1/96.);
      sum1 += M1(0, 0)*(9.*ID3(ep)+2.*ID3(ep+1));
      ivalue = sum1/(81.*M0());
    }
  } else { assert(ep==1);
    const double y11 = Cay[nss(1,1)];
    const double y12 = Cay[nss(1,2)];
    const double y22 = Cay[nss(2,2)];
    ivalue = (
          +y11*y11*(y11*(35.*(y11+y12)+5.*y22)+15.*y12*(2.*y12+y22))
          +y22*y22*(y22*(35.*(y22+y12)+5.*y11)+15.*y12*(2.*y12+y11))
          +y12*y12*(y12*(8.*y12+20.*y11+20.*y22)+24.*y11*y22)
          +3.*y11*y11*y22*y22
            )/120960.;
  }
  pID4[ep] = ivalue;
}

/* --------------------------------------------------------
 *   bubble in D+10 dim
 * --------------------------------------------------------
 */
void Minor2::ID5Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = -(77.*msq1 + 60.*I1v(ep, 1))*(msq1*msq1)*(msq1*msq1)/7200.;
      } else {
        const double m1p5 = (msq1*msq1)*(msq1*msq1)*msq1;
        const double m2p5 = (msq2*msq2)*(msq2*msq2)*msq2;
        ivalue = -(29.*(msq1*m1p5-msq2*m2p5)/14400.
                 + ( + m1p5*I1v(ep, 1)
                     - m2p5*I1v(ep, 2)
                     )/720.)/mm12;
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*((660.*I1v(ep, 2)+967.*msq2)*(msq2*msq2)*(msq2*msq2)/7200.);
      sum1 -= M1(0, 2)*((660.*I1v(ep, 1)+967.*msq1)*(msq1*msq1)*(msq1*msq1)/7200.);
      sum1 += M1(0, 0)*(11.*ID4(ep)+2.*ID4(ep+1));
      ivalue = sum1/(121.*M0());
    }
  } else { assert(ep==1);
    const double y11 = Cay[nss(1,1)];
    const double y12 = Cay[nss(1,2)];
    const double y22 = Cay[nss(2,2)];
    ivalue = -(
            y11*y11*y11*(y11*(63.*(y11+y12)+7.*y22)+7.*y12*(8.*y12+3.*y22)+3.*y22*y22)
          + y22*y22*y22*(y22*(63.*(y22+y12)+7.*y11)+7.*y12*(8.*y12+3.*y11)+3.*y11*y11)
          + y12*y12*y12*(8.*y12*(y12+3.*y11+3.*y22)+6.*(7.*y11*y11+4.*y11*y22+7.*y22*y22))
          + y11*y22*y12*(4.*y12*(9.*(y11+y22)+4.*y12)+15.*y11*y22)
            )/2661120.;
  }
  pID5[ep] = ivalue;
}

/* --------------------------------------------------------
 *   bubble in D+12 dim
 * --------------------------------------------------------
 */
void Minor2::ID6Eval(int ep)
{
  ncomplex ivalue = 0.;
  const double msq1 = kinem.m1();
  const double psq1 = kinem.p1();
  const double msq2 = kinem.m2();
  if (ep==0) {
    if (qZeroS) {
      const double mm12 = msq1 - msq2;
      if (qEqMass) {
        ivalue = (29.*msq1 + 20.*I1v(ep, 1))*(msq1*msq1)*(msq1*msq1)*msq1/14400.;
      } else {
        const double m1p6 = (msq1*msq1)*(msq1*msq1)*(msq1*msq1);
        const double m2p6 = (msq2*msq2)*(msq2*msq2)*(msq2*msq2);
        ivalue = (223.*(msq1*m1p6-msq2*m2p6)/705600.
                 + ( + m1p6*I1v(ep, 1)
                     - m2p6*I1v(ep, 2)
                     )/5040.)/mm12;
      }
    } else {
      ncomplex sum1 = 0.;
      sum1 -= M1(0, 1)*(-(260.*I1v(ep, 2)+417.*msq2)*(msq2*msq2)*(msq2*msq2)*msq2/14400.);
      sum1 -= M1(0, 2)*(-(260.*I1v(ep, 1)+417.*msq1)*(msq1*msq1)*(msq1*msq1)*msq1/14400.);
      sum1 += M1(0, 0)*(13.*ID5(ep)+2.*ID5(ep+1));
      ivalue = sum1/(169.*M0());
    }
  } else { assert(ep==1);
    const double y11 = Cay[nss(1,1)];
    const double y12 = Cay[nss(1,2)];
    const double y22 = Cay[nss(2,2)];
    ivalue = (
      y11*y11*y11*(y11*(21.*y11*(11.*(y11+y12)+y22)+210.*y12*y12+7*y22*y22+63.*y22*y12)
      +y12*y12*(168.*y12+112.*y22))+y22*y22*y22*(y22*(21.*y22*(11.*(y22
      +y12)+y11)+210.*y12*y12+7.*y11*y11+63.*y11*y12)+y12*y12*(168.*y12+112.*y11))
      +y12*y12*(y12*y12*(16.*y12*y12+112.*(y11*y11+y22*y22)+56.*y12*(y11+y22)
      +120.*y11*y22)+y11*y22*(90.*y11*y22+140.*y12*(y22+y11)))
      +y11*y11*y22*y22*(35.*(y11+y22)*y12+5.*y11*y22)
      )/138378240.;
  }
  pID6[ep] = ivalue;
}



/* Undefine local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 */

#undef pM0
#undef pM1
#undef evalM1
#undef DM1
