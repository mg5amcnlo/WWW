/*
 * minor3.cpp - triangles
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include <cstdio> // DEBUG

#include "minor3.h"
#include "icache.h"
#include "mcache.h"

/* Define local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 * rrMi - matrix rank numbering
 */
#define pM0 rrM4
#define pM1 rrM3
#define pM2 rrM2
#define evalM1 evalRM3
#define evalM2 evalRM2
#define DM1 RM3
#define DM2 RM2

// Constructor
Minor3::Minor3(const Kinem3 &k)
  : kinem(k),
    pID2i()  // zero-init externally accessible uv-div parts
{
  pID0 = ICache::getI3(kinem);  // IR-div
  pID1[0] = Cache::sNAN.d64;    // UV-div
  pID1[1] = ndouble(-0.5);
  pID1[2] = 0.;
  pID2[0] = Cache::sNAN.d64;
  pID2[1] = Cache::sNAN.d64;
  pID2[2] = 0.;
  pID3[0] = Cache::sNAN.d64;
  pID3[1] = Cache::sNAN.d64;
  pID3[2] = 0.;
  pID4[0] = Cache::sNAN.d64;
  pID4[1] = Cache::sNAN.d64;
  pID4[2] = 0.;
  pID5[0] = Cache::sNAN.d64;
  pID5[1] = Cache::sNAN.d64;
  pID5[2] = 0.;
  pID6[0] = Cache::sNAN.d64;
  pID6[1] = Cache::sNAN.d64;
  pID6[2] = 0.;
  pID7[0] = Cache::sNAN.d64;
  pID7[1] = Cache::sNAN.d64;
  pID7[2] = 0.;

  const double p1=kinem.p1();
  const double p2=kinem.p2();
  const double p3=kinem.p3();
  const double m1=kinem.m1();
  const double m2=kinem.m2();
  const double m3=kinem.m3();

  // Bubbles
  const Kinem2 k2[] = {
    Kinem2(p3,m2,m3),
    Kinem2(p1,m1,m3),
    Kinem2(p2,m1,m2)
  };
  MEntry2* ptrs2[3];
  for (int i=0; i<N; i++) {
    ptrs2[i] = &MCache::entry(k2[i]); // look-up or create empty element
    mnr2[i] = ptrs2[i]->val;
  }

  // do smth, initialize minors
  kinem.setcayley(Cay);
  evalM1();
  pM0[0] = 0.;
  for (int i=1; i<=N; i++) {
    pM0[0] += M1(0, i);
  }
  ////////////

  for (int i=0; i<N; i++) {
//     printf("mnr2[%d] = %lX ------------------\n", i, mnr2[i].operator->());
    if (mnr2[i] == 0) {
      if (ptrs2[i]->val == 0) {
        mnr2[i] = Minor2::create(k2[i]);
        ptrs2[i]->val = mnr2[i]; // MCache::insertMinor2(k2[i], mnr2[i]);
      } else {
        mnr2[i] = ptrs2[i]->val;
      }
    }
  }

  // Analyze
  // find maximal Cayley matrix element
  pmaxCay = 0.;
  for (int i=0; i<N; i++) {
    const double abscay = mnr2[i]->maxCay();
    if (abscay > pmaxCay) pmaxCay = abscay;
  }
  // TODO tune ceps
  // set conditions
  qSmallGram = false;
  qTinyGram = false;
  if (M1(0, 0) != 0.) {
    const double maxS = fabs(pmaxCay*M0()/M1(0, 0));
    qSmallGram = maxS <= ceps;
    qTinyGram  = maxS <= deps;
  }
}

double Minor3::M2r00(int i, int j)  // M2(0, i, 0, j)
{
  const int powsign = -2*((i+j)&0x1)+1;
  const int uidx = im2(0,i);
  const int lidx = im2(0,j);

  return pM2[is(uidx,lidx)]*powsign;
}

/* --------------------------------------------------------
 *   triangle in D+2 dim
 * --------------------------------------------------------
 */
void Minor3::ID1Eval(int ep)
{
  assert(ep==0);
  ncomplex ivalue = 0.;

  if (qSmallGram) {
    // EXP
    const double x = M0()/M1(0, 0);
    ncomplex sump;
    do {
      double du0[N+1];
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        du0[u] = M1(u, 0);
        sum1 += du0[u]*I2Du(0, u);
      }

      double xn = 1.;
      ncomplex dv, s21;

      ncomplex sum[3];
      sum[0] = sump = sum1;

#define stepI3D(n,a,b) \
      xn *= x; \
      dv = 0.; \
      for (int u=1; u<=N; u++) { \
        dv += du0[u]*(a*I2D##n##u(0, u) - b*I2D##n##u(1, u)); \
      } \
      dv *= xn; \
      sum1 += dv;

      stepI3D(2,4.,2.)
      if (   fabs(sum1.real()*teps)>=fabs(dv.real())
          && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
        break;
      sum[1] = sump = sum1;
      s21 = sum[1] - sum[0];

      stepI3D(3,24.,20.)
      sump = sum1;
      stepWynn(0)
      stepI3D(4,192.,208.)
      stepWynn(1)
      stepI3D(5,1920.,2464.)
      stepWynn(2)
      stepI3D(6,23040.,33408.)
      stepWynn(3)
//         stepI3D(7,322560.,513792.)
//         stepWynn(4)
#undef stepI3D
    } while (0);
    ivalue = sump/M1(0, 0);
  } else {
    // NORMAL
    ncomplex sum1 = 0.;
    for (int u=1; u<=N; u++) {
      sum1 -= M1(u, 0)*I2u(ep, u);
    }
    sum1 += M1(0, 0)*ID0(ep);
    ivalue = sum1/(2.*M0())-ndouble(0.5); // 2*(-1/2)/2 == -0.5
  }
  pID1[ep] = ivalue;
}

/* --------------------------------------------------------
 *   triangle in D+4 dim
 * --------------------------------------------------------
 */
void Minor3::ID2Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (ep==0) {
    const double d00 = M1(0, 0);
    if (qSmallGram) {
      // EXP
      const double x = M0()/d00;
      ncomplex sump;
      do {
        double du0[N+1];
        ncomplex sum1 = 0.;
        for (int u=1; u<=N; u++) {
          du0[u] = M1(u, 0);
          sum1 += du0[u]*I2D2u(0, u);
        }

        double xn = 1.;
        ncomplex dv, s21;

        ncomplex sum[3];
        sum[0] = sump = sum1;

#define stepI3D(n,a,b) \
        xn *= x; \
        dv = 0.; \
        for (int u=1; u<=N; u++) { \
          dv += du0[u]*(a*I2D##n##u(0, u) - b*I2D##n##u(1, u)); \
        } \
        dv *= xn; \
        sum1 += dv;

        stepI3D(3,6.,2.)
        if (   fabs(sum1.real()*teps)>=fabs(dv.real())
            && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
          break;
        sum[1] = sump = sum1;
        s21 = sum[1] - sum[0];

        stepI3D(4,48.,28.)
        sump = sum1;
        stepWynn(0)
        stepI3D(5,480.,376.)
        stepWynn(1)
        stepI3D(6,5760.,5472.)
        stepWynn(2)
//           stepI3D(7,80640.,88128.)
//           stepWynn(3)
//           stepI3D(8,1290240.,1571328.)
//           stepWynn(4)
#undef stepI3D
      } while (0);
      ivalue = sump/d00;
    } else {
      // NORMAL
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 -= M1(u, 0)*I2Du(ep, u);
      }
      sum1 += d00*ID1(ep);
      ivalue = sum1/(4.*M0())+ID2(ep+1)*0.5; // 2*x/4 == 0.5*x
    }
  } else {
    assert(ep==1);
    ivalue=( Cay[nss(1,1)]+Cay[nss(2,2)]+Cay[nss(3,3)]
            +Cay[nss(1,2)]+Cay[nss(1,3)]+Cay[nss(2,3)])/24.;
  }
  pID2[ep] = ivalue;
}

/* --------------------------------------------------------
 *   triangle in D+6 dim
 * --------------------------------------------------------
 */
void Minor3::ID3Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (ep==0) {
    const double d00 = M1(0, 0);
    if (qSmallGram) {
      // EXP
      const double x = M0()/d00;
      ncomplex sump;
      do {
        assert(ep==0);

        double du0[N+1];
        ncomplex sum1 = 0.;
        for (int u=1; u<=N; u++) {
          du0[u] = M1(u, 0);
          sum1 += du0[u]*I2D3u(0, u);
        }

        double xn = 1.;
        ncomplex dv, s21;

        ncomplex sum[3];
        sum[0] = sump = sum1;

#define stepI3D(n,a,b) \
        xn *= x; \
        dv = 0; \
        for (int u=1; u<=N; u++) { \
          dv += du0[u]*(a*I2D##n##u(0, u) - b*I2D##n##u(1, u)); \
        } \
        dv *= xn; \
        sum1 += dv;

        stepI3D(4,8.,2.)
        if (   fabs(sum1.real()*teps)>=fabs(dv.real())
            && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
          break;
        sum[1] = sump = sum1;
        s21 = sum[1] - sum[0];

        stepI3D(5,80.,36.)
        sump = sum1;
        stepWynn(0)
        stepI3D(6,960.,592.)
        stepWynn(1)
//           stepI3D(7,13440.,10208.)
//           stepWynn(2)
//           stepI3D(8,215040.,190208.)
//           stepWynn(3)
//           stepI3D(9,3870720.,3853824.)
//           stepWynn(4)
#undef stepI3D
      } while (0);
      ivalue = sump/d00;
    } else {
      // NORMAL
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 -= M1(u, 0)*I2D2u(ep, u);
      }
      sum1 += d00*ID2(ep);
      ivalue = sum1/(6.*M0())+ID3(ep+1)/3.;
    }
  } else {
    assert(ep==1);
    const double y11=Cay[nss(1,1)];
    const double y12=Cay[nss(1,2)];
    const double y13=Cay[nss(1,3)];
    const double y22=Cay[nss(2,2)];
    const double y23=Cay[nss(2,3)];
    const double y33=Cay[nss(3,3)];
    ivalue = -(3.*(y11*(y11+y12+y13)+y22*(y12+y22+y23)+y33*(y13+y23+y33))
              +2.*(y12*(y12+y23)+y13*(y12+y13)+y23*(y13+y23))
              +   (y11*(y22+y23)+y22*(y13+y33)+y33*(y11+y12))
              )/720.;
  }
  pID3[ep] = ivalue;
}


/* --------------------------------------------------------
 *   IDi triangle in D+2 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor3::IDi(int ep, int i) // IR-div
{
  assert(ep<=2); // if (ep>2) return 0;
  if (not fEval[E_Di+ep]) {
    IDiEval(ep);
  }
  return pIDi[ep][i-1];
}

void Minor3::IDiEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    const double d00 = M1(0, 0);
    if (ep!=0 && fabs(d00) > m3eps) { // if d00!=0 I3Dsti is finite // TODO: check!
      pIDi[ep][i-1] = 0.;
      continue;
    }
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      // Cayley3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M2r00(u, i)*I2u(ep, u);
      }
      sum1 += M1(0, i)*(-2.*ID1(ep) + EPSCAP(2.*ID1(ep+1)));
      ivalue = sum1/d00;
    } else {
      // Gram3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M1(u, i)*I2u(ep, u);
      }
      sum1 -= M1(0, i)*ID0(ep);
      ivalue = sum1/M0();
    }
    pIDi[ep][i-1] = ivalue;
  }
  fEval[E_Di+ep] = true;
}

/* --------------------------------------------------------
 *   ID2i triangle in D+4 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor3::ID2i(int ep, int i)
{
  if (ep>=2) return 0.;
  if (not fEval[E_D2i+ep]) {
    ID2iEval(ep);
  }
  return pID2i[ep][i-1];
}

void Minor3::ID2iEval(int ep)
{
  if (ep==1) {
    for (int i=1; i<=CIDX; i++) {
      pID2i[ep][i-1] = ndouble(1.)/6.;
    }
    fEval[E_D2i+ep] = true;
    return;
  }
  for (int i=1; i<=CIDX; i++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      // Cayley3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M2r00(u, i)*I2Du(ep, u);
      }
      sum1 += M1(0, i)*(-4.*ID2(ep) + EPSCAP(2.*ID2(ep+1)));
      ivalue = sum1/M1(0, 0);
    } else {
      // Gram3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M1(u, i)*I2Du(ep, u);
      }
      sum1 -= M1(0, i)*ID1(ep);
      ivalue = sum1/M0();
    }
    pID2i[ep][i-1] = ivalue;
  }
  fEval[E_D2i+ep] = true;
}

/* --------------------------------------------------------
 *   I3D3sti triangle in D+6 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor3::ID3i(int ep, int i)
{
  if (ep>=2) return 0.;
  if (not fEval[E_D3i+ep]) {
    ID3iEval(ep);
  }
  return pID3i[ep][i-1];
}

void Minor3::ID3iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex ivalue = 0.;

    if (ep==0) {
      if (qSmallGram) {
        // Cayley3
        ncomplex sum1 = 0.;
        for (int u=1; u<=N; u++) {
          sum1 += M2r00(u, i)*I2D2u(ep, u);
        }
        sum1 += M1(0, i)*(-6.*ID3(ep) + EPSCAP(2.*ID3(ep+1)));
        ivalue = sum1/M1(0, 0);
      } else {
        // Gram3
        ncomplex sum1 = 0.;
        for (int u=1; u<=N; u++) {
          sum1 += M1(u, i)*I2D2u(ep, u);
        }
        sum1 -= M1(0, i)*ID2(ep);
        ivalue = sum1/M0();
      }
    } else {
      assert(ep==1);
      // TODO verify
      int j= i==2 ? 1 : 2;
      int k= i==3 ? 1 : 3;
      ivalue = -( 3.*Cay[nss(i,i)]+2.*(Cay[ns(i,j)]+Cay[ns(i,k)])
                    +Cay[nss(j,j)]+Cay[ns(j,k)]+Cay[nss(k,k)]
                )/120.;
//       ivalue = -(   Cay[nss(i,i)]
//                    +Cay[ ns(1,i)]+Cay[ ns(2,i)]+Cay[ ns(3,i)]
//                    +Cay[nss(1,1)]+Cay[nss(1,2)]+Cay[nss(1,3)]
//                    +Cay[nss(2,2)]+Cay[nss(2,3)]+Cay[nss(3,3)]
//                 )/120.;
    }
    pID3i[ep][i-1] = ivalue;
  }
  fEval[E_D3i+ep] = true;
}

/* --------------------------------------------------------
 *   ID2ij triangle in D+4 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor3::ID2ij(int ep, int i, int j) // IR-div
{
  assert(ep<=2); // if (ep>2) return 0;
  if (not fEval[E_D2ij+ep]) {
    ID2ijEval(ep);
  }
  return pID2ij[ep][ns(i,j)];
}

void Minor3::ID2ijEval(int ep)
{
  const double d00=M1(0, 0);
  if (ep!=0 && fabs(d00) > m3eps) { // if d00!=0 I3D2ij is finite
    for (int ij=nss(1,1); ij<=nss(CIDX,CIDX); ij++) {
      pID2ij[ep][ij] = 0.;
    }
    fEval[E_D2ij+ep] = true;
    return;
  }

  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      // Cayley3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M2r00(u, j)*I2Dui(ep, u, i);
      }
      sum1 += M2r00(i, j)*ID1(ep);
      sum1 += M1(0, j)*(-3.*ID2i(ep, i) + EPSCAP(2.*ID2i(ep+1, i)));
      ivalue = sum1/M1(0, 0);
    } else {
      // Gram3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M1(u, j)*I2Dui(ep, u, i);
      }
      sum1 += -M1(0, j)*IDi(ep, i) + M1(i, j)*ID1(ep);
      ivalue = sum1/M0();
    }
    pID2ij[ep][nss(i,j)] = ivalue;
  }
  }
  fEval[E_D2ij+ep] = true;
}

/* --------------------------------------------------------
 *   I3D3stij triangle in D+6 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor3::ID3ij(int ep, int i, int j)
{
  if      (ep==1) return ( i==j ? ndouble(-1.)/12. : ndouble(-1.)/24. ); // -1/12 == -2/24
  else if (ep>=2) return 0;
  if (not fEval[E_D3ij+ep]) {
    ID3ijEval(ep);
  }
  return pID3ij[ep][ns(i,j)];
}

void Minor3::ID3ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      // Cayley3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M2r00(u, j)*I2D2ui(ep, u, i);
      }
      sum1 += M2r00(i, j)*ID2(ep);
      sum1 += M1(0, j)*(-5.*ID3i(ep, i) + EPSCAP(2.*ID3i(ep+1, i)));  // EPSCAP not needed
      ivalue = sum1/M1(0, 0);
    } else {
      // Gram3
      ncomplex sum1=0;
      for (int u=1; u<=N; u++) {
        sum1 += M1(u, j)*I2D2ui(ep, u, i);
      }
      sum1 += -M1(0, j)*ID2i(ep, i) + M1(i, j)*ID2(ep);
      ivalue = sum1/M0();
    }
    pID3ij[ep][nss(i,j)] = ivalue;
  }
  }
  fEval[E_D3ij+ep] = true;
}

/* --------------------------------------------------------
 *   I3D3ijk triangle in D+6 dim with three dots
 * --------------------------------------------------------
 */
ncomplex Minor3::ID3ijk(int ep, int i, int j, int k) // IR-div
{
  assert(ep<=2); // if (ep>2) return 0;
  if (not fEval[E_D3ijk+ep]) {
    ID3ijkEval(ep);
  }
  return pID3ijk[ep][is(i-1,j-1,k-1)];
}

void Minor3::ID3ijkEval(int ep)
{
  const double d00 = M1(0, 0);
  if (ep!=0 && fabs(d00) > m3eps) { // if d00!=0 I3D3stijk is finite
    for (int ijk=iss(1-1,1-1,1-1); ijk<=iss(CIDX-1,CIDX-1,CIDX-1); ijk++) {
      pID3ijk[ep][ijk] = 0.;
    }
    fEval[E_D3ijk+ep] = true;
    return;
  }

  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      // Cayley3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M2r00(u, k)*I2D2uij(ep, u, i, j);
      }
      sum1 += M2r00(i, k)*ID2i(ep, j) + M2r00(j, k)*ID2i(ep, i);
      sum1 += M1(0, k)*(-4.*ID3ij(ep, i, j) + EPSCAP(2.*ID3ij(ep+1, i, j)));
      ivalue = sum1/M1(0, 0);
    } else {
      // Gram3
      ncomplex sum1 = 0.;
      for (int u=1; u<=N; u++) {
        sum1 += M1(u, k)*I2D2uij(ep, u, i, j);
      }
      sum1 -= M1(0, k)*ID2ij(ep, i, j);
      sum1 += M1(i, k)*ID2i(ep, j) + M1(j, k)*ID2i(ep, i);
      ivalue = sum1/M0();
    }
    pID3ijk[ep][iss(i-1,j-1,k-1)] = ivalue;
  }
  }
  }
  fEval[E_D3ijk+ep] = true;
}

/* ========================================================
 *               SMALL Gram4 expansion
 * ========================================================
 */

/* --------------------------------------------------------
 *   triangle in D+8 dim
 * --------------------------------------------------------
 */
void Minor3::ID4Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (qTinyGram) {
    printf("I3D4 small Gram\n");
    ivalue = std::numeric_limits<double>::quiet_NaN();
  } else {
    double cf = ndouble(1.)/8.;
    for (int ei=ep; ei<=1; ei++) {
      ncomplex sum1 = M1(0, 0)*ID3(ei);
      for (int u=1; u<=N; u++) {
        sum1 -= M1(u, 0)*I2D3u(ei, u);
      }
      ivalue += cf*sum1;
      cf *= ndouble(1.)/4.;
    }
    ivalue /= M0();
  }
  pID4[ep] = ivalue;
}

/* --------------------------------------------------------
 *   triangle in D+10 dim
 * --------------------------------------------------------
 */
void Minor3::ID5Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (qTinyGram) {
    printf("I3D5 small Gram\n");
    ivalue = std::numeric_limits<double>::quiet_NaN();
  } else {
    double cf=ndouble(1.)/10.;
    for (int ei=ep; ei<=1; ei++) {
      ncomplex sum1 = M1(0, 0)*ID4(ei);
      for (int u=1; u<=N; u++) {
        sum1 -= M1(u, 0)*I2D4u(ei, u);
      }
      ivalue += cf*sum1;
      cf *= ndouble(1.)/5.;
    }
    ivalue /= M0();
  }
  pID5[ep] = ivalue;
}

/* --------------------------------------------------------
 *   triangle in D+12 dim
 * --------------------------------------------------------
 */
void Minor3::ID6Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (qTinyGram) {
    printf("I3D6 small Gram\n");
    ivalue = std::numeric_limits<double>::quiet_NaN();
  } else {
    double cf = ndouble(1.)/12.;
    for (int ei=ep; ei<=1; ei++) {
      ncomplex sum1 = M1(0, 0)*ID5(ei);
      for (int u=1; u<=N; u++) {
        sum1 -= M1(u, 0)*I2D5u(ei, u);
      }
      ivalue += cf*sum1;
      cf *= ndouble(1.)/6.;
    }
    ivalue /= M0();
  }
  pID6[ep] = ivalue;
}

/* --------------------------------------------------------
 *   triangle in D+14 dim
 * --------------------------------------------------------
 */
void Minor3::ID7Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (qTinyGram) {
    printf("I3D7 small Gram\n");
    ivalue = std::numeric_limits<double>::quiet_NaN();
  } else {
    double cf = ndouble(1.)/14.;
    for (int ei=ep; ei<=1; ei++) {
      ncomplex sum1 = M1(0, 0)*ID6(ei);
      for (int u=1; u<=N; u++) {
        sum1 -= M1(u, 0)*I2D6u(ei, u);
      }
      ivalue += cf*sum1;
      cf *= ndouble(1.)/7.;
    }
    ivalue /= M0();
  }
  pID7[ep] = ivalue;
}

/* Undefine local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 */
#undef pM0
#undef pM1
#undef pM2
#undef evalM1
#undef evalM2
#undef DM1
#undef DM2
