/*
 * minor4.cpp - boxes
 *
 * this file is part of PJFry library
 * Copyright 2012 Valery Yundin
 */

#include "minor4.h"
#include "icache.h"
#include "mcache.h"

/* Define local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 * rrMi - matrix rank numbering
 */
#define pM0 rrM5
#define pM1 rrM4
#define pM2 rrM3
#define evalM1 evalRM4
#define evalM2 evalRM3
#define DM1 RM4
#define DM2 RM3

// Constructor
Minor4::Minor4(const Kinem4 &k)
  : kinem(k),
    pID2i(), pID3ij()  // zero-init externally accessible finite parts
{
  pID0 = ICache::getI4(kinem);  // IR-div
  pID1[0] = Cache::sNAN.d64;    // finite
  pID1[1] = 0.;
  pID1[2] = 0.;
  pID2[0] = Cache::sNAN.d64;    // UV-div
  pID2[1] = ndouble(1.)/6.;
  pID2[2] = 0.;
  pID3[0] = Cache::sNAN.d64;
  pID3[1] = Cache::sNAN.d64;
  pID3[2] = 0.;
  pID4[0] = Cache::sNAN.d64;
  pID4[1] = Cache::sNAN.d64;
  pID4[2] = 0.;

  const double p1=kinem.p1();
  const double p2=kinem.p2();
  const double p3=kinem.p3();
  const double p4=kinem.p4();
  const double s12=kinem.s12();
  const double s23=kinem.s23();
  const double m1=kinem.m1();
  const double m2=kinem.m2();
  const double m3=kinem.m3();
  const double m4=kinem.m4();

  // Triangles
  const Kinem3 k3[] = {
    Kinem3(s12,p3,p4,m2,m3,m4),
    Kinem3(p1,s23,p4,m1,m3,m4),
    Kinem3(p1,p2,s12,m1,m2,m4),
    Kinem3(s23,p2,p3,m1,m2,m3)
  };
  MEntry3* ptrs3[N];
  for (int i=0; i<N; i++) {
    ptrs3[i] = &MCache::entry(k3[i]); // look-up or create empty element
    mnr3[i] = ptrs3[i]->val;
  }

  // do smth, initialize minors
  kinem.setcayley(Cay);
  evalM1();
  pM0[0] = 0.;
  for (int i=1; i<=N; i++) {
    pM0[0] += M1(0, i);
  }
  ////////////

  for (int i=0; i<N; i++) {
//     printf("mnr3[%d] = %lX ------------------\n", i, mnr3[i].operator->());
    if (mnr3[i] == 0) {
      if (ptrs3[i]->val == 0) {
        mnr3[i] = Minor3::create(k3[i]);
        ptrs3[i]->val = mnr3[i]; // MCache::insertMinor3(k3[i], mnr3[i]);
      } else {
        mnr3[i] = ptrs3[i]->val;
      }
    }
  }

  // Analyze
  pmaxCay = 0.;
  for (int i=0; i<N; i++) {
    const double abscay = mnr3[i]->maxCay();
    if (abscay > pmaxCay) pmaxCay = abscay;
  }
  // set conditions
  qSmallGram = false;
  if (M1(0, 0) != 0.) {
    const double maxS = fabs(pmaxCay*M0()/M1(0, 0));
    qSmallGram = maxS <= deps1;  // maybe have several for deps1,2,3
  }
}

/* --------------------------------------------------------
    Return two-index minor with proper sign
 * --------------------------------------------------------
 */
double Minor4::M2(int i, int j, int l, int m)
{
  int sign = signM2ud(i,j,l,m);
  if (sign==0) return 0;

  const int uidx = im2(i,j);
  const int lidx = im2(l,m);

  return pM2[is(uidx,lidx)]*sign;
}

/* --------------------------------------------------------
    Evaluate all 1x1 scratched (4-dim) minors
 * --------------------------------------------------------
 */
void Minor4::evalM1()
{
  evalM2();
#ifndef NDEBUG
  for (int i=0; i<DM1*(DM1+1)/2; i++) { pM1[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif
  {
    const int i=0;
    const int j=1;
    {
      const int l=0; const int bl=1<<l;

      double m1ele = 0.;
      const int ui = 0; // idxtbl[bi|bj]
      for (int m=1; m<=DCay-1; m++) {
        const unsigned int tdi = (1<<m)|bl;
        m1ele += pM2[iss(ui,idxtbl[tdi])]*Cay[nss(j,m)];
      }
      pM1[is(i,l)] = m1ele;
    }
  }
  const int j=0;
  for (int i=1; i<=DCay-1; i++) {
    for (int l=0; l<=i; l++) {
      double m1ele = 0.;
      for (int m=1; m<=DCay-1; m++) {
        m1ele += M2(i,j,l,m);
      }
      pM1[iss(l,i)] = m1ele;
    }
  }
//   fEval[E_M1] = true;
}

/* --------------------------------------------------------
 *   box in D+2 dim
 * --------------------------------------------------------
 */
void Minor4::ID1Eval(int ep)
{
  assert(ep==0);
  ncomplex ivalue = 0.;

  if (qSmallGram) {
    // EXP
    const double x = M0()/M1(0, 0);
    ncomplex sump;
    do {
      assert(ep==0);

      double d0t[N+1];
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        d0t[t] = M1(0, t);
        sum1 += d0t[t]*I3Dt(0, t);
      }

      double xn = 1.;
      ncomplex dv, s21;

      ncomplex sum[3];
      sum[0] = sump = sum1;

#define stepI4D(n,a,b) \
      xn *= x; \
      dv = 0.; \
      for (int t=1; t<=N; t++) { \
        dv += d0t[t]*(a*I3D##n##t(0, t) - b*I3D##n##t(1, t)); \
      } \
      dv *= xn; \
      sum1 += dv;

      stepI4D(2,3.,2.)
      if (   fabs(sum1.real()*teps)>=fabs(dv.real())
          && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
        break;
      sum[1] = sump = sum1;
      s21 = sum[1]-sum[0];

      stepI4D(3,15.,16.)
      sump = sum1;
      stepWynn(0)
      stepI4D(4,105.,142.)
      stepWynn(1)
      stepI4D(5,945.,1488.)
      stepWynn(2)
      stepI4D(6,10395.,18258.)
      stepWynn(3)
      stepI4D(7,135135.,258144.)
      stepWynn(4)
//       stepI4D(8,2027025.,4142430.)
//       stepWynn(5)
//       stepI4D(9,34459425.,74475360.)
//       stepWynn(6)
#undef stepI4D
    } while (0);
    ivalue = sump/M1(0, 0);
  } else {
    // NORMAL
    ncomplex sum1 = 0.;
    for (int t=1; t<=N; t++) {
      sum1 -= M1(0, t)*I3t(ep, t);
    }
    sum1 += M1(0, 0)*ID0(ep);
    ivalue = sum1/M0();
  }
  pID1[ep] = ivalue;
}

/* --------------------------------------------------------
 *   box in D+4 dim
 * --------------------------------------------------------
 */
void Minor4::ID2Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (qSmallGram) {
    // EXP
    const double x = M0()/M1(0, 0);
    ncomplex sump;
    do {
      assert(ep==0);

      double d0t[N+1];
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        d0t[t] = M1(0, t);
        sum1 += d0t[t]*I3D2t(0, t);
      }

      double xn = 1.;
      ncomplex dv, s21;

      ncomplex sum[3];
      sum[0] = sump = sum1;

#define stepI4D(n,a,b) \
      xn *= x; \
      dv = 0.; \
      for (int t=1; t<=N; t++) { \
        dv += d0t[t]*(a*I3D##n##t(0, t) - b*I3D##n##t(1, t)); \
      } \
      dv *= xn; \
      sum1 += dv;

      stepI4D(3,5.,2.)
      if (   fabs(sum1.real()*teps)>=fabs(dv.real())
          && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
        break;
      sum[1] = sump = sum1;
      s21 = sum[1]-sum[0];

      stepI4D(4,35.,24.)
      sump = sum1;
      stepWynn(0)
      stepI4D(5,315.,286.)
      stepWynn(1)
      stepI4D(6,3465.,3776.)
      stepWynn(2)
      stepI4D(7,45045.,56018.)
      stepWynn(3)
//       stepI4D(8,675675.,930360.)
//       stepWynn(4)
//       stepI4D(9,11486475.,17167470.)
//       stepWynn(5)
#undef stepI4D
    } while (0);
    ivalue = sump/M1(0, 0);
  } else {
    // NORMAL
    ncomplex sum1 = 0.;
    for (int t=1; t<=N; t++) {
      sum1 -= M1(0, t)*I3Dt(ep, t);
    }
    sum1 += M1(0, 0)*ID1(ep);
    ivalue = sum1/(3.*M0())+ndouble(1.)/9.; // +2*(1/6)/3
  }
  pID2[ep] = ivalue;
}

/* --------------------------------------------------------
 *   box in D+6 dim
 * --------------------------------------------------------
 */
void Minor4::ID3Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (ep==0) {
    if (qSmallGram) {
      // EXP
      const double x = M0()/M1(0, 0);
      ncomplex sump;
      do {
        assert(ep==0);

        double d0t[N+1];
        ncomplex sum1 = 0.;
        for (int t=1; t<=N; t++) {
          d0t[t] = M1(0, t);
          sum1 += d0t[t]*I3D3t(0, t);
        }

        double xn = 1.;
        ncomplex dv, s21;

        ncomplex sum[3];
        sum[0] = sump = sum1;

#define stepI4D(n,a,b) \
        xn *= x; \
        dv = 0.; \
        for (int t=1; t<=N; t++) { \
          dv += d0t[t]*(a*I3D##n##t(0, t) - b*I3D##n##t(1, t)); \
        } \
        dv *= xn; \
        sum1 += dv;

        stepI4D(4,7.,2.)
        if (   fabs(sum1.real()*teps)>=fabs(dv.real())
            && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
          break;
        sum[1] = sump = sum1;
        s21 = sum[1]-sum[0];

        stepI4D(5,63.,32.)
        sump = sum1;
        stepWynn(0)
        stepI4D(6,693.,478.)
        stepWynn(1)
        stepI4D(7,9009.,7600.)
        stepWynn(2)
//       stepI4D(8,135135.,132018.)
//         stepWynn(3)
//       stepI4D(9,2297295.,2514576.)
//         stepWynn(4)
//       stepI4D(10,43648605.,52371534.)
//         stepWynn(5)
#undef stepI4D
      } while (0);
      ivalue = sump/M1(0, 0);
    } else {
      // NORMAL
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 -= M1(0, t)*I3D2t(ep, t);
      }
      sum1 += M1(0, 0)*ID2(ep);
      ivalue = sum1/(5.*M0()) + 2.*ID3(ep+1)/5.;
    }
  } else {
    assert(ep==1);
    // TODO unroll?
    double sum1 = 0.;
    for (int i=1; i<=N; i++) {
    for (int j=i; j<=N; j++) {
      sum1 += Cay[nss(i,j)];
    }
    }
    ivalue = -sum1/120.;
  }
  pID3[ep] = ivalue;
}

/* --------------------------------------------------------
 *   box in D+8 dim
 * --------------------------------------------------------
 */
void Minor4::ID4Eval(int ep)
{
  ncomplex ivalue = 0.;

  if (ep==0) {
    if (qSmallGram) {
      // EXP
      const double x = M0()/M1(0, 0);
      ncomplex sump;
      do {
        assert(ep==0);

        double d0t[N+1];
        ncomplex sum1 = 0.;
        for (int t=1; t<=N; t++) {
          d0t[t] = M1(0, t);
          sum1 += d0t[t]*I3D4t(0, t);
        }

        double xn = 1.;
        ncomplex dv, s21;

        ncomplex sum[3];
        sum[0] = sump = sum1;

#define stepI4D(n,a,b) \
        xn *= x; \
        dv = 0.; \
        for (int t=1; t<=N; t++) { \
          dv += d0t[t]*(a*I3D##n##t(0, t) - b*I3D##n##t(1, t)); \
        } \
        dv *= xn; \
        sum1 += dv;

        stepI4D(5,9.,2.)
        if (   fabs(sum1.real()*teps)>=fabs(dv.real())
            && fabs(sum1.imag()*teps)>=fabs(dv.imag()))
          break;
        sum[1] = sump = sum1;
        s21 = sum[1]-sum[0];

        stepI4D(6,99.,40.)
        sump = sum1;
        stepWynn(0)
        stepI4D(7,1287.,718.)
        stepWynn(1)
//         stepI4D(8,19305.,13344.)
//         stepWynn(2)
//         stepI4D(9,328185.,265458.)
//         stepWynn(3)
//         stepI4D(10,6235515.,5700072.)
//         stepWynn(4)
//         stepI4D(11,130945815.,132172542.)
//         stepWynn(5)
#undef stepI4D
      } while (0);
      ivalue = sump/M1(0, 0);
    } else {
      // NORMAL
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 -= M1(0, t)*I3D3t(ep, t);
      }
      sum1 += M1(0, 0)*ID3(ep);
      ivalue = sum1/(7.*M0())+2.*ID4(ep+1)/7.;
    }
  } else {
    assert(ep==1);
    // TODO unroll?
    double sum1 = 0.;
    for (int i=1; i<=N; i++) {
    for (int j=i; j<=N; j++) {
    for (int k=j; k<=N; k++) {
    for (int l=k; l<=N; l++) {
      sum1 += +Cay[nss(i,j)]*Cay[nss(k,l)]
              +Cay[nss(i,k)]*Cay[nss(j,l)]
              +Cay[nss(i,l)]*Cay[nss(j,k)];
    }
    }
    }
    }
    ivalue=sum1/5040.;
  }
  pID4[ep] = ivalue;
}

/* --------------------------------------------------------
 *   box in D+2 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor4::IDi(int ep, int i)  // IR-div
{
  if (ep>2) return 0;
  if (not fEval[E_Di+ep]) {
    IDiEval(ep);
  }
  return pIDi[ep][i-1];
}

void Minor4::IDiEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, i)*I3t(ep, t);
      }
      sum1 -= M1(0, i)*ID1(ep);
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, i)*I3t(ep, t);
      }
      sum1 -= M1(0, i)*ID0(ep);
      ivalue = sum1/M0();
    }
    pIDi[ep][i-1] = ivalue;
  }
  fEval[E_Di+ep] = true;
}

/* --------------------------------------------------------
 *   box in D+4 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor4::ID2i(int ep, int i)  // finite
{
  if (ep!=0) return 0.;  // I4D2si is finite
  if (not fEval[E_D2i+ep]) {
    ID2iEval(ep);
  }
  return pID2i[ep][i-1];
}

void Minor4::ID2iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, i)*I3Dt(ep, t);
      }
      sum1 += M1(0, i)*(-3.*ID2(ep)+ndouble(1.)/3.); // 1/3 == 2*1/6
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, i)*I3Dt(ep, t);
      }
      sum1 -= M1(0, i)*ID1(ep);
      ivalue = sum1/M0();
    }
    pID2i[ep][i-1] = ivalue;
  }
  fEval[E_D2i+ep] = true;
}

/* --------------------------------------------------------
 *   ID2ij box in D+4 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor4::ID2ij(int ep, int i, int j)  // IR-div
{
  assert(ep<=2); // if (ep>2) return 0;
  if (not fEval[E_D2ij+ep]) {
    ID2ijEval(ep);
  }
  return pID2ij[ep][ns(i,j)];
}

void Minor4::ID2ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, j)*I3Dti(ep, t, i);
      }
      sum1 += M2(0, i, 0, j)*ID1(ep);
      sum1 += M1(0, j)*(-2.*ID2i(ep, i));
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, j)*I3Dti(ep, t, i);
      }
      sum1 += M1(i, j)*ID1(ep);
      sum1 -= M1(0, j)*IDi(ep, i);
      ivalue = sum1/M0();
    }
    pID2ij[ep][nss(i,j)] = ivalue;
  }
  }
  fEval[E_D2ij+ep] = true;
}


/* --------------------------------------------------------
 *   ID3ij box in D+4 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor4::ID3ij(int ep, int i, int j)  // finite
{
  if (ep!=0) return 0.;  // ID3ij is finite
  if (not fEval[E_D3ij+ep]) {
    ID3ijEval(ep);
  }
  return pID3ij[ep][ns(i,j)];
}

void Minor4::ID3ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, j)*I3D2ti(ep, t, i);
      }
      sum1 += M2(0, i, 0, j)*ID2(ep);
      sum1 += M1(0, j)*(-4.*ID3i(ep, i) + EPSCAP(2.*ID3i(ep+1, i)));  // EPSCAP not needed
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, j)*I3D2ti(ep, t, i);
      }
      sum1 += M1(i, j)*ID2(ep);
      sum1 -= M1(0, j)*ID2i(ep, i);
      ivalue = sum1/M0();
    }
    pID3ij[ep][nss(i,j)] = ivalue;
  }
  }
  fEval[E_D3ij+ep] = true;
}

/* --------------------------------------------------------
 *   ID4sij box in D+8 dim with two dots
 * --------------------------------------------------------
 */
ncomplex Minor4::ID4ij(int ep, int i, int j)
{
  if      (ep==1) return ( i==j ? ndouble(1.)/60. : ndouble(1.)/120. );
  else if (ep>=2) return 0;
  if (not fEval[E_D4ij+ep]) {
    ID4ijEval(ep);
  }
  return pID4ij[ep][ns(i,j)];
}

void Minor4::ID4ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, j)*I3D3ti(ep, t, i);
      }
      sum1 += M2(0, i, 0, j)*ID3(ep);
      sum1 += M1(0, j)*(-6.*ID4i(ep, i) + EPSCAP(2.*ID4i(ep+1, i)));  // EPSCAP not needed
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, j)*I3D3ti(ep, t, i);
      }
      sum1 += M1(i, j)*ID3(ep);
      sum1 -= M1(0, j)*ID3i(ep, i);
      ivalue = sum1/M0();
    }
    pID4ij[ep][nss(i,j)] = ivalue;
  }
  }
  fEval[E_D4ij+ep] = true;
}


/* --------------------------------------------------------
 *   ID3ijk box in D+6 dim with three dots
 * --------------------------------------------------------
 */
ncomplex Minor4::ID3ijk(int ep, int i, int j, int k) // IR-div
{
  assert(ep<=2); // if (ep>2) return 0;
  if (not fEval[E_D3ijk+ep]) {
    ID3ijkEval(ep);
  }
  return pID3ijk[ep][is(i-1,j-1,k-1)];
}

void Minor4::ID3ijkEval(int ep)
{
  // symmetric in 'i,j,k'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
    ncomplex ivalue=0;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, k)*I3D2tij(ep, t, i, j);
      }
      sum1 += M2(0, i, 0, k)*ID2i(ep, j)
             +M2(0, j, 0, k)*ID2i(ep, i);
      sum1 += M1(0, k)*(-3.*ID3ij(ep, i, j) + EPSCAP(2.*ID3ij(ep+1, i, j)));
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, k)*I3D2tij(ep,t,i,j);
      }
      sum1 -= M1(0, k)*ID2ij(ep, i, j);
      sum1 += M1(i, k)*ID2i(ep, j) + M1(j, k)*ID2i(ep, i);
      ivalue = sum1/M0();
    }
    pID3ijk[ep][iss(i-1,j-1,k-1)] = ivalue;
  }
  }
  }
  fEval[E_D3ijk+ep] = true;
}

/* --------------------------------------------------------
 *   ID3i box in D+6 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor4::ID3i(int ep, int i)
{
  if      (ep==1) return ndouble(-1.)/24.;
  else if (ep>=2) return 0.;
  if (not fEval[E_D3i+ep]) {
    ID3iEval(ep);
  }
  return pID3i[ep][i-1];
}

void Minor4::ID3iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, i)*I3D2t(ep, t);
      }
      sum1 += M1(0, i)*(-5.*ID3(ep) + EPSCAP(2.*ID3(ep+1)));  // EPSCAP not needed
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, i)*I3D2t(ep, t);
      }
      sum1 -= M1(0, i)*ID2(ep);
      ivalue = sum1/M0();
    }
    pID3i[ep][i-1] = ivalue;
  }
  fEval[E_D3i+ep] = true;
}

/* --------------------------------------------------------
 *   ID4si box in D+8 dim with a dot
 * --------------------------------------------------------
 */
ncomplex Minor4::ID4i(int ep, int i)
{
  if (ep>=2) return 0.;
  if (not fEval[E_D4i+ep]) {
    ID4iEval(ep);
  }
  return pID4i[ep][i-1];
}

void Minor4::ID4iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex ivalue = 0.;

    // TODO maybe put this "if" out of the loop
    if (ep == 0) {
      if (qSmallGram) {
        ncomplex sum1 = 0.;
        for (int t=1; t<=N; t++) {
          sum1 += M2(0, t, 0, i)*I3D3t(ep, t);
        }
        sum1 += M1(0, i)*(-7.*ID4(ep) + 2.*ID4(ep+1));
        ivalue = sum1/M1(0, 0);
      } else {
        ncomplex sum1 = 0.;
        for (int t=1; t<=N; t++) {
          sum1 += M1(t, i)*I3D3t(ep, t);
        }
        sum1 -= M1(0, i)*ID3(ep);
        ivalue = sum1/M0();
      }
    } else {
      assert(ep==1);
      // TODO unroll?
      double sum1 = 0;
      sum1 += Cay[nss(i,i)];
      for (int j=1; j<=N; j++) {
        sum1 += Cay[ns(i,j)];
        for (int k=j; k<=N; k++) {
          sum1 += Cay[nss(j,k)];
        }
      }
      ivalue = sum1/720.;
    }
    pID4i[ep][i-1] = ivalue;
  }
  fEval[E_D4i+ep] = true;
}

/* --------------------------------------------------------
 *   ID4ijk box in D+8 dim with three dots
 * --------------------------------------------------------
 */
ncomplex Minor4::ID4ijk(int ep, int i, int j, int k)  // finite
{
  if (ep!=0) return 0.;  // I4D4sijk is finite
  if (not fEval[E_D4ijk+ep]) {
    ID4ijkEval(ep);
  }
  return pID4ijk[ep][is(i-1,j-1,k-1)];
}

void Minor4::ID4ijkEval(int ep)
{
  // symmetric in 'i,j,k'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, k)*I3D3tij(ep, t, i, j);
      }
      sum1 += M2(0, i, 0, k)*ID3i(ep, j)
             +M2(0, j, 0, k)*ID3i(ep, i);
      sum1 += M1(0, k)*(-5.*ID4ij(ep, i, j) + EPSCAP(2.*ID4ij(ep+1, i, j)));  // EPSCAP not needed
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, k)*I3D3tij(ep, t, i, j);
      }
      sum1 -= M1(0, k)*ID3ij(ep, i, j);
      sum1 += M1(i, k)*ID3i(ep, j) + M1(j, k)*ID3i(ep, i);
      ivalue = sum1/M0();
    }
    pID4ijk[ep][iss(i-1,j-1,k-1)] = ivalue;
  }
  }
  }
  fEval[E_D4ijk+ep] = true;
}

/* --------------------------------------------------------
 *   ID4ijkl box in D+8 dim with four dots
 * --------------------------------------------------------
 */
ncomplex Minor4::ID4ijkl(int ep, int i, int j, int k, int l) // IR-div
{
  assert(ep<=2);  // if (ep>2) return 0.;
  if (not fEval[E_D4ijkl+ep]) {
    ID4ijklEval(ep);
  }
  return pID4ijkl[ep][is(i-1,j-1,k-1,l-1)];
}

void Minor4::ID4ijklEval(int ep)
{
  // symmetric in 'i,j,k,l'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  for (int l=k; l<=CIDX; l++) {
    ncomplex ivalue = 0.;

    if (qSmallGram) {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M2(0, t, 0, l)*I3D3tijk(ep, t, i, j, k);
      }
      sum1 += M2(0, i, 0, l)*ID3ij(ep, j, k)
             +M2(0, j, 0, l)*ID3ij(ep, i, k)
             +M2(0, k, 0, l)*ID3ij(ep, i, j);
      sum1 += M1(0, l)*(-4.*ID4ijk(ep, i, j, k) + EPSCAP(2.*ID4ijk(ep+1, i, j, k)));
      ivalue = sum1/M1(0, 0);
    } else {
      ncomplex sum1 = 0.;
      for (int t=1; t<=N; t++) {
        sum1 += M1(t, l)*I3D3tijk(ep, t, i, j, k);
      }
      sum1 -= M1(0, l)*ID3ijk(ep, i, j, k);
      sum1 += M1(i, l)*ID3ij(ep, j, k)
             +M1(j, l)*ID3ij(ep, i, k)
             +M1(k, l)*ID3ij(ep, i, j);
      ivalue = sum1/M0();
    }
    pID4ijkl[ep][iss(i-1,j-1,k-1,l-1)] = ivalue;
  }
  }
  }
  }
  fEval[E_D4ijkl+ep] = true;
}


/* Undefine local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 */
#undef pM0
#undef pM1
#undef pM2
#undef evalM1
#undef evalM2
#undef DM1
#undef DM2
