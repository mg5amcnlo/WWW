/*
 * lorentz.h - lorentz tensor classes header
 *
 * this file is part of PJFry library
 * Copyright 2012 Valery Yundin
 */

#ifndef QUL_LORENTZ_H
#define QUL_LORENTZ_H

#include <complex>

// size of symmetric RANK tensor of dimension DIM
template <int RANK, int DIM>
class STensorLEN
{
  public:
    // LEN(R,D) = (R+D-1)!/R!/(D-1)!
    static const int LEN = STensorLEN<RANK-1,DIM>::LEN*(DIM+RANK-1)/RANK;
    static const int SIZE = STensorLEN<RANK-1,DIM>::SIZE + LEN;
};
template <int DIM>
class STensorLEN<0, DIM>
{
  public:
    static const int LEN = 1;
    static const int SIZE = 1;
};

// Symmetric RANK tensor of dimension DIM and type CLS, with elements of type T
template <int RANK, int DIM, class CLS, typename T>
class STensor
{
  public:
    static const int LEN = STensorLEN<RANK,DIM>::LEN;
    STensor() {}
    STensor(const T data_[]) {
      for (int i=0; i<LEN; i++) {
        data[i] = data_[i];
      }
    }

    template <typename U>
    struct rebind { typedef typename CLS::template rebind<U>::other other; };

    CLS& operator- () {
      for (int i=0; i<LEN; i++) {
        data[i] = -data[i];
      }
      return static_cast<CLS&>(*this);
    }

    CLS& operator+= (const CLS& t1) {
      for (int i=0; i<LEN; i++) {
        data[i] += t1.data[i];
      }
      return static_cast<CLS&>(*this);
    }
    CLS& operator-= (const CLS& t1) {
      for (int i=0; i<LEN; i++) {
        data[i] -= t1.data[i];
      }
      return static_cast<CLS&>(*this);
    }
    // could be a template, but need C++0x <type_traits>
    CLS& operator*= (const double& x) {
      for (int i=0; i<LEN; i++) {
        data[i] *= x;
      }
      return static_cast<CLS&>(*this);
    }
    CLS& operator/= (const double& x) {
      for (int i=0; i<LEN; i++) {
        data[i] /= x;
      }
      return static_cast<CLS&>(*this);
    }

    bool operator== (const CLS& t1) const {
      for (int i=0; i<LEN; i++) {
        if (data[i] != t1.data[i]) return false;
      }
      return true;
    }
    bool operator!= (const CLS& t1) const {
      return !(*this == t1);
    }

    std::ostream& output(std::ostream& os) const {
      os << data[0];
      for (int i=1; i<LEN; i++) {
        os << " " << data[i];
      }
      return os;
    }
    friend std::ostream& operator<< (std::ostream& os, const CLS& obj) {
      return obj.output(os);
    }

    T operator() (int i) const {
      assert(RANK==1);
      return data[i];
    }
    T operator() (int i, int j) const {
      assert(RANK==2);
      assert(i<=j);
      return data[i+j*(j+1)/2];
    }
    T operator() (int i, int j, int k) const {
      assert(RANK==3);
      assert(i<=j && j<=k);
      return data[i+j*(j+1)/2+k*(k+1)*(k+2)/6];
    }
    T operator() (int i, int j, int k, int l) const {
      assert(RANK==4);
      assert(i<=j && j<=k && k<=l);
      return data[i+j*(j+1)/2+k*(k+1)*(k+2)/6+l*(l+1)*(l+2)*(l+3)/24];
    }
    T operator() (int i, int j, int k, int l, int m) const {
      assert(RANK==5);
      assert(i<=j && j<=k && k<=l && l<=m);
      return data[i+j*(j+1)/2+k*(k+1)*(k+2)/6+l*(l+1)*(l+2)*(l+3)/24+m*(m+1)*(m+2)*(m+3)*(m+4)/120];
    }
    T operator() (int i, int j, int k, int l, int m, int n) const {
      assert(RANK==6);
      assert(i<=j && j<=k && k<=l && l<=m && m<=n);
      return data[i+j*(j+1)/2+k*(k+1)*(k+2)/6+l*(l+1)*(l+2)*(l+3)/24+m*(m+1)*(m+2)*(m+3)*(m+4)/120+n*(n+1)*(n+2)*(n+3)*(n+4)*(n+5)/720];
    }
    T data[LEN];
};

template <int RANK, int DIM, class CLS, typename T>
CLS operator* (const STensor<RANK,DIM,CLS,T>& t1, const double& x)
{
  CLS t2 = CLS(static_cast<const CLS&>(t1));
  t2 *= x;
  return t2;
}
template <int RANK, int DIM, class CLS, typename T>
CLS operator* (const double& x, const STensor<RANK,DIM,CLS,T>& t1)
{
  return t1*x;
}

template <int RANK, int DIM, class CLS, typename T>
CLS operator/ (const STensor<RANK,DIM,CLS,T>& t1, const double& x)
{
  CLS t2 = CLS(static_cast<const CLS&>(t1));
  t2 /= x;
  return t2;
}


// the following can be nicer with type_traits (maybe) make this a member?
// TODO maybe keep U=T always
template <int RANK, int DIM, class CLS, typename T, typename U>
typename CLS::template rebind<std::complex<U> >::other
operator* (const STensor<RANK,DIM,CLS,T>& t1, const std::complex<U>& x)
{
  std::complex<U> data[CLS::LEN];
  for (int i=0; i<CLS::LEN; i++) {
    data[i] = t1.data[i] * x;
  }
  return typename CLS::template rebind<std::complex<U> >::other(data);
}
template <int RANK, int DIM, class CLS, typename T, typename U>
typename CLS::template rebind<std::complex<U> >::other
operator* (const std::complex<U>& x, const STensor<RANK,DIM,CLS,T>& t1)
{
  return t1*x;
}

template <int RANK, int DIM, class CLS, typename T, typename U>
typename CLS::template rebind<std::complex<U> >::other
operator/ (const STensor<RANK,DIM,CLS,T>& t1, const std::complex<U>& x)
{
  std::complex<U> data[CLS::LEN];
  for (int i=0; i<CLS::LEN; i++) {
    data[i] = t1.data[i] / x;
  }
  return typename CLS::template rebind<std::complex<U> >::other(data);
}

template <int RANK, int DIM, class CLS, typename T>
CLS operator+ (const STensor<RANK,DIM,CLS,T>& t1, const CLS& t2)
{
  CLS t3 = CLS(static_cast<const CLS&>(t1));
  t3 += t2;
  return t3;
}

template <int RANK, int DIM, class CLS, typename T>
CLS operator- (const STensor<RANK,DIM,CLS,T>& t1, const CLS& t2)
{
  CLS t3 = CLS(static_cast<const CLS&>(t1));
  t3 -= t2;
  return t3;
}

// Symmetric lorentz tensor (covariant basis element)
template <int RANK, int DIM, typename T>
class SLTensor : public STensor<RANK, DIM, SLTensor<RANK,DIM,T>, T>
{
  public:
    typedef STensor<RANK, DIM, SLTensor<RANK,DIM,T>, T> Base;
    using Base::LEN;
    using Base::data;
    template <typename U> struct rebind { typedef SLTensor<RANK,DIM,U> other; };
    SLTensor() {}
    SLTensor(const T data_[]) : Base(data_) {}
};

template <typename T>
class SLTensor<1, 4, T> : public STensor<1, 4, SLTensor<1,4,T>, T>
{
  public:
    typedef STensor<1, 4, SLTensor<1,4,T>, T> Base;
    using Base::LEN;
    using Base::data;
    template <typename U> struct rebind { typedef SLTensor<1,4,U> other; };
    SLTensor() {}
    SLTensor(const T data_[]) : Base(data_) {}

    SLTensor(T a0, T a1, T a2, T a3) {
      data[0] = a0;
      data[1] = a1;
      data[2] = a2;
      data[3] = a3;
    }

    T sq() const {
      return data[0]*data[0]-(data[1]*data[1]+data[2]*data[2]+data[3]*data[3]);
    }
};

template <typename T>
class SLTensor<2, 4, T> : public STensor<2, 4, SLTensor<2,4,T>, T>
{
  public:
    typedef STensor<2, 4, SLTensor<2,4,T>, T> Base;
    using Base::LEN;
    using Base::data;
    template <typename U> struct rebind { typedef SLTensor<2,4,U> other; };
    SLTensor() {}
    SLTensor(const T data_[]) : Base(data_) {}

    SLTensor(T a0, T a1, T a2, T a3) {
      data[0] = a0;
      data[1] = T();
      data[2] = a1;
      data[3] = data[4] = T();
      data[5] = a2;
      data[6] = data[7] = data[8] = T();
      data[9] = a3;
    }
};

// Symmetric outer product, e.g. p_a*p_b -> p_ab + p_ba
template <int DIM, typename T>
SLTensor<2,DIM,T> operator* (const SLTensor<1,DIM,T>& a1, const SLTensor<1,DIM,T>& b1)
{
  double data[SLTensor<2,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<i; j++) {
      data[idx++] = a1(i)*b1(j) + a1(j)*b1(i);
    }
    data[idx++] = 2.*a1(i)*b1(i);
  }
  return SLTensor<2,DIM,T>(data);
}

template <int DIM, typename T>
SLTensor<3,DIM,T> operator* (const SLTensor<1,DIM,T>& a1, const SLTensor<2,DIM,T>& b2)
{
  double data[SLTensor<3,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<i; j++) {  // can be j<=i if removed i==j special case below
      for (int k=0; k<j; k++) {
        data[idx++] = a1(i)*b2(k, j) + a1(j)*b2(k, i) + a1(k)*b2(j, i);  // k < j < i
      }
      data[idx++] = a1(i)*b2(j, j) + 2.*a1(j)*b2(j, i); // k==j
    }
    // i==j
    for (int k=0; k<i; k++) {
      data[idx++] = a1(k)*b2(i, i) + 2.*a1(i)*b2(k, i);  // k < j == i
    }
    data[idx++] = 3.*a1(i)*b2(i, i); // k==j==i
  }
  return SLTensor<3,DIM,T>(data);
}

template <int DIM, typename T>
SLTensor<4,DIM,T> operator* (const SLTensor<1,DIM,T>& a1, const SLTensor<3,DIM,T>& b3)
{
  double data[SLTensor<4,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          data[idx++] = a1(i)*b3(l, k, j)
                       +a1(j)*b3(l, k, i)
                       +a1(k)*b3(l, j, i)
                       +a1(l)*b3(k, j, i);  // l <= k <= j <= i
        }
      }
    }
  }
  return SLTensor<4,DIM,T>(data);
}

template <int DIM, typename T>
SLTensor<5,DIM,T> operator* (const SLTensor<1,DIM,T>& a1, const SLTensor<4,DIM,T>& b4)
{
  double data[SLTensor<5,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          for (int m=0; m<=l; m++) {
            data[idx++] = a1(i)*b4(m, l, k, j)
                         +a1(j)*b4(m, l, k, i)
                         +a1(k)*b4(m, l, j, i)
                         +a1(l)*b4(m, k, j, i)
                         +a1(m)*b4(l, k, j, i);  // m <= l <= k <= j <= i
          }
        }
      }
    }
  }
  return SLTensor<5,DIM,T>(data);
}

template <int DIM, typename T>
SLTensor<6,DIM,T> operator* (const SLTensor<1,DIM,T>& a1, const SLTensor<5,DIM,T>& b5)
{
  double data[SLTensor<6,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          for (int m=0; m<=l; m++) {
            for (int n=0; n<=m; n++) {
              data[idx++] = a1(i)*b5(n, m, l, k, j)
                           +a1(j)*b5(n, m, l, k, i)
                           +a1(k)*b5(n, m, l, j, i)
                           +a1(l)*b5(n, m, k, j, i)
                           +a1(m)*b5(n, l, k, j, i)
                           +a1(n)*b5(m, l, k, j, i);  // n <= m <= l <= k <= j <= i
            }
          }
        }
      }
    }
  }
  return SLTensor<6,DIM,T>(data);
}

template <int RANK, int DIM, typename T>
SLTensor<RANK+1,DIM,T> operator* (const SLTensor<RANK,DIM,T>& bR, const SLTensor<1,DIM,T>& a1)
{
  return a1*bR;
}

template <int DIM, typename T>
SLTensor<4,DIM,T> operator* (const SLTensor<2,DIM,T>& a2, const SLTensor<2,DIM,T>& b2)
{
  double data[SLTensor<4,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          data[idx++] = a2(j, i)*b2(l, k)
                       +a2(k, i)*b2(l, j)
                       +a2(l, i)*b2(k, j)
                       +b2(j, i)*a2(l, k)
                       +b2(k, i)*a2(l, j)
                       +b2(l, i)*a2(k, j);  // l <= k <= j <= i
        }
      }
    }
  }
  return SLTensor<4,DIM,T>(data);
}

template <int DIM, typename T>
SLTensor<5,DIM,T> operator* (const SLTensor<2,DIM,T>& a2, const SLTensor<3,DIM,T>& b3)
{
  double data[SLTensor<5,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          for (int m=0; m<=l; m++) {
            data[idx++] =  a2(j, i)*b3(m, l, k)
                          +a2(k, i)*b3(m, l, j)
                          +a2(l, i)*b3(m, k, j)
                          +a2(m, i)*b3(l, k, j)
                          +a2(k, j)*b3(m, l, i)
                          +a2(l, j)*b3(m, k, i)
                          +a2(m, j)*b3(l, k, i)
                          +a2(l, k)*b3(m, j, i)
                          +a2(m, k)*b3(l, j, i)
                          +a2(m, l)*b3(k, j, i);  // m <= l <= k <= j <= i
          }
        }
      }
    }
  }
  return SLTensor<5,DIM,T>(data);
}
template <int DIM, typename T>
SLTensor<5,DIM,T> operator* (const SLTensor<3,DIM,T>& b3, const SLTensor<2,DIM,T>& a2)
{
  return a2*b3;
}


template <int DIM, typename T>
SLTensor<6,DIM,T> operator* (const SLTensor<2,DIM,T>& a2, const SLTensor<4,DIM,T>& b4)
{
  double data[SLTensor<6,DIM,T>::LEN];
  int idx = 0;
  for (int i=0; i<DIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          for (int m=0; m<=l; m++) {
            for (int n=0; n<=m; n++) {
              data[idx++] = a2(j, i)*b4(n, m, l, k)
                           +a2(k, i)*b4(n, m, l, j)
                           +a2(l, i)*b4(n, m, k, j)
                           +a2(m, i)*b4(n, l, k, j)
                           +a2(n, i)*b4(m, l, k, j)
                           +a2(k, j)*b4(n, m, l, i)
                           +a2(l, j)*b4(n, m, k, i)
                           +a2(m, j)*b4(n, l, k, i)
                           +a2(n, j)*b4(m, l, k, i)
                           +a2(l, k)*b4(n, m, j, i)
                           +a2(m, k)*b4(n, l, j, i)
                           +a2(n, k)*b4(m, l, j, i)
                           +a2(m, l)*b4(n, k, j, i)
                           +a2(n, l)*b4(m, k, j, i)
                           +a2(n, m)*b4(l, k, j, i);  // n <= m <= l <= k <= j <= i
            }
          }
        }
      }
    }
  }
  return SLTensor<6,DIM,T>(data);
}
template <int DIM, typename T>
SLTensor<6,DIM,T> operator* (const SLTensor<4,DIM,T>& b4, const SLTensor<2,DIM,T>& a2)
{
  return a2*b4;
}

// ==============================================================================
// Contractions of lorentz tensors in 4-dim with 1,-1,-1,-1 signature

template <typename T, typename U>
U dotTU(const SLTensor<1,4,T>& a1, const SLTensor<1,4,U>& b1)
{
  return a1.data[0]*b1.data[0]-(a1.data[1]*b1.data[1]+a1.data[2]*b1.data[2]+a1.data[3]*b1.data[3]);
}

template <typename T>
T dot(const SLTensor<1,4,T>& a1, const SLTensor<1,4,T>& b1)
{
  return dotTU(a1, b1);
}
template <typename T>
std::complex<T> dot(const SLTensor<1,4,T>& a1, const SLTensor<1,4,std::complex<T> >& b1)
{
  return dotTU(a1, b1);
}
template <typename T>
std::complex<T> dot(const SLTensor<1,4,std::complex<T> >& a1, const SLTensor<1,4,T>& b1)
{
  return dotTU(b1, a1);
}

template <typename T, typename U>
SLTensor<1,4,U> dotTU(const SLTensor<1,4,T>& a1, const SLTensor<2,4,U>& b2)
{
  U data[SLTensor<1,4,U>::LEN];
  int idx = 0;
  int idx0 = 0;
  int idx2 = 3;  // 2,2 len
  int idx3 = 6;  // 2,3 len
  for (int i=0; i<4; i++) {
    if (i==3) idx2 += 2;
    for (int j=0; j<=i; j+=i+1) {
      data[idx++] = a1.data[0]*b2.data[idx0]
                   -( a1.data[1]*b2.data[idx0+1]
                     +a1.data[2]*b2.data[idx2++]
                     +a1.data[3]*b2.data[idx3++]);
      idx0 += i+1;
    }
  }
  return SLTensor<1,4,U>(data);
}

template <typename T, typename U>
SLTensor<2,4,U> dotTU(const SLTensor<1,4,T>& a1, const SLTensor<3,4,U>& b3)
{
  U data[SLTensor<2,4,U>::LEN];
  int idx = 0;
  int idx0 = 0;
  int idx2 = 4;   // 3,2 len
  int idx3 = 10;  // 3,3 len
  for (int i=0; i<4; i++) {
    if (i==3) idx2 += 3;
    for (int j=0; j<=i; j++) {
      if (j==3) idx2 += 2;
      for (int k=0; k<=j; k+=j+1) {
        data[idx++] = a1.data[0]*b3.data[idx0]
                     -( a1.data[1]*b3.data[idx0+1]
                       +a1.data[2]*b3.data[idx2++]
                       +a1.data[3]*b3.data[idx3++]);
        idx0 += j+1;
      }
    }
  }
  return SLTensor<2,4,U>(data);
}

template <typename T, typename U>
SLTensor<3,4,U> dotTU(const SLTensor<1,4,T>& a1, const SLTensor<4,4,U>& b4)
{
  U data[SLTensor<3,4,U>::LEN];
  int idx = 0;
  int idx0 = 0;
  int idx2 = 5;   // 4,2 len
  int idx3 = 15;  // 4,3 len
  for (int i=0; i<4; i++) {
    if (i==3) idx2 += 4;
    for (int j=0; j<=i; j++) {
      if (j==3) idx2 += 3;
      for (int k=0; k<=j; k++) {
        if (k==3) idx2 += 2;
        for (int l=0; l<=k; l+=k+1) {
          data[idx++] = a1.data[0]*b4.data[idx0]
                       -( a1.data[1]*b4.data[idx0+1]
                         +a1.data[2]*b4.data[idx2++]
                         +a1.data[3]*b4.data[idx3++]);
          idx0 += k+1;
        }
      }
    }
  }
  return SLTensor<3,4,U>(data);
}

template <typename T, typename U>
SLTensor<4,4,U> dotTU(const SLTensor<1,4,T>& a1, const SLTensor<5,4,U>& b5)
{
  U data[SLTensor<4,4,U>::LEN];
  int idx = 0;
  int idx0 = 0;
  int idx2 = 6;   // 5,2 len
  int idx3 = 21;  // 5,3 len
  for (int i=0; i<4; i++) {
    if (i==3) idx2 += 5;
    for (int j=0; j<=i; j++) {
      if (j==3) idx2 += 4;
      for (int k=0; k<=j; k++) {
        if (k==3) idx2 += 3;
        for (int l=0; l<=k; l++) {
          if (l==3) idx2 += 2;
          for (int m=0; m<=l; m+=l+1) {
            data[idx++] = a1.data[0]*b5.data[idx0]
                         -( a1.data[1]*b5.data[idx0+1]
                           +a1.data[2]*b5.data[idx2++]
                           +a1.data[3]*b5.data[idx3++]);
            idx0 += l+1;
          }
        }
      }
    }
  }
  return SLTensor<4,4,U>(data);
}

template <typename T, typename U>
SLTensor<5,4,U> dotTU(const SLTensor<1,4,T>& a1, const SLTensor<6,4,U>& b6)
{
  U data[SLTensor<5,4,U>::LEN];
  int idx = 0;
  int idx0 = 0;
  int idx2 = 7;    // 6,2 len
  int idx3 = 28;   // 6,3 len
  for (int i=0; i<4; i++) {
    if (i==3) idx2 += 6;
    for (int j=0; j<=i; j++) {
      if (j==3) idx2 += 5;
      for (int k=0; k<=j; k++) {
        if (k==3) idx2 += 4;
        for (int l=0; l<=k; l++) {
          if (l==3) idx2 += 3;
          for (int m=0; m<=l; m++) {
            if (m==3) idx2 += 2;
            for (int n=0; n<=m; n+=m+1) {
              data[idx++] = a1.data[0]*b6.data[idx0]
                           -( a1.data[1]*b6.data[idx0+1]
                             +a1.data[2]*b6.data[idx2++]
                             +a1.data[3]*b6.data[idx3++]);
              idx0 += m+1;
            }
          }
        }
      }
    }
  }
  return SLTensor<5,4,U>(data);
}

template <int RANK, typename T>
SLTensor<RANK-1,4,T> dot(const SLTensor<1,4,T>& a1, const SLTensor<RANK,4,T>& bR)
{
  return dotTU(a1, bR);
}
template <int RANK, typename T>
SLTensor<RANK-1,4,T> dot(const SLTensor<RANK,4,T>& bR, const SLTensor<1,4,T>& a1)
{
  return dotTU(a1, bR);
}
template <int RANK, typename T>
SLTensor<RANK-1,4,std::complex<T> > dot(const SLTensor<1,4,T>& a1,
                                        const SLTensor<RANK,4,std::complex<T> >& bR)
{
  return dotTU(a1, bR);
}
template <int RANK, typename T>
SLTensor<RANK-1,4,std::complex<T> > dot(const SLTensor<RANK,4,std::complex<T> >& bR,
                                        const SLTensor<1,4,T>& a1)
{
  return dotTU(a1, bR);
}

// Coefficient tensor
template <int RANK, int DIM, typename T>
class SCTensor : public STensor<RANK, DIM, SCTensor<RANK,DIM,T>, T>
{
  public:
    typedef STensor<RANK, DIM, SCTensor<RANK,DIM,T>, T> Base;
    using Base::LEN;
    using Base::data;
    template <typename U> struct rebind { typedef SCTensor<RANK,DIM,U> other; };
    SCTensor(const T data_[]) : Base(data_) {}
};

// Unique-Symmetric outer product, e.g. p_a*p_b -> a!=b ? p_ab : p_ab/2
template <int CDIM, typename T>
SCTensor<2,CDIM,SLTensor<2,4,T> > operator* (const SCTensor<1,CDIM,SLTensor<1,4,T> >& a1,
                                             const SCTensor<1,CDIM,SLTensor<1,4,T> >& b1)
{
  SLTensor<2,4,T> data[SCTensor<2,CDIM,SLTensor<2,4,T> >::LEN];
  int idx = 0;
  for (int i=0; i<CDIM; i++) {
    for (int j=0; j<i; j++) {
      data[idx++] = a1(i)*b1(j);
    }
    // j == i
    data[idx++] = a1(i)*(b1(i)/2.);
  }
  return SCTensor<2,CDIM,SLTensor<2,4,T> >(data);
}

template <int CDIM, typename T>
SCTensor<3,CDIM,SLTensor<3,4,T> > operator* (const SCTensor<2,CDIM,SLTensor<2,4,T> >& a2,
                                             const SCTensor<1,CDIM,SLTensor<1,4,T> >& b1)
{
  SLTensor<3,4,T> data[SCTensor<3,CDIM,SLTensor<3,4,T> >::LEN];
  int idx = 0;
  for (int i=0; i<CDIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        int fac = 1 + int(k==j) + int(k==i);
        if (fac <= 1) {
          data[idx++] = a2(j,i)*b1(k);
        } else {
          data[idx++] = a2(j,i)*(b1(k)/T(fac));
        }
      }
    }
  }
  return SCTensor<3,CDIM,SLTensor<3,4,T> >(data);
}

template <int CDIM, typename T>
SCTensor<4,CDIM,SLTensor<4,4,T> > operator* (const SCTensor<3,CDIM,SLTensor<3,4,T> >& a3,
                                             const SCTensor<1,CDIM,SLTensor<1,4,T> >& b1)
{
  SLTensor<4,4,T> data[SCTensor<4,CDIM,SLTensor<4,4,T> >::LEN];
  int idx = 0;
  for (int i=0; i<CDIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          int fac = 1 + int(l==k) + int(l==j) + int(l==i);
          if (fac <= 1) {
            data[idx++] = a3(k,j,i)*b1(l);
          } else {
            data[idx++] = a3(k,j,i)*(b1(l)/T(fac));
          }
        }
      }
    }
  }
  return SCTensor<4,CDIM,SLTensor<4,4,T> >(data);
}

template <int CDIM, typename T>
SCTensor<5,CDIM,SLTensor<5,4,T> > operator* (const SCTensor<4,CDIM,SLTensor<4,4,T> >& a4,
                                             const SCTensor<1,CDIM,SLTensor<1,4,T> >& b1)
{
  SLTensor<5,4,T> data[SCTensor<5,CDIM,SLTensor<5,4,T> >::LEN];
  int idx = 0;
  for (int i=0; i<CDIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          for (int m=0; m<=l; m++) {
            int fac = 1 + int(m==l) + int(m==k) + int(m==j) + int(m==i);
            if (fac <= 1) {
              data[idx++] = a4(l,k,j,i)*b1(m);
            } else {
              data[idx++] = a4(l,k,j,i)*(b1(m)/T(fac));
            }
          }
        }
      }
    }
  }
  return SCTensor<5,CDIM,SLTensor<5,4,T> >(data);
}

template <int CDIM, typename T>
SCTensor<6,CDIM,SLTensor<6,4,T> > operator* (const SCTensor<5,CDIM,SLTensor<5,4,T> >& a5,
                                             const SCTensor<1,CDIM,SLTensor<1,4,T> >& b1)
{
  SLTensor<6,4,T> data[SCTensor<6,CDIM,SLTensor<6,4,T> >::LEN];
  int idx = 0;
  for (int i=0; i<CDIM; i++) {
    for (int j=0; j<=i; j++) {
      for (int k=0; k<=j; k++) {
        for (int l=0; l<=k; l++) {
          for (int m=0; m<=l; m++) {
            for (int n=0; n<=m; n++) {
              int fac = 1 + int(n==m) + int(n==l) + int(n==k) + int(n==j) + int(n==i);
              if (fac <= 1) {
                data[idx++] = a5(m,l,k,j,i)*b1(n);
              } else {
                data[idx++] = a5(m,l,k,j,i)*(b1(n)/T(fac));
              }
            }
          }
        }
      }
    }
  }
  return SCTensor<6,CDIM,SLTensor<6,4,T> >(data);
}

// inner product
template <int LRANK, int CRANK, int LDIM, int CDIM, typename T>
SLTensor<LRANK,LDIM,T> operator* (const SCTensor<CRANK,CDIM,SLTensor<LRANK,LDIM,T> >& scsl,
                                  const SCTensor<CRANK,CDIM,T>& sct)
{
  SLTensor<LRANK,LDIM,T> sum = scsl.data[0]*sct.data[0];
  for (int i=1; i < SCTensor<CRANK,CDIM,T>::LEN; i++) {
    sum += scsl.data[i]*sct.data[i];
  }
  return sum;
}

// inner product double/complex
template <int LRANK, int CRANK, int LDIM, int CDIM, typename T>
SLTensor<LRANK,LDIM,std::complex<T> > operator* (const SCTensor<CRANK,CDIM,SLTensor<LRANK,LDIM,T> >& scsl,
                                                 const SCTensor<CRANK,CDIM,std::complex<T> >& sct)
{
  SLTensor<LRANK,LDIM,std::complex<T> > sum = scsl.data[0]*sct.data[0];
  for (int i=1; i < SCTensor<CRANK,CDIM,std::complex<T> >::LEN; i++) {
    sum += scsl.data[i]*sct.data[i];
  }
  return sum;
}

// map-product
template <int CRANK, int LRANK1, int LRANK2, int LDIM, int CDIM, typename T>
SCTensor<CRANK,CDIM,SLTensor<LRANK1+LRANK2,LDIM,T> > operator* (const SCTensor<CRANK,CDIM,SLTensor<LRANK1,LDIM,T> >& sc1,
                                                                const SLTensor<LRANK2,LDIM,T>& sl2)
{
  SLTensor<LRANK1+LRANK2,LDIM,T> data[SCTensor<CRANK,CDIM,SLTensor<LRANK1+LRANK2,LDIM,T> >::LEN];
  for (int i=0; i < SCTensor<CRANK,CDIM,SLTensor<LRANK1,LDIM,T> >::LEN; i++) {
    data[i] = sc1.data[i]*sl2;
  }
  return SCTensor<CRANK,CDIM,SLTensor<LRANK1+LRANK2,LDIM,T> >(data);
}

#endif // QUL_LORENTZ_H
