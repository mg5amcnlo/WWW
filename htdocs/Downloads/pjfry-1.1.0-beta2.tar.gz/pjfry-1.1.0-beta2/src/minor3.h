/*
 * minor3.h - signed minors classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_MINOR3_H
#define QUL_MINOR3_H

#include "minor.h"
#include "minor2.h"
#include "entry.h"
#include "cache.h"

class Minor3 : public Minor<3>
{
  friend class Golem;
  public:
    friend class SPtr<Minor3>;
    typedef SPtr<Minor3> Ptr;
    static Ptr create(const Kinem3 &k) { return Ptr(new Minor3(k)); }

    virtual Tensor::Ptr Sub(int s) { assert(0<s && s<=N); return Tensor::Ptr(mnr2[s-1]); };

    ncomplex evalC(int ep);
    ncomplex evalC(int ep, int i);
    ncomplex evalC(int ep, int i, int j);
    ncomplex evalC(int ep, int i, int j, int k);

    virtual ncomplex A(int ep) { return ID0(ep); }
    virtual ncomplex A(int ep, int i) { return -IDi(ep, i); }
    virtual ncomplex A(int ep, int i, int j) { return ID2ij(ep, i, j); }
    virtual ncomplex A(int ep, int i, int j, int k) { return -ID3ijk(ep, i, j, k); }
    virtual ncomplex B(int ep) { return -0.5*ID1(ep); }
    virtual ncomplex B(int ep, int k) { return 0.5*ID2i(ep, k); }

    virtual const ncomplex* Ai(int ep) { if (not fEval[E_Di+ep]) { IDiEval(ep); } return pIDi[ep]; }
    virtual const ncomplex* Aij(int ep) { if (not fEval[E_D2ij+ep]) { ID2ijEval(ep); } return pID2ij[ep]; }
    virtual const ncomplex* Aijk(int ep) { if (not fEval[E_D3ijk+ep]) { ID3ijkEval(ep); } return pID3ijk[ep]; }
    virtual const ncomplex* Bi(int ep) { if (not (ep>=2 || fEval[E_D2i+ep])) { ID2iEval(ep); } return pID2i[ep]; }

    inline
    ncomplex ID0(int ep) { return pID0[ep]; }
    ncomplex ID1(int ep) { if (pID1[ep].real() == Cache::sNAN) ID1Eval(ep); return pID1[ep]; }
    ncomplex ID2(int ep) { if (pID2[ep].real() == Cache::sNAN) ID2Eval(ep); return pID2[ep]; }
    ncomplex ID3(int ep) { if (pID3[ep].real() == Cache::sNAN) ID3Eval(ep); return pID3[ep]; }
    ncomplex ID4(int ep) { if (pID4[ep].real() == Cache::sNAN) ID4Eval(ep); return pID4[ep]; }
    ncomplex ID5(int ep) { if (pID5[ep].real() == Cache::sNAN) ID5Eval(ep); return pID5[ep]; }
    ncomplex ID6(int ep) { if (pID6[ep].real() == Cache::sNAN) ID6Eval(ep); return pID6[ep]; }
    ncomplex ID7(int ep) { if (pID7[ep].real() == Cache::sNAN) ID7Eval(ep); return pID7[ep]; }

    ncomplex IDi(int ep, int i);
    ncomplex ID2i(int ep, int i);
    ncomplex ID3i(int ep, int i);
    ncomplex ID2ij(int ep, int i, int j);
    ncomplex ID3ij(int ep, int i, int j);
    ncomplex ID3ijk(int ep, int i, int j, int k);

#define ix(i) (i<u ? i : i-1)
    inline ncomplex I2u(int ep, int u) { return mnr2[u-1]->ID0(ep); }
    inline ncomplex I2Du(int ep, int u) { return mnr2[u-1]->ID1(ep); }
    inline ncomplex I2D2u(int ep, int u) { return mnr2[u-1]->ID2(ep); }
    inline ncomplex I2D3u(int ep, int u) { return mnr2[u-1]->ID3(ep); }
    inline ncomplex I2D4u(int ep, int u) { return mnr2[u-1]->ID4(ep); }
    inline ncomplex I2D5u(int ep, int u) { return mnr2[u-1]->ID5(ep); }
    inline ncomplex I2D6u(int ep, int u) { return mnr2[u-1]->ID6(ep); }
    inline ncomplex I2Dui(int ep, int u, int i) { return u==i ? 0. : mnr2[u-1]->IDi(ep, ix(i)); }
    inline ncomplex I2D2ui(int ep, int u, int i) { return u==i ? 0. : mnr2[u-1]->ID2i(ep, ix(i)); }
    inline ncomplex I2D2uij(int ep, int u, int i, int j) { return (u==i || u==j) ? 0. : mnr2[u-1]->ID2ij(ep, ix(i), ix(j)); }
#undef ix

// pMi  - scratched lines numbering
// rrMi - matrix rank numbering
#define pM0 rrM4
#define pM1 rrM3
#define pM2 rrM2
    double M0() PURE { return pM0[0]; }
    double M1(int i, int l) PURE { return pM1[is(i,l)]; }
    double M2r00(int i, int j) PURE;   // M2(0, i, 0, j)
#undef pM0
#undef pM1
#undef pM2

    inline
    double maxCay() { return pmaxCay; }

  private:
    Minor3(const Kinem3 &k);

    const Kinem3 kinem;

    // flags marking evuation steps
    enum EvalM {E_None=0,
                E_M1, E_M2, E_M3,
                                                              E_D4ijk,
                                                       E_D4ij=E_D4ijk+3,
                                                 E_D4i=E_D4ij+3,
                                         E_D3ijk=E_D4i+3,
                                  E_D3ij=E_D3ijk+3,
                            E_D3i=E_D3ij+3,
                     E_D2ij=E_D3i+3,
               E_D2i=E_D2ij+3,
          E_Di=E_D2i+3,
    E_DUM=E_Di+3,
    E_LEN};
    std::bitset<E_LEN> fEval;

    // internally we use rank-notation, ranks 2 and 3 are defined in Minor<N>
    double rrM4[1];

    void ID1Eval(int ep);
    void ID2Eval(int ep);
    void ID3Eval(int ep);
    void ID4Eval(int ep);
    void ID5Eval(int ep);
    void ID6Eval(int ep);
    void ID7Eval(int ep);

    void IDiEval(int ep);
    void ID2iEval(int ep);
    void ID3iEval(int ep);
    void ID2ijEval(int ep);
    void ID3ijEval(int ep);
    void ID3ijkEval(int ep);

    Cache::Ival pID0;
    Cache::Ival pID1;
    Cache::Ival pID2;
    Cache::Ival pID3;
    Cache::Ival pID4;
    Cache::Ival pID5;
    Cache::Ival pID6;
    Cache::Ival pID7;

    ncomplex pIDi[3][CIDX];
    ncomplex pID2i[3][CIDX];
    ncomplex pID3i[3][CIDX];
    ncomplex pID2ij[3][CIDX*(CIDX+1)/2];  // symm 3x3
    ncomplex pID3ij[3][CIDX*(CIDX+1)/2];  // symm 3x3
    ncomplex pID3ijk[3][CIDX*(CIDX+1)*(CIDX+2)/6];  // 3x3x3 symm

    double pmaxCay;
    int imax;

    Minor2::Ptr mnr2[N];

    bool qSmallGram, qTinyGram;
};

typedef Entry< Kinem3, Minor3::Ptr > MEntry3;

#endif /* QUL_MINOR3_H */
