/*
 * minor5.h - signed minors classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_MINOR5_H
#define QUL_MINOR5_H

#include "minor.h"
#include "minor4.h"
#include "entry.h"
#include "cache.h"

class Minor5 : public Minor<5>
{
  friend class Golem;
  public:
    friend class SPtr<Minor5>;
    typedef SPtr<Minor5> Ptr;
    static Ptr create(const Kinem5 &k) { return Ptr(new Minor5(k)); }

    virtual Tensor::Ptr Sub(int s) { assert(0<s && s<=N); return Tensor::Ptr(mnr4[s-1]); };

    ncomplex evalE(int ep);
    ncomplex evalE(int ep, int i);
    ncomplex evalE(int ep, int i, int j);
    ncomplex evalE(int ep, int i, int j, int k);
    ncomplex evalE(int ep, int i, int j, int k, int l);
    ncomplex evalE(int ep, int i, int j, int k, int l, int m);

    virtual ncomplex A(int ep) { return ID0(ep); }
    virtual ncomplex A(int ep, int i) { return -IDi(ep, i); }
    virtual ncomplex A(int ep, int i, int j) { return ID2ij(ep, i, j); }
    virtual ncomplex A(int ep, int i, int j, int k) { return -ID3ijk(ep, i, j, k); }
    virtual ncomplex A(int ep, int i, int j, int k, int l) { return ID4ijkl(ep, i, j, k, l); }
    virtual ncomplex A(int ep, int i, int j, int k, int l, int m) { return -ID5ijklm(ep, i, j, k, l, m); }
    virtual ncomplex B(int ep) { return -0.5*ID1(ep); }
    virtual ncomplex B(int ep, int k) { return 0.5*ID2i(ep, k); }
    virtual ncomplex B(int ep, int k, int l) { return -0.5*ID3ij(ep, k, l); }
    virtual ncomplex B(int ep, int k, int l, int m) { return 0.5*ID4ijk(ep, k, l, m); }
    virtual ncomplex C(int ep) { return 0.25*ID2(ep); }
    virtual ncomplex C(int ep, int m) { return -0.25*ID3i(ep, m); }

    virtual const ncomplex* Ai(int ep) { if (not fEval[E_Di+ep]) { IDiEval(ep); } return pIDi[ep]; }
    virtual const ncomplex* Aij(int ep) { if (not fEval[E_D2ij+ep]) { ID2ijEval(ep); } return pID2ij[ep]; }
    virtual const ncomplex* Aijk(int ep) { if (not fEval[E_D3ijk+ep]) { ID3ijkEval(ep); } return pID3ijk[ep]; }
    virtual const ncomplex* Aijkl(int ep) { if (not fEval[E_D4ijkl+ep]) { ID4ijklEval(ep); } return pID4ijkl[ep]; }
    virtual const ncomplex* Aijklm(int ep) { if (not fEval[E_D5ijklm+ep]) { ID5ijklmEval(ep); } return pID5ijklm[ep]; }
    virtual const ncomplex* Bi(int ep) { if (not fEval[E_D2i+ep]) { ID2iEval(ep); } return pID2i[ep]; }
    virtual const ncomplex* Bij(int ep) { if (not fEval[E_D3ij+ep]) { ID3ijEval(ep); } return pID3ij[ep]; }
    virtual const ncomplex* Bijk(int ep) { if (not fEval[E_D4ijk+ep]) { ID4ijkEval(ep); } return pID4ijk[ep]; }
    virtual const ncomplex* Ci(int ep) { if (not fEval[E_D3i+ep]) { ID3iEval(ep); } return pID3i[ep]; }

    ncomplex ID0(int ep) { if (pID0[ep].real() == Cache::sNAN) ID0Eval(ep); return pID0[ep]; }
    ncomplex ID1(int ep) { if (pID1[ep].real() == Cache::sNAN) ID1Eval(ep); return pID1[ep]; }
    ncomplex ID2(int ep) { if (pID2[ep].real() == Cache::sNAN) ID2Eval(ep); return pID2[ep]; }

    ncomplex IDi(int ep, int i);
    ncomplex ID2i(int ep, int i);
    ncomplex ID3i(int ep, int i);

    ncomplex ID2ij(int ep, int i, int j);
    ncomplex ID3ij(int ep, int i, int j);
    ncomplex ID4ij(int ep, int i, int j);

    ncomplex ID3ijk(int ep, int i, int j, int k);
    ncomplex ID4ijk(int ep, int i, int j, int k);

    ncomplex ID4ijkl(int ep, int i, int j, int k, int l);

    ncomplex ID5ijklm(int ep, int i, int j, int k, int l, int m);

    double M1(int i, int l) PURE;
    double M2(int i, int j, int l, int m) PURE;
    double M3(int i, int j, int k, int l, int m, int n) PURE;

#define ix(i) (i<s ? i : i-1)
    inline ncomplex I4s(int ep, int s) { return mnr4[s-1]->ID0(ep); }
    inline ncomplex I4Ds(int ep, int s) { return mnr4[s-1]->ID1(ep); }
    inline ncomplex I4D2s(int ep, int s) { return mnr4[s-1]->ID2(ep); }
    inline ncomplex I4Dsi(int ep, int s, int i) { return s==i ? 0. : mnr4[s-1]->IDi(ep, ix(i)); }
    inline ncomplex I4D2si(int ep, int s, int i) { return s==i ? 0. : mnr4[s-1]->ID2i(ep, ix(i)); }
    inline ncomplex I4D3si(int ep, int s, int i) { return s==i ? 0. : mnr4[s-1]->ID3i(ep, ix(i)); }
    inline ncomplex I4D2sij(int ep, int s, int i, int j)
      { return (s==i || s==j) ? 0. : mnr4[s-1]->ID2ij(ep, ix(i), ix(j)); }
    inline ncomplex I4D3sij(int ep, int s, int i, int j)
      { return (s==i || s==j) ? 0. : mnr4[s-1]->ID3ij(ep, ix(i), ix(j)); }
    inline ncomplex I4D3sijk(int ep, int s, int i, int j, int k)
      { return (s==i || s==j || s==k) ? 0. : mnr4[s-1]->ID3ijk(ep, ix(i), ix(j), ix(k)); }
    inline ncomplex I4D4sijk(int ep, int s, int i, int j, int k)
      { return (s==i || s==j || s==k) ? 0. : mnr4[s-1]->ID4ijk(ep, ix(i), ix(j), ix(k)); }
    inline ncomplex I4D4sijkl(int ep, int s, int i, int j, int k, int l)
      { return (s==i || s==j || s==k || s==l) ? 0. : mnr4[s-1]->ID4ijkl(ep, ix(i), ix(j), ix(k), ix(l)); }
#undef ix

  private:
    Minor5(const Kinem5 &k);                        // prevent direct creation
    Minor5(const Kinem4 &k);                        // prevent direct creation
#ifdef USE_TRIANGLES
    Minor5(const Kinem3 &k);                        // prevent direct creation
    Minor5(const Kinem2 &k);                        // prevent direct creation
#endif
    Minor5(const Minor5 &m) { assert(0); }   // prevent copy-constructing
    Minor5& operator= (const Minor5& m) { assert(0); } // prevent reassignment

    const Kinem5 kinem;

    // flags marking evuation steps
    enum EvalM {E_None=0,
                E_M1, E_M2, E_M3,
                                                                         E_D5ijklm,
                                                                E_D4ijkl=E_D5ijklm+3,
                                                        E_D4ijk=E_D4ijkl+3,
                                                 E_D4ij=E_D4ijk+3,
                                         E_D3ijk=E_D4ij+3,
                                  E_D3ij=E_D3ijk+3,
                            E_D3i=E_D3ij+3,
                     E_D2ij=E_D3i+3,
               E_D2i=E_D2ij+3,
          E_Di=E_D2i+3,
    E_DUM=E_Di+3,
    E_LEN};
    std::bitset<E_LEN> fEval;

    // internally we use rank-notation, ranks 2 and 3 are defined in Minor<N>
    void evalRM4();
    void evalRM5();
    static const int RM4=15;   // Binomial[DCay,DCay-R] = Binomial[6,2]
    static const int RM5=6;    // Binomial[DCay,DCay-R] = Binomial[6,1]
    double rrM4[RM4*(RM4+1)/2];
    double rrM5[RM5*(RM5+1)/2];

    void ID0Eval(int ep);
    void ID1Eval(int ep);
    void ID2Eval(int ep);

    void IDiEval(int ep);
    void ID2iEval(int ep);
    void ID3iEval(int ep);

    void ID2ijEval(int ep);
    void ID3ijEval(int ep);
    void ID4ijEval(int ep);

    void ID3ijkEval(int ep);
    void ID4ijkEval(int ep);

    void ID4ijklEval(int ep);

    void ID5ijklmEval(int ep);

    // Integral values
    ncomplex pID0[3];
    ncomplex pID1[3];
    ncomplex pID2[3];
    static ncomplex pID2rat[3];

    ncomplex pIDi[3][CIDX];
    ncomplex pID2i[3][CIDX];
    ncomplex pID3i[3][CIDX];

    ncomplex pID2ij[3][CIDX*(CIDX+1)/2];                                  // symm 5x5
    ncomplex pID3ij[3][CIDX*(CIDX+1)/2];                                  // symm 5x5
    ncomplex pID4ij[3][CIDX*(CIDX+1)/2];                                  // symm 5x5

    ncomplex pID3ijk[3][CIDX*(CIDX+1)*(CIDX+2)/6];                        // symm 5x5x5
    ncomplex pID4ijk[3][CIDX*(CIDX+1)*(CIDX+2)/6];                        // symm 5x5x5

    ncomplex pID4ijkl[3][CIDX*(CIDX+1)*(CIDX+2)*(CIDX+3)/24];             // symm 5x5x5x5

    ncomplex pID5ijklm[3][CIDX*(CIDX+1)*(CIDX+2)*(CIDX+3)*(CIDX+4)/120];  // symm 5x5x5x5x5

    Minor4::Ptr mnr4[N];
};

typedef Entry< Kinem5, Minor5::Ptr > MEntry5;

#endif /* QUL_MINOR5_H */
