/*
 * mcache.h - cache classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_MCACHE_H
#define QUL_MCACHE_H

#include "cache.h"
#include "minor6.h"
#include "minor5.h"
#include "minor4.h"
#include "minor3.h"
#include "minor2.h"
#include "darray.h"

class MCache : public Cache
{
  friend class Golem;
  public:
    static MEntry6& entry(const Kinem6 &k);
    static MEntry5& entry(const Kinem5 &k);
    static MEntry4& entry(const Kinem4 &k);
    static MEntry3& entry(const Kinem3 &k);
    static MEntry2& entry(const Kinem2 &k);

    // TODO: may be return by reference here?
    static Minor6::Ptr getMinor6(const Kinem6 &k);
    static Minor5::Ptr getMinor5(const Kinem5 &k);
    static Minor4::Ptr getMinor4(const Kinem4 &k);
    static Minor3::Ptr getMinor3(const Kinem3 &k);
    static Minor2::Ptr getMinor2(const Kinem2 &k);

    static void insertMinor6(const Kinem6 &k, Minor6::Ptr &m);
    static void insertMinor5(const Kinem5 &k, Minor5::Ptr &m);
    static void insertMinor4(const Kinem4 &k, Minor4::Ptr &m);
    static void insertMinor3(const Kinem3 &k, Minor3::Ptr &m);
    static void insertMinor2(const Kinem2 &k, Minor2::Ptr &m);


#ifdef USE_SMART_INSERT
#   define INSERTMINOR3 smartinsertMinor3
#   define INSERTMINOR2 smartinsertMinor2
    static void smartinsertMinor3(const Kinem3 &k, Minor3::Ptr &m);
    static void smartinsertMinor2(const Kinem2 &k, Minor2::Ptr &m);
#else
#   define INSERTMINOR3 insertMinor3
#   define INSERTMINOR2 insertMinor2
#endif

    static void Clear();

  private:

    typedef DArray< MEntry6, size6 > Array6;
    static Array6 cm6;

    typedef DArray< MEntry5, size5 > Array5;
    static Array5 cm5;

    typedef DArray< MEntry4, size4 > Array4;
    static Array4 cm4;

    typedef DArray< MEntry3, size3 > Array3;
    static Array3 cm3;

    typedef DArray< MEntry2, size2 > Array2;
    static Array2 cm2;

};

/* =============================================
 *
 *            inline functions
 *
 * =============================================
 */

#define insertMinorN(n) \
inline \
void MCache::insertMinor##n(const Kinem##n &k, Minor##n::Ptr &m) \
{ \
  cm##n.insert(MEntry##n(k,m)); \
}

insertMinorN(6)
insertMinorN(5)
insertMinorN(4)
insertMinorN(3)
insertMinorN(2)

#undef insertMinorN


#endif // QUL_MCACHE_H
