/*
 * cache.h - cache classes header
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_CACHE_H
#define QUL_CACHE_H

#include "common.h"

#ifdef DBL_ULP_CMP
#include <cstdlib>
#endif
#ifdef DBL_SLOPPY_CMP
#include <cmath>
#endif

class Cache
{
  public:
    struct Ival {
      ncomplex val[3];
      ncomplex& operator[] (int i) { return val[i]; }
    };

    typedef union { int64_t i64; double  d64; } ID64;
    typedef union { double  d64; int64_t i64; } DI64;
    static const ID64 sNAN;
    friend bool operator==(const double &x, const Cache::ID64 &y);

    static bool eq(const double& a, const double& b);
    static bool neq(const double& a, const double& b);

    inline static double getMu2() { return mu2; }
    static double setMu2(const double newmu2);

  protected:
    static double eps;
    static double mu2;
    static double epsmu2;

#ifdef USE_GOLEM_MODE
    static const int size6=1;
#else
    static const int size6=3;
#endif
    static const int size5=size6*6;
    static const int size4=size6*15;
    static const int size3=size6*20;
    static const int size2=size6*15;
    static const int size1=size6*6;

/*  // static const double mdelta=1e-14;
    // static const int64_t idelta=1+mdelta/DBL_EPSILON; // needs cfloat
    Comparison ulp-tolerance for double
    idelta   fdelta(%)
        5  - 1.11e-15
       46  - 1.02e-14
      451  - 1.00e-13
     4504  - 1.00e-12
    45036  - 1.00e-11
    */
    static const uint64_t idelta=5; // unsigned !!!
};

inline
bool operator==(const double &x, const Cache::ID64 &y)
{
  const Cache::DI64 ix={x};
  return ix.i64 == y.i64;
}

#ifdef DBL_SLOPPY_CMP
inline
bool Cache::neq(const double& a, const double& b) {
  return fabs(a-b) > epsmu2;
}
#else // DBL_SLOPPY_CMP
inline
bool Cache::neq(const double& a, const double& b) {
  const DI64 ia={a};
  const DI64 ib={b};
#ifdef DBL_ULP_CMP
  const int64_t diff=ia.i64-ib.i64;
  return diff != 0LL && static_cast<uint64_t>(llabs(diff)) > idelta;
#else
  return ia.i64 != ib.i64;
#endif
}
#endif // DBL_SLOPPY_CMP

inline
bool Cache::eq(const double& a, const double& b) {
  return !neq(a, b);
}


#endif /* _QUL_CACHE_H */
