/*
 * minor2.h - signed minors classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_MINOR2_H
#define QUL_MINOR2_H

#include "minor.h"
#include "entry.h"
#include "cache.h"

class Minor1 : public MinorBase
{
  friend class Golem;
  public:
    friend class SPtr<Minor1>;
    typedef SPtr<Minor1> Ptr;
    static Ptr create(const Kinem1 &k) { return Ptr(new Minor1(k)); }

    virtual Tensor::Ptr Sub(int s) { assert(s==1); return Tensor::Ptr(0); };

    virtual ncomplex A(int ep) { return pID0[ep]; }

    ncomplex ID0(int ep) { return pID0[ep]; }

  private:
    Minor1(const Kinem1 &k);

    Kinem1 kinem;
    Cache::Ival pID0;
};


class Minor2 : public Minor<2>
{
  friend class Golem;
  public:
    friend class SPtr<Minor2>;
    typedef SPtr<Minor2> Ptr;

    static Ptr create(const Kinem2 &k) { return Ptr(new Minor2(k)); }

    virtual Tensor::Ptr Sub(int s) { assert(0<s && s<=N); return Tensor::Ptr(mnr1[s-1]); };

    ncomplex evalB(int ep);
    ncomplex evalB(int ep, int i);
    ncomplex evalB(int ep, int i, int j);

    virtual ncomplex A(int ep) { return ID0(ep); }
    virtual ncomplex A(int ep, int i) { return -IDi(ep, i); }
    virtual ncomplex A(int ep, int i, int j) { return ID2ij(ep, i, j); }
    virtual ncomplex B(int ep) { return -0.5*ID1(ep); }

    virtual const ncomplex* Ai(int ep) {
      if (not (ep>=2 || qZeroALL || fEval[E_Di+ep])) {
        IDiEval(ep);
      }
      return pIDi[ep];
    }
    virtual const ncomplex* Aij(int ep) {
      if (not (ep>=2 || qZeroALL || fEval[E_D2ij+ep])) {
        ID2ijEval(ep);
      }
      return pID2ij[ep];
    }

    inline
    ncomplex IDm1(int ep) { if (pIDm1[ep].real() == Cache::sNAN) IDm1Eval(ep); return pIDm1[ep]; }
    ncomplex ID0(int ep) { return pID0[ep]; }
    ncomplex ID1(int ep) { if (pID1[ep].real() == Cache::sNAN) ID1Eval(ep); return pID1[ep]; }
    ncomplex ID2(int ep) { if (pID2[ep].real() == Cache::sNAN) ID2Eval(ep); return pID2[ep]; }
    ncomplex ID3(int ep) { if (pID3[ep].real() == Cache::sNAN) ID3Eval(ep); return pID3[ep]; }
    ncomplex ID4(int ep) { if (pID4[ep].real() == Cache::sNAN) ID4Eval(ep); return pID4[ep]; }
    ncomplex ID5(int ep) { if (pID5[ep].real() == Cache::sNAN) ID5Eval(ep); return pID5[ep]; }
    ncomplex ID6(int ep) { if (pID6[ep].real() == Cache::sNAN) ID6Eval(ep); return pID6[ep]; }

    inline ncomplex I1v(int ep, int v) { return mnr1[v-1]->ID0(ep); }

    ncomplex IDi(int ep, int i);
    ncomplex ID2i(int ep, int i);
    ncomplex ID2ij(int ep, int i, int j);

    ncomplex Ii(int ep, int i);
    ncomplex IDij(int ep, int i, int j);
    ncomplex ID2ijk(int ep, int i, int j, int k);

// pMi  - scratched lines numbering
// rrMi - matrix rank numbering
#define pM0 rrM3
#define pM1 rrM2
    double M0() PURE { return pM0[0]; }
    double M1(int i, int l) PURE { return pM1[is(i,l)]; }
#undef pM0
#undef pM1

    inline
    double maxCay() { return pmaxCay; }

  private:
    Minor2(const Kinem2 &k);

    const Kinem2 kinem;

    // flags marking evuation steps
    enum EvalM {E_None=0,
                               E_D2ij,
                         E_D2i=E_D2ij+3,
                    E_Di=E_D2i+3,
                E_i=E_Di+3,
          E_Dij=E_i+3,
    E_DUM=E_Dij+3,
    E_LEN};
    std::bitset<E_LEN> fEval;

    void IDm1Eval(int ep);
    void ID1Eval(int ep);
    void ID2Eval(int ep);
    void ID3Eval(int ep);
    void ID4Eval(int ep);
    void ID5Eval(int ep);
    void ID6Eval(int ep);

    void IDiEval(int ep);
    void ID2iEval(int ep);
    void ID2ijEval(int ep);

    void IiEval(int ep);
    void IDijEval(int ep);
    void ID2ijkEval(int ep);

    Cache::Ival pIDm1;
    Cache::Ival pID0;
    Cache::Ival pID1;
    Cache::Ival pID2;
    Cache::Ival pID3;
    Cache::Ival pID4;
    Cache::Ival pID5;
    Cache::Ival pID6;

    ncomplex pIDi[3][CIDX];               // uv-div
    ncomplex pID2i[2][CIDX];              // uv-div
    ncomplex pID2ij[3][CIDX*(CIDX+1)/2];  //        symm 2x2

    ncomplex pIi[2][CIDX];                // uv-div
    ncomplex pIDij[2][CIDX*(CIDX+1)/2];   //        symm 2x2

    double pmaxCay;

    Minor1::Ptr mnr1[N];

    bool qZeroALL, qZeroS, qEqMass;
};

typedef Entry< Kinem2, Minor2::Ptr > MEntry2;

#endif /* QUL_MINOR2_H */
