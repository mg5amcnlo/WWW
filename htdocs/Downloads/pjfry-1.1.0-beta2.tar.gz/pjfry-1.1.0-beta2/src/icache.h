/*
 * icache.h - cache classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_ICACHE_H
#define QUL_ICACHE_H

#include "cache.h"
#include "kinem.h"
#include "entry.h"
#include "darray.h"

class ICache : public Cache
{
  friend class Golem;
  public:
    // Scalars
    static Ival getI4(const Kinem4 &k);
    static Ival getI3(const Kinem3 &k);
    static Ival getI2(const Kinem2 &k);
    static Ival getI1(const Kinem1 &k);

    static ncomplex getI4(int ep, const Kinem4 &k);
    static ncomplex getI3(int ep, const Kinem3 &k);
    static ncomplex getI2(int ep, const Kinem2 &k);
    static ncomplex getI1(int ep, const Kinem1 &k);

    static void Clear();
    static void ClearIC();

  private:
    // ------------------------------
    // Scalar integrals
    // ------------------------------
    typedef Entry< Kinem4, Ival > EntryS4;
    typedef DArray< EntryS4, size4 > ArrayS4;
    static ArrayS4 ics4;

    typedef Entry< Kinem3, Ival > EntryS3;
    typedef DArray< EntryS3, size3 > ArrayS3;
    static ArrayS3 ics3;

    typedef Entry< Kinem2, Ival > EntryS2;
    typedef DArray< EntryS2, size2 > ArrayS2;
    static ArrayS2 ics2;

    typedef Entry< Kinem1, Ival > EntryS1;
    typedef DArray< EntryS1, size1 > ArrayS1;
    static ArrayS1 ics1;
};

#endif // QUL_ICACHE_H
