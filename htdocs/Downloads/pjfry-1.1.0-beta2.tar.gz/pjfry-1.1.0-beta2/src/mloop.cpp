/*
 * mloop.cpp - component interface functions
 *
 * this file is part of PJFry library
 * Copyright 2012 Valery Yundin
 */

#include "common.h"
#define PJFRY_NATIVE 1
#include "pjfry.h"
#include "lorentz.h"

// Temporary
typedef SLTensor<1,4,double> SLTensor1;
typedef SLTensor<2,4,double> SLTensor2;
typedef SLTensor<3,4,double> SLTensor3;
typedef SLTensor<4,4,double> SLTensor4;
typedef SLTensor<5,4,double> SLTensor5;
typedef SLTensor<6,4,double> SLTensor6;

typedef SLTensor<1,4,ncomplex> SLTensor1c;
typedef SLTensor<2,4,ncomplex> SLTensor2c;
typedef SLTensor<3,4,ncomplex> SLTensor3c;
typedef SLTensor<4,4,ncomplex> SLTensor4c;
typedef SLTensor<5,4,ncomplex> SLTensor5c;
typedef SLTensor<6,4,ncomplex> SLTensor6c;

const SLTensor2 g2(1, -1, -1, -1);
const SLTensor4 g4 = g2*(g2*0.5);
const SLTensor6 g6 = g4*g2;

static const int ranklen[] = {1, 5, 15, 35, 70, 126, 210, 330, 495};

// bubbles, triangles, boxes, pentagons use ABC-scheme
template <int NC>
void eval_rank1(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                const SLTensor1* const qqs)
{
  const SCTensor<1,NC,SLTensor1> qi(qqs);
  int idx = ranklen[0];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<1,NC,ncomplex> ci(tens->Ai(eps));
    const SLTensor1c c1 = qi*ci;
    for (int i=0; i<SLTensor1c::LEN; i++) {
      coefs[idx + i] = c1.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 2) {
    eval_rank2(coefs, rank, tens, qi);
  }
}

template <int NC>
void eval_rank2(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                const SCTensor<1,NC,SLTensor1>& qi)
{
  const SCTensor<2,NC,SLTensor2> qij(qi*qi);
  int idx = ranklen[1];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<2,NC,ncomplex> cij(tens->Aij(eps));
    const SLTensor2c c2 = qij*cij + g2*tens->B(eps);
    for (int i=0; i<SLTensor2c::LEN; i++) {
      coefs[idx + i] = c2.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 3) {
    eval_rank3(coefs, rank, tens, qi, qij);
  }
}

template <int NC>
void eval_rank3(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                const SCTensor<1,NC,SLTensor1>& qi,
                const SCTensor<2,NC,SLTensor2>& qij)
{
  const SCTensor<3,NC,SLTensor3> qijk(qij*qi);
  const SCTensor<1,NC,SLTensor3> q00i(qi*(-0.5*g2));
  int idx = ranklen[2];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<3,NC,ncomplex> cijk(tens->Aijk(eps));
    const SCTensor<1,NC,ncomplex> c00i(tens->Bi(eps));
    const SLTensor3c c3 = qijk*cijk + q00i*c00i;
    for (int i=0; i<SLTensor3c::LEN; i++) {
      coefs[idx + i] = c3.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 4) {
    eval_rank4(coefs, rank, tens, qi, qij, qijk, q00i);
  }
}

template <int NC>
void eval_rank4(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                const SCTensor<1,NC,SLTensor1>& qi,
                const SCTensor<2,NC,SLTensor2>& qij,
                const SCTensor<3,NC,SLTensor3>& qijk,
                const SCTensor<1,NC,SLTensor3>& q00i)

{
  const SCTensor<4,NC,SLTensor4> qijkl(qijk*qi);
  const SCTensor<2,NC,SLTensor4> q00ij(qij*(-0.5*g2));
  int idx = ranklen[3];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<4,NC,ncomplex> cijkl(tens->Aijkl(eps));
    const SCTensor<2,NC,ncomplex> c00ij(tens->Bij(eps));
    const SLTensor4c c4 = qijkl*cijkl + q00ij*c00ij + g4*tens->C(eps);
    for (int i=0; i<SLTensor4c::LEN; i++) {
      coefs[idx + i] = c4.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 5) {
    eval_rank5(coefs, rank, tens, qi, qij, qijk, q00i, qijkl, q00ij);
  }
}

template <int NC>
void eval_rank5(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                const SCTensor<1,NC,SLTensor1>& qi,
                const SCTensor<2,NC,SLTensor2>& qij,
                const SCTensor<3,NC,SLTensor3>& qijk,
                const SCTensor<1,NC,SLTensor3>& q00i,
                const SCTensor<4,NC,SLTensor4>& qijkl,
                const SCTensor<2,NC,SLTensor4>& q00ij)

{
  const SCTensor<5,NC,SLTensor5> qijklm(qijkl*qi);
  const SCTensor<3,NC,SLTensor5> q00ijk(qijk*(-0.5*g2));
  const SCTensor<1,NC,SLTensor5> q0000i(qi*(0.25*g4));
  int idx = ranklen[4];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<5,NC,ncomplex> cijklm(tens->Aijklm(eps));
    const SCTensor<3,NC,ncomplex> c00ijk(tens->Bijk(eps));
    const SCTensor<1,NC,ncomplex> c0000i(tens->Ci(eps));
    const SLTensor5c c5 = qijklm*cijklm + q00ijk*c00ijk + q0000i*c0000i;
    for (int i=0; i<SLTensor5c::LEN; i++) {
      coefs[idx + i] = c5.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 6) {
    assert(rank <= 5);
  }
}

// hexagons use A-scheme
template <int NC>
void hex_eval_rank1(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                    const SLTensor1* const qqs)
{
  const SCTensor<1,NC,SLTensor1> qi(qqs);
  int idx = ranklen[0];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<1,NC,ncomplex> ci(tens->Ai(eps));
    const SLTensor1c c1 = qi*ci;
    for (int i=0; i<SLTensor1c::LEN; i++) {
      coefs[idx + i] = c1.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 2) {
    hex_eval_rank2(coefs, rank, tens, qi);
  }
}

template <int NC>
void hex_eval_rank2(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                    const SCTensor<1,NC,SLTensor1>& qi)
{
  const SCTensor<2,NC,SLTensor2> qij(qi*qi);
  int idx = ranklen[1];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<2,NC,ncomplex> cij(tens->Aij(eps));
    const SLTensor2c c2 = qij*cij;
    for (int i=0; i<SLTensor2c::LEN; i++) {
      coefs[idx + i] = c2.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 3) {
    hex_eval_rank3(coefs, rank, tens, qi, qij);
  }
}

template <int NC>
void hex_eval_rank3(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                    const SCTensor<1,NC,SLTensor1>& qi,
                    const SCTensor<2,NC,SLTensor2>& qij)
{
  const SCTensor<3,NC,SLTensor3> qijk(qij*qi);
  int idx = ranklen[2];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<3,NC,ncomplex> cijk(tens->Aijk(eps));
    const SLTensor3c c3 = qijk*cijk;
    for (int i=0; i<SLTensor3c::LEN; i++) {
      coefs[idx + i] = c3.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 4) {
    hex_eval_rank4(coefs, rank, tens, qi, qij, qijk);
  }
}

template <int NC>
void hex_eval_rank4(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                    const SCTensor<1,NC,SLTensor1>& qi,
                    const SCTensor<2,NC,SLTensor2>& qij,
                    const SCTensor<3,NC,SLTensor3>& qijk)

{
  const SCTensor<4,NC,SLTensor4> qijkl(qijk*qi);
  int idx = ranklen[3];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<4,NC,ncomplex> cijkl(tens->Aijkl(eps));
    const SLTensor4c c4 = qijkl*cijkl;
    for (int i=0; i<SLTensor4c::LEN; i++) {
      coefs[idx + i] = c4.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 5) {
    hex_eval_rank5(coefs, rank, tens, qi, qij, qijk, qijkl);
  }
}

template <int NC>
void hex_eval_rank5(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                    const SCTensor<1,NC,SLTensor1>& qi,
                    const SCTensor<2,NC,SLTensor2>& qij,
                    const SCTensor<3,NC,SLTensor3>& qijk,
                    const SCTensor<4,NC,SLTensor4>& qijkl)

{
  const SCTensor<5,NC,SLTensor5> qijklm(qijkl*qi);
  int idx = ranklen[4];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<5,NC,ncomplex> cijklm(tens->Aijklm(eps));
    const SLTensor5c c5 = qijklm*cijklm;
    for (int i=0; i<SLTensor5c::LEN; i++) {
      coefs[idx + i] = c5.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 6) {
    hex_eval_rank6(coefs, rank, tens, qi, qij, qijk, qijkl, qijklm);
  }
}

template <int NC>
void hex_eval_rank6(ncomplex *coefs, const int rank, Tensor::Ptr tens,
                    const SCTensor<1,NC,SLTensor1>& qi,
                    const SCTensor<2,NC,SLTensor2>& qij,
                    const SCTensor<3,NC,SLTensor3>& qijk,
                    const SCTensor<4,NC,SLTensor4>& qijkl,
                    const SCTensor<5,NC,SLTensor5>& qijklm)

{
  const SCTensor<6,NC,SLTensor6> qijklmn(qijklm*qi);
  int idx = ranklen[5];
  for (int eps=0; eps<=2; eps++) {
    const SCTensor<6,NC,ncomplex> cijklmn(tens->Aijklmn(eps));
    const SLTensor6c c6 = qijklmn*cijklmn;
    for (int i=0; i<SLTensor6c::LEN; i++) {
      coefs[idx + i] = c6.data[i];
    }
    idx += ranklen[rank];
  }
  if (rank >= 7) {
    assert(rank <= 6);
  }
}

void pmloop_(int *pn, int *prank, double *pl, double *ql, double *m2l, double *mur,
             ncomplex *coefs, bool *stable)
{
  const int n = *pn;
  const int rank = *prank;
  PJFry::SetMu2(mur[0]*mur[0]);
  switch (n) {
    case 1:
    break;
    case 2: {
      const SLTensor1 p1 = SLTensor1(&pl[0]);
      const double m1 = m2l[0];
      const double m2 = m2l[2];
      const double ps1 = p1.sq();

      const SLTensor1 qqs[] = {-SLTensor1(&ql[0])};
      Tensor::Ptr tens = PJFry::Tensor2(ps1,m2,m1);
      int idx = 0;
      for (int eps=0; eps<=2; eps++) {
        coefs[idx] = tens->A(eps);
        idx += ranklen[rank];
      }
      if (rank >= 1) {
        eval_rank1<1>(coefs, rank, tens, qqs);
      }
      *stable = true;
    }
    break;
    case 3: {
      const SLTensor1 p1 = SLTensor1(&pl[0]);
      const SLTensor1 p2 = SLTensor1(&pl[4]);
      const SLTensor1 p3 = SLTensor1(&pl[8]);
      const double m1 = m2l[0];
      const double m2 = m2l[2];
      const double m3 = m2l[4];
      const double ps1 = p1.sq();
      const double ps2 = p2.sq();
      const double ps3 = p3.sq();

      const SLTensor1 qqs[] = {-SLTensor1(&ql[0]),
                               -SLTensor1(&ql[4])};
      Tensor::Ptr tens = PJFry::Tensor3(ps1,ps2,ps3,m2,m3,m1);
      int idx = 0;
      for (int eps=0; eps<=2; eps++) {
        coefs[idx] = tens->A(eps);
        idx += ranklen[rank];
      }
      if (rank >= 1) {
        eval_rank1<2>(coefs, rank, tens, qqs);
      }
  /*
#define TRIQ 2
      const SCTensor<1,TRIQ,SLTensor1> cqi(qqs);
      const SCTensor<2,TRIQ,SLTensor2> cqij(cqi*cqi);
      const SCTensor<3,TRIQ,SLTensor3> cqijk(cqij*cqi);
      const SCTensor<1,TRIQ,SLTensor3> cq00i(cqi*(-0.5*g2));

      for (int eps=0; eps<=2; eps++) {
        coefs[idx++] = tria->A(eps);
        if (rank < 1) continue;
        const SCTensor<1,TRIQ,ncomplex> cci(tria->Ai(eps));
        const SLTensor1c c1 = cqi*cci;
        for (int i=0; i<SLTensor1c::LEN; i++) {
          coefs[idx++] = c1.data[i];
        }
        if (rank < 2) continue;
        const SCTensor<2,TRIQ,ncomplex> ccij(tria->Aij(eps));
        const SLTensor2c c2 = cqij*ccij + g2*tria->B(eps);
        for (int i=0; i<SLTensor2c::LEN; i++) {
          coefs[idx++] = c2.data[i];
        }
        if (rank < 3) continue;
        const SCTensor<3,TRIQ,ncomplex> ccijk(tria->Aijk(eps));
        const SCTensor<1,TRIQ,ncomplex> cc00i(tria->Bi(eps));
        const SLTensor3c c3 = cqijk*ccijk + cq00i*cc00i;
        for (int i=0; i<SLTensor3c::LEN; i++) {
          coefs[idx++] = c3.data[i];
        }
      }
#undef TRIQ
      */
      *stable = true;
    }
    break;
    case 4: {
      const SLTensor1 p1 = SLTensor1(&pl[0]);
      const SLTensor1 p2 = SLTensor1(&pl[4]);
      const SLTensor1 p3 = SLTensor1(&pl[8]);
      const SLTensor1 p4 = SLTensor1(&pl[12]);
      const double m1 = m2l[0];
      const double m2 = m2l[2];
      const double m3 = m2l[4];
      const double m4 = m2l[6];
      const double ps1 = p1.sq();
      const double ps2 = p2.sq();
      const double ps3 = p3.sq();
      const double ps4 = p4.sq();
      const double s12 = (p1 + p2).sq();
      const double s23 = (p2 + p3).sq();

      const SLTensor1 qqs[] = {-SLTensor1(&ql[0]),
                               -SLTensor1(&ql[4]),
                               -SLTensor1(&ql[8])};
      Tensor::Ptr tens = PJFry::Tensor4(ps1,ps2,ps3,ps4,s12,s23,m2,m3,m4,m1);
      int idx = 0;
      for (int eps=0; eps<=2; eps++) {
        coefs[idx] = tens->A(eps);
        idx += ranklen[rank];
      }
      if (rank >= 1) {
        eval_rank1<3>(coefs, rank, tens, qqs);
      }
      *stable = true;
    }
    break;
    case 5: {
      const SLTensor1 p1 = SLTensor1(&pl[0]);
      const SLTensor1 p2 = SLTensor1(&pl[4]);
      const SLTensor1 p3 = SLTensor1(&pl[8]);
      const SLTensor1 p4 = SLTensor1(&pl[12]);
      const SLTensor1 p5 = SLTensor1(&pl[16]);
      const double m1 = m2l[0];
      const double m2 = m2l[2];
      const double m3 = m2l[4];
      const double m4 = m2l[6];
      const double m5 = m2l[8];
      const double ps1 = p1.sq();
      const double ps2 = p2.sq();
      const double ps3 = p3.sq();
      const double ps4 = p4.sq();
      const double ps5 = p5.sq();
      const double s12 = (p1 + p2).sq();
      const double s23 = (p2 + p3).sq();
      const double s34 = (p3 + p4).sq();
      const double s45 = (p4 + p5).sq();
      const double s15 = (p5 + p1).sq();

      const SLTensor1 qqs[] = {-SLTensor1(&ql[0]),
                               -SLTensor1(&ql[4]),
                               -SLTensor1(&ql[8]),
                               -SLTensor1(&ql[12])};
      Tensor::Ptr tens = PJFry::Tensor5(ps1,ps2,ps3,ps4,ps5,s12,s23,s34,s45,s15,m2,m3,m4,m5,m1);
      int idx = 0;
      for (int eps=0; eps<=2; eps++) {
        coefs[idx] = tens->A(eps);
        idx += ranklen[rank];
      }
      if (rank >= 1) {
        eval_rank1<4>(coefs, rank, tens, qqs);
      }
      *stable = true;
    }
    break;
    case 6: {
      const SLTensor1 p1 = SLTensor1(&pl[0]);
      const SLTensor1 p2 = SLTensor1(&pl[4]);
      const SLTensor1 p3 = SLTensor1(&pl[8]);
      const SLTensor1 p4 = SLTensor1(&pl[12]);
      const SLTensor1 p5 = SLTensor1(&pl[16]);
      const SLTensor1 p6 = SLTensor1(&pl[20]);
      const double m1 = m2l[0];
      const double m2 = m2l[2];
      const double m3 = m2l[4];
      const double m4 = m2l[6];
      const double m5 = m2l[8];
      const double m6 = m2l[10];
      const double ps1 = p1.sq();
      const double ps2 = p2.sq();
      const double ps3 = p3.sq();
      const double ps4 = p4.sq();
      const double ps5 = p5.sq();
      const double ps6 = p6.sq();
      const double s12 = (p1 + p2).sq();
      const double s23 = (p2 + p3).sq();
      const double s34 = (p3 + p4).sq();
      const double s45 = (p4 + p5).sq();
      const double s56 = (p5 + p6).sq();
      const double s16 = (p6 + p1).sq();
      const double s234 = (p2 + p3 + p4).sq();
      const double s345 = (p3 + p4 + p5).sq();
      const double s456 = (p4 + p5 + p6).sq();

      const SLTensor1 qqs[] = {-SLTensor1(&ql[0]),
                               -SLTensor1(&ql[4]),
                               -SLTensor1(&ql[8]),
                               -SLTensor1(&ql[12]),
                               -SLTensor1(&ql[16])};
      Tensor::Ptr tens = PJFry::Tensor6(ps1,ps2,ps3,ps4,ps5,ps6,s12,s23,s34,s45,s56,s16,s234,s345,s456,m2,m3,m4,m5,m6,m1);
      int idx = 0;
      for (int eps=0; eps<=2; eps++) {
        coefs[idx] = tens->A(eps);
        idx += ranklen[rank];
      }
      if (rank >= 1) {
        hex_eval_rank1<5>(coefs, rank, tens, qqs);
      }
      *stable = true;
    }
    break;
    default:
      assert(n >= 1 && n <= 6);
    break;
  }
}
