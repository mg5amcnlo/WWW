/*
 * mcache.cpp - cache classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "mcache.h"

MCache::Array6 MCache::cm6;
MCache::Array5 MCache::cm5;
MCache::Array4 MCache::cm4;
MCache::Array3 MCache::cm3;
MCache::Array2 MCache::cm2;

/* clear minor cache */
void MCache::Clear()
{
  cm6.reset();
  cm5.reset();
  cm4.reset();
  cm3.reset();
  cm2.reset();
}


#define entryN(n) \
MEntry##n& MCache::entry(const Kinem##n &k) \
{ \
  for (Array##n::iterator it=cm##n.begin(); it!=cm##n.end(); ++it) { \
    if (it->key == k) { \
      return *it; \
    } \
  } \
  Minor##n::Ptr m; \
  return cm##n.insert(MEntry##n(k,m)); \
}

entryN(2)
entryN(3)
entryN(4)
entryN(5)
entryN(6)

#undef entryN

#define getMinorN(n) \
Minor##n::Ptr MCache::getMinor##n(const Kinem##n &k) \
{ \
  for (Array##n::iterator it=cm##n.begin(); it!=cm##n.end(); ++it) { \
    if (it->key == k) { \
      return it->val; \
    } \
  } \
  Minor##n::Ptr minor = Minor##n::create(k); \
  assert(minor!=0); \
  cm##n.insert(MEntry##n(k,minor)); \
  return minor; \
}

getMinorN(6)
getMinorN(5)
getMinorN(4)
getMinorN(3)
getMinorN(2)

#undef getMinorN

#ifdef USE_SMART_INSERT

void MCache::smartinsertMinor3(const Kinem3 &k, Minor3::Ptr &m)
{
  for (Array3::iterator it=cm3.begin(); it!=cm3.end(); ++it) {
    if (it->key == k) {
      cm3.remove(it);
      break;
    }
  }
  insertMinor3(k,m);
}

void MCache::smartinsertMinor2(const Kinem2 &k, Minor2::Ptr &m)
{
  for (Array2::iterator it=cm2.begin(); it!=cm2.end(); ++it) {
    if (it->key == k) {
      cm2.remove(it);
      break;
    }
  }
  insertMinor2(k,m);
}

#endif

// -------------------------------------------------------
