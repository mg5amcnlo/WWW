/*
 * cache.cpp - cache classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "cache.h"
#include "icache.h"
#include "mcache.h"
#include "integral.h"

// const double ICache::sNan=std::numeric_limits<double>::signaling_NaN();
// const int64_t ICache::sNAN=0x7ffc0000BA13BA13LL;
// const double ICache::sNAN.d64=reinterpret_cast<const double&>(sNAN); // Bad because breaks strict aliasing
// const double ICache::sNAN.d64=((const ICache::ID64&)sNAN).dbl;

const Cache::ID64 Cache::sNAN={ 0x7ffc0000BA13BA13LL };

double Cache::eps=1e-15;
double Cache::mu2=1.;
double Cache::epsmu2=1e-15; // Cache::eps*Cache::mu2; maybe std::numeric_limits::epsilon() ???

double Cache::setMu2(const double newmu2)
{
  if (newmu2 > 0 && newmu2 != mu2) {
    MinorBase::Rescale(newmu2/mu2);
    mu2 = newmu2;
    epsmu2 = eps*mu2;
#ifdef USE_ONELOOP
    double mu = sqrt(mu2);
    F77_FUNC_(avh_olo_mu_set,AVH_OLO_MU_SET)(&mu);
#endif
    ICache::Clear();
    MCache::Clear();
  }
  return mu2;
}
