/*
 * cache.h - golem-mode header
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#ifndef QUL_GOLEM_H
#define QUL_GOLEM_H

#include "common.h"

class Golem
{
  public:
    static void initgolem95(int n);
    static void setmat(int i, int j, double val);
    static void preparesmatrix();
    static double getmat(int i, int j);

    static ncomplex ga0(int s, int ep);
    static ncomplex ga1(int i, int s, int ep);
    static ncomplex ga2(int i, int j, int s, int ep);
    static ncomplex gb2(int s, int ep);
    static ncomplex ga3(int i, int j, int k, int s, int ep);
    static ncomplex gb3(int i, int s, int ep);
    static ncomplex ga4(int i, int j, int k, int l, int s, int ep);
    static ncomplex gb4(int i, int j, int s, int ep);
    static ncomplex gc4(int s, int ep);
    static ncomplex ga5(int i, int j, int k, int l, int m, int s, int ep);
    static ncomplex gb5(int i, int j, int k, int s, int ep);
    static ncomplex gc5(int i, int s, int ep);
    static ncomplex ga6(int i, int j, int k, int l, int m, int n, int s, int ep);
    static ncomplex gb6(int i, int j, int k, int l, int s, int ep);
    static ncomplex gc6(int i, int j, int s, int ep);

  private:
    static void prepare6();
    static void prepare5();
    static void prepare4();
    static void prepare3();
    static void prepare2();
    static void prepare1();

    static int N;
    static int caylen;

    static MinorBase* minortbl[128];
    static Minor6::Ptr minor6;
    static Minor5::Ptr minor5;
    static Minor4::Ptr minor4;
    static Minor3::Ptr minor3;
    static Minor2::Ptr minor2;
    static Minor1::Ptr minor1;

    static double Cay[6*(6+1)/2]; // upto rank 6
    static unsigned int bitfield;
    static unsigned int bitmask;

    static const unsigned char scrtbl[128][8];
};

#endif /* QUL_GOLEM_H */
