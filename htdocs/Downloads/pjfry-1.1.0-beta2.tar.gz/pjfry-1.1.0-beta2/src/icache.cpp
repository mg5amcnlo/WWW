/*
 * mcache.cpp - cache classes
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "icache.h"
#include "mcache.h"
#include "integral.h"

void ICache::Clear()
{
  ClearIC();
}

/* clear scalar integral cache */
void ICache::ClearIC()
{
  ics4.reset();
  ics3.reset();
  ics2.reset();
  ics1.reset();
}

ICache::ArrayS4 ICache::ics4;
ICache::ArrayS3 ICache::ics3;
ICache::ArrayS2 ICache::ics2;
ICache::ArrayS1 ICache::ics1;


/* ===========================================================
 *
 *               Get saved value
 *
 * ===========================================================
 */

// ncomplex ICache::getI2(int ep, const Kinem2 &k)
// {
//   ncomplex ivalue(sNAN.d64, 0);
//   for (ArrayS2::iterator it2=ics2[ep].begin(); it2 != ics2[ep].end(); ++it2) {
//     if (it2->key == k) {
//       ivalue=it2->val;
//       break;
//     }
//   }
//   if (ivalue.real() == sNAN) {
//     ivalue=qlI2(k.p1(),
//                 k.m1(), k.m2(),
//                 -ep);
//     ics2[ep].insert(EntryS2(k,ivalue));
//   }
//   return ivalue;
// }


// get all eps=0,1,2 coefficients of the scalar integral
#define getIN(n) \
Cache::Ival ICache::getI##n(const Kinem##n &k) \
{ \
  Ival ivalue; \
  bool found = false; \
  for (ArrayS##n::iterator it=ics##n.begin(); it != ics##n.end(); ++it) { \
    if (it->key == k) { \
      ivalue = it->val; \
      found = true; \
      break; \
    } \
  } \
  if ( ! found ) { \
    ivalue = qlI##n(k); \
    ics##n.insert(EntryS##n(k,ivalue)); \
  } \
  return ivalue; \
}

getIN(1)
getIN(2)
getIN(3)
getIN(4)

#undef getIN


// get one eps=ep coefficient of the scalar integral
#define getIN(n) \
ncomplex ICache::getI##n(int ep, const Kinem##n &k) \
{ \
  Ival ivalue; \
  bool found=false; \
  for (ArrayS##n::iterator it##n=ics##n.begin(); it##n != ics##n.end(); ++it##n) { \
    if (it##n->key == k) { \
      ivalue=it##n->val; \
      found=true; \
      break; \
    } \
  } \
  if ( ! found ) { \
    ivalue=qlI##n(k); \
    ics##n.insert(EntryS##n(k,ivalue)); \
  } \
  return ivalue.val[ep]; \
}

getIN(1)
getIN(2)
getIN(3)
getIN(4)

#undef getIN
