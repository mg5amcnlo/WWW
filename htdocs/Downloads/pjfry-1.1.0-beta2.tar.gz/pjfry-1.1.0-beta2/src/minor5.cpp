/*
 * minor5.cpp - pentagons
 *
 * this file is part of PJFry library
 * Copyright 2012 Valery Yundin
 */

#include "minor5.h"
#include "icache.h"
#include "mcache.h"

/* Define local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 * rrMi - matrix rank numbering
 */
#define pM1 rrM5
#define pM2 rrM4
#define pM3 rrM3
#define evalM1 evalRM5
#define evalM2 evalRM4
#define evalM3 evalRM3
#define DM1 RM5
#define DM2 RM4
#define DM3 RM3

#ifndef USE_GOLEM_MODE
// Cancel pole and finite part with E00ij - LoopTools-like convention
ncomplex Minor5::pID2rat[3] = {-ndouble(1.)/6.+ndouble(1.)/4., -ndouble(1.)/6., 0.};
#else
// Golem95 convention
ncomplex Minor5::pID2rat[3] = {-ndouble(1.)/9., 0., 0.};
#endif

/* --------------------------------------------------------
 *    Real 5-point kinematics
 * --------------------------------------------------------
 */
Minor5::Minor5(const Kinem5& k)
  : kinem(k)
{
  pID0[0] = Cache::sNAN.d64;
  pID0[1] = Cache::sNAN.d64;
  pID0[2] = Cache::sNAN.d64;
  pID1[0] = Cache::sNAN.d64;
  pID1[1] = Cache::sNAN.d64;
  pID1[2] = Cache::sNAN.d64;
  pID2[0] = Cache::sNAN.d64;
  pID2[1] = Cache::sNAN.d64;
  pID2[2] = Cache::sNAN.d64;

  const double p1=kinem.p1();
  const double p2=kinem.p2();
  const double p3=kinem.p3();
  const double p4=kinem.p4();
  const double p5=kinem.p5();
  const double s12=kinem.s12();
  const double s23=kinem.s23();
  const double s34=kinem.s34();
  const double s45=kinem.s45();
  const double s15=kinem.s15();
  const double m1=kinem.m1();
  const double m2=kinem.m2();
  const double m3=kinem.m3();
  const double m4=kinem.m4();
  const double m5=kinem.m5();

  // Boxes
  const Kinem4 k4[] = {
    Kinem4(s12,p3,p4,p5,s45,s34,m2,m3,m4,m5),
    Kinem4(p1,s23,p4,p5,s45,s15,m1,m3,m4,m5),
    Kinem4(p1,p2,s34,p5,s12,s15,m1,m2,m4,m5),
    Kinem4(p1,p2,p3,s45,s12,s23,m1,m2,m3,m5),
    Kinem4(s15,p2,p3,p4,s34,s23,m1,m2,m3,m4)
  };
  MEntry4* ptrs4[N];
  for (int i=0; i<N; i++) {
    ptrs4[i] = &MCache::entry(k4[i]); // look-up or create empty element
    mnr4[i] = ptrs4[i]->val;
  }

  // do smth, initialize minors
  kinem.setcayley(Cay);
  evalM1();

  for (int i=0; i<N; i++) {
//     printf("mnr4[%d] = %lX ------------------\n", i, mnr4[i].operator->());
    if (mnr4[i] == 0) {
      if (ptrs4[i]->val == 0) {
        mnr4[i] = Minor4::create(k4[i]);
        ptrs4[i]->val = mnr4[i]; // MCache::insertMinor4(k4[i], mnr4[i]);
      } else {
        mnr4[i] = ptrs4[i]->val;
      }
    }
  }
}

/* --------------------------------------------------------
 *
 *                5-point signed minors
 *
 * --------------------------------------------------------
 */

/* --------------------------------------------------------
    Return one-index minor with proper sign
 * --------------------------------------------------------
 */
double Minor5::M1(int i, int l)
{
  return pM1[is(i,l)];
}

/* --------------------------------------------------------
    Return two-index minor with proper sign
 * --------------------------------------------------------
 */
double Minor5::M2(int i, int j, int l, int m)
{
  int sign=signM2ud(i,j,l,m);
  if (sign==0) return 0;

  int uidx=im2(i,j);
  int lidx=im2(l,m);

  return pM2[is(uidx,lidx)]*sign;
}

/* --------------------------------------------------------
  Return three-index minor with proper sign
* --------------------------------------------------------
*/
double Minor5::M3(int i, int j, int k, int l, int m, int n)
{
  int sign=signM3ud(i,j,k,l,m,n);
  if (sign==0) return 0;

  int uidx=im3(i,j,k);
  int lidx=im3(l,m,n);

  return pM3[is(uidx,lidx)]*sign;
}

/* --------------------------------------------------------
  Evaluate all 15 one-index minors (need 2-idx minors)
* --------------------------------------------------------
*/
void Minor5::evalM1()
{
  if (not fEval[E_M2] ) {
    evalM2();
  }
#ifndef NDEBUG
  for (int i=0; i<DM1*(DM1+1)/2; i++) { pM1[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif
  {
    const int i=0;
    const int j=1;
    {
      const int l=0; const int bl=1<<l;

      double m1ele = 0.;
      const int ui = 0; // idxtbl[bi|bj]
      for (int m=1; m<=DCay-1; m++) {
        const unsigned int tdi = (1<<m)|bl;
        m1ele += pM2[iss(ui,idxtbl[tdi])]*Cay[nss(j,m)];
      }
      pM1[is(i,l)] = m1ele;
    }
  }
  const int j=0;
  for (int i=1; i<=DCay-1; i++) {
    for (int l=0; l<=i; l++) {
      double m1ele = 0.;
      for (int m=1; m<=DCay-1; m++) {
        m1ele += M2(i,j,l,m);
      }
      pM1[iss(l,i)] = m1ele;
    }
  }
  fEval[E_M1] = true;
}

/* --------------------------------------------------------
    Evaluate all 120 two-index minors (need 3-idx minors)
 * --------------------------------------------------------
 */
void Minor5::evalM2()
{
  evalM3();
#ifndef NDEBUG
  for (int i=0; i<DM2*(DM2+1)/2; i++) { pM2[i]=std::numeric_limits<double>::quiet_NaN(); }
#endif

  {
  const int i=0;                    const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-1; j++) { const unsigned int bj = 1<<j;
    const int k = j==1 ? 2 : 1;     const unsigned int bk = 1<<k;
    const unsigned int uidx = idxtbl[bi|bj];
    const unsigned int bijk = bi|bj|bk;
    for (int l=0;   l<=DCay-2; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int blm = bl|bm;
      const unsigned int lidx = idxtbl[blm];
      if (lidx > uidx) continue;

      const unsigned int ui = idxtbl[bijk];
      int sign = (k<<1)-3; // k==1 ? -1 : 1;
      double m2ele = 0.;
      if (l==0) {
        sign = -sign;
      } else {
        m2ele = sign*pM3[is(ui,idxtbl[blm|1])];
      }
      for (int n=1; n<=DCay-1; n++) {
        const unsigned int tdi = (1<<n)|blm;
        if (tdi == blm) {
          sign = -sign;
        } else {
          m2ele += sign*pM3[is(ui,idxtbl[tdi])]*Cay[ns(k,n)];
        }
      }
      pM2[iss(lidx,uidx)] = m2ele;
    }
    }
  }
  }
  const int k=0;                    const unsigned int bk = 1<<k;
  for (int i=1;   i<=DCay-2; i++) { const unsigned int bi = 1<<i;
  for (int j=i+1; j<=DCay-1; j++) { const unsigned int bj = 1<<j;
    const unsigned int uidx = idxtbl[bi|bj];
    const unsigned int bijk = bi|bj|bk;
    for (int l=0;   l<=DCay-2; l++) { const unsigned int bl = 1<<l;
    for (int m=l+1; m<=DCay-1; m++) { const unsigned int bm = 1<<m;
      const unsigned int blm = bl|bm;
      const unsigned int lidx = idxtbl[blm];
      if (lidx > uidx) continue;

      const unsigned int ui = idxtbl[bijk];
      int sign = l==0 ? -1 : 1;
      double m2ele = 0.;
      for (int n=1; n<=DCay-1; n++) {
        const unsigned int tdi = (1<<n)|blm;
        if (tdi == blm) {
          sign = -sign;
        } else {
          m2ele += sign*pM3[is(ui,idxtbl[tdi])];
        }
      }
      pM2[iss(lidx,uidx)] = m2ele;
    }
    }
  }
  }
  fEval[E_M2] = true;
}


/* --------------------------------------------------------
 *
 *                Rank-0 functions
 *
 * --------------------------------------------------------
 */

void Minor5::ID0Eval(int ep)
{
  ncomplex sum1 = 0.;
  for (int s=1; s<=N; s++) {
    sum1 += M1(0, s)*I4s(ep, s);
  }
  pID0[ep] = sum1/M1(0, 0);
}

/* --------------------------------------------------------
 *
 *                Rank-1 functions
 *
 * --------------------------------------------------------
 */
ncomplex Minor5::IDi(int ep, int i)
{
  assert(ep<=2);
  if (not fEval[E_Di+ep]) {
    IDiEval(ep);
  }
  return pIDi[ep][i-1];
}

void Minor5::IDiEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
      sum1 += M2(0, i, 0, s)*I4s(ep, s);
    }
    pIDi[ep][i-1] = sum1/M1(0, 0);
  }
  fEval[E_Di+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-2 functions
 *
 * --------------------------------------------------------
 */

void Minor5::ID1Eval(int ep)
{
  ncomplex sum1 = 0.;
  for (int s=1; s<=N; s++) {
    sum1 += M1(0, s)*I4Ds(ep, s);
  }
  pID1[ep] = sum1/M1(0, 0);
}

ncomplex Minor5::ID2ij(int ep, int i, int j)
{
  assert(ep<=2);
  if (not fEval[E_D2ij+ep]) {
    ID2ijEval(ep);
  }
  return pID2ij[ep][ns(i,j)];
}

void Minor5::ID2ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
      sum1 += M2(0, i, s, j)*I4Ds(ep, s)
             +M2(0, s, 0, j)*I4Dsi(ep, s, i);
    }
    pID2ij[ep][nss(i,j)] = sum1/M1(0, 0);
  }
  }
  fEval[E_D2ij+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-3 functions
 *
 * --------------------------------------------------------
 */

ncomplex Minor5::ID2i(int ep, int i)
{
  assert(ep<=2);
  if (not fEval[E_D2i+ep]) {
    ID2iEval(ep);
  }
  return pID2i[ep][i-1];
}

void Minor5::ID2iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
      sum1 += M2(0, s, 0, i)*I4Ds(ep, s)
             +2.*M1(s, 0)*I4D2si(ep, s, i);
    }
    pID2i[ep][i-1] = sum1/(3.*M1(0, 0));
  }
  fEval[E_D2i+ep] = true;
}

ncomplex Minor5::ID3ijk(int ep, int i, int j, int k)
{
  assert(ep<=2);
  if (not fEval[E_D3ijk+ep]) {
    ID3ijkEval(ep);
  }
  return pID3ijk[ep][is(i-1,j-1,k-1)];
}

void Minor5::ID3ijkEval(int ep)
{
  // symmetric in 'i,j,k'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
    ncomplex sum1 = 0.;
    ncomplex sumX = 0.;
    ncomplex sumY = 0.;
    if (i == j) {
      for (int s=1; s<=N; s++) {
        sum1 += 2*M2(0, j, s, k)*I4D2si(ep, s, i)
               +M2(0, s, 0, k)*I4D2sij(ep, s, i, j);
      }
      if (i != k) {
        for (int s=1; s<=N; s++) {
          sumX += M2(0, j, s, i)*I4D2si(ep, s, k)
                 +M2(0, k, s, i)*I4D2si(ep, s, j)
                 +M2(0, s, 0, i)*I4D2sij(ep, s, k, j);
        }
        sum1 = (sum1+2.*sumX)/3.;
      }
    } else { // i!=j
      for (int s=1; s<=N; s++) {
        sum1 += M2(0, j, s, k)*I4D2si(ep, s, i)
               +M2(0, i, s, k)*I4D2si(ep, s, j)
               +M2(0, s, 0, k)*I4D2sij(ep, s, i, j);
      }
      if (i != k) {
        for (int s=1; s<=N; s++) {
          sumX += M2(0, j, s, i)*I4D2si(ep, s, k)
                 +M2(0, k, s, i)*I4D2si(ep, s, j)
                 +M2(0, s, 0, i)*I4D2sij(ep, s, k, j);
        }
      }
      else { sumX = sum1; }
      if (j != k) {
        for (int s=1; s<=N; s++) {
          sumY += M2(0, k, s, j)*I4D2si(ep, s, i)
                 +M2(0, i, s, j)*I4D2si(ep, s, k)
                 +M2(0, s, 0, j)*I4D2sij(ep, s, i, k);
        }
      }
      else { sumY = sum1; }
      sum1 = (sum1+sumX+sumY)/3.;
    }
    pID3ijk[ep][iss(i-1,j-1,k-1)] = sum1/M1(0, 0);
  }
  }
  }
  fEval[E_D3ijk+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-4 functions
 *
 * --------------------------------------------------------
 */

void Minor5::ID2Eval(int ep)
{
  ncomplex sum1 = 0.;
  for (int s=1; s<=N; s++) {
    sum1 += M1(s, 0)*(I4D2s(ep, s)+pID2rat[ep]);
  }
  pID2[ep] = sum1/M1(0, 0);
}

ncomplex Minor5::ID3ij(int ep, int i, int j)
{
  assert(ep<=2);
  if (not fEval[E_D3ij+ep]) {
    ID3ijEval(ep);
  }
  return pID3ij[ep][ns(i,j)];
}

void Minor5::ID3ijEval(int ep)
{
  // symmetric in 'i,j'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
      sum1 += (M2(0, i, s, j) + M2(0, j, s, i))*(I4D2s(ep, s) + pID2rat[ep])
             +M2(0, s, 0, j)*I4D2si(ep, s, i) + M2(0, s, 0, i)*I4D2si(ep, s, j)
             +M1(s, 0)*(I4D3sij(ep, s, i, j) + I4D3sij(ep, s, j, i));
    }
    pID3ij[ep][nss(i,j)] = 0.25*sum1/M1(0, 0);
  }
  }
  fEval[E_D3ij+ep] = true;
}

ncomplex Minor5::ID4ijkl(int ep, int i, int j, int k, int l)
{
  assert(ep<=2);
  if (not fEval[E_D4ijkl+ep]) {
    ID4ijklEval(ep);
  }
  return pID4ijkl[ep][is(i-1,j-1,k-1,l-1)];
}

void Minor5::ID4ijklEval(int ep)
{
  // symmetric in 'i,j,k,l'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  for (int l=k; l<=CIDX; l++) {
    ncomplex sum1234 = 0.;
    for (int s=1; s<=N; s++) {
      ncomplex sum1 = M2(0,k,s,l)*I4D3sij(ep, s, i, j)
                     +M2(0,i,s,l)*I4D3sij(ep, s, k, j)
                     +M2(0,j,s,l)*I4D3sij(ep, s, i, k)
                     +M2(0,s,0,l)*I4D3sijk(ep, s, i, j, k);
      ncomplex sum2 = sum1;
      if (l!=k) {
        sum2 = M2(0,l,s,k)*I4D3sij(ep, s, i, j)
              +M2(0,i,s,k)*I4D3sij(ep, s, l, j)
              +M2(0,j,s,k)*I4D3sij(ep, s, i, l)
              +M2(0,s,0,k)*I4D3sijk(ep, s, i, j, l);
      }
      ncomplex sum3 = sum1;
      if (j==k) {
        sum3 = sum2;
      } else if (l!=j) {
        sum3 = M2(0,k,s,j)*I4D3sij(ep, s, i, l)
              +M2(0,i,s,j)*I4D3sij(ep, s, k, l)
              +M2(0,l,s,j)*I4D3sij(ep, s, i, k)
              +M2(0,s,0,j)*I4D3sijk(ep, s, i, l, k);
      }
      ncomplex sum4 = sum1;
      if (i==j) {
        sum4 = sum3;
      } else if (l!=i) {
        sum4 = M2(0,k,s,i)*I4D3sij(ep, s, l, j)
              +M2(0,l,s,i)*I4D3sij(ep, s, k, j)
              +M2(0,j,s,i)*I4D3sij(ep, s, l, k)
              +M2(0,s,0,i)*I4D3sijk(ep, s, l, j, k);
      }
      sum1234 += sum1+sum2+sum3+sum4;
    }
    pID4ijkl[ep][iss(i-1,j-1,k-1,l-1)] = sum1234/(4.*M1(0, 0));
  }
  }
  }
  }
  fEval[E_D4ijkl+ep] = true;
}

/* --------------------------------------------------------
 *
 *                Rank-5 functions
 *
 * --------------------------------------------------------
 */


ncomplex Minor5::ID3i(int ep, int i)
{
  assert(ep<=2);
  if (not fEval[E_D3i+ep]) {
    ID3iEval(ep);
  }
  return pID3i[ep][i-1];
}

void Minor5::ID3iEval(int ep)
{
  for (int i=1; i<=CIDX; i++) {
    ncomplex sum1 = 0.;
    for (int s=1; s<=N; s++) {
      sum1 += M2(0, s, 0, i)*I4D2s(ep, s)
             +M1(s, 0)*(4.*I4D3si(ep, s, i)-2.*(ep<2 ? I4D3si(ep+1, s, i) : 0.));
    }
    pID3i[ep][i-1] = sum1/(5.*M1(0, 0));
  }
  fEval[E_D3i+ep] = true;
}

ncomplex Minor5::ID4ijk(int ep, int i, int j, int k)
{
  assert(ep<=2);
  if (not fEval[E_D4ijk+ep]) {
    ID4ijkEval(ep);
  }
  return pID4ijk[ep][is(i-1,j-1,k-1)];
}

void Minor5::ID4ijkEval(int ep)
{
  // symmetric in 'i,j,k'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
    ncomplex sum1 = 0.;
    ncomplex sumX = 0.;
    ncomplex sumY = 0.;
    if (i == j) {
      for (int s=1; s<=N; s++) {
        sum1 += 2.*M2(0, i, s, k)*I4D3si(ep, s, j)
                +M2(0, s, 0, k)*I4D3sij(ep, s, i, j);
      }
      if (ep==0) sum1 += 1./24.*(M1(i, k)-M2(0, i, j, k));
      if (i != k) {
        for (int s=1; s<=N; s++) {
          sumX += M2(0, k, s, i)*I4D3si(ep, s, j)
                 +M2(0, j, s, i)*I4D3si(ep, s, k)
                 +M2(0, s, 0, i)*I4D3sij(ep, s, k, j);
        }
        if (ep==0) sumX += 1./48.*(M1(k, i)+M1(j, i)-M2(0, j, k, i));
        sum1 = (sum1+2.*sumX)/3.;
      }
    } else { // i!=j
      for (int s=1; s<=N; s++) {
        sum1 += M2(0, i, s, k)*I4D3si(ep, s, j)
               +M2(0, j, s, k)*I4D3si(ep, s, i)
               +M2(0, s, 0, k)*I4D3sij(ep, s, i, j);
      }
      if (ep==0) sum1 += 1./48.*(M1(i, k)+M1(j, k)-M2(0, i, j, k)-M2(0, j, i, k));
      if (i != k) {
        for (int s=1; s<=N; s++) {
          sumX += M2(0, k, s, i)*I4D3si(ep, s, j)
                 +M2(0, j, s, i)*I4D3si(ep, s, k)
                 +M2(0, s, 0, i)*I4D3sij(ep, s, k, j);
        }
        if (ep==0) sumX += 1./48.*(M1(k, i)+M1(j, i)-M2(0, k, j, i)-M2(0, j, k, i));
      }
      else { sumX = sum1; }
      if (j != k) {
        for (int s=1; s<=N; s++) {
          sumY += M2(0, i, s, j)*I4D3si(ep, s, k)
                 +M2(0, k, s, j)*I4D3si(ep, s, i)
                 +M2(0, s, 0, j)*I4D3sij(ep, s, i, k);
        }
        if (ep==0) sumY += 1./48.*(M1(i, j)+M1(k, j)-M2(0, i, k, j)-M2(0, k, i, j));
      }
      else { sumY = sum1; }
      sum1 = (sum1+sumX+sumY)/3.;
    }
    sumX = 0.;
    for (int s=1; s<=N; s++) {
      sumX += M1(s,0)*I4D4sijk(ep, s, i, j, k);
    }
    sum1 = 3.*sum1+2.*sumX;
    pID4ijk[ep][iss(i-1,j-1,k-1)] = sum1/(5.*M1(0, 0));
  }
  }
  }
  fEval[E_D4ijk+ep] = true;
}

ncomplex Minor5::ID5ijklm(int ep, int i, int j, int k, int l, int m)
{
  assert(ep<=2);
  if (not fEval[E_D5ijklm+ep]) {
    ID5ijklmEval(ep);
  }
  return pID5ijklm[ep][iss(i-1,j-1,k-1,l-1,m-1)];
}

void Minor5::ID5ijklmEval(int ep)
{
  // symmetric in 'i,j,k,lm'
  for (int i=1; i<=CIDX; i++) {
  for (int j=i; j<=CIDX; j++) {
  for (int k=j; k<=CIDX; k++) {
  for (int l=k; l<=CIDX; l++) {
  for (int m=l; m<=CIDX; m++) {
    ncomplex sum12345 = 0.;
    for (int s=1; s<=N; s++) {
      ncomplex sum1 = M2(0, l, s, m)*I4D4sijk(ep, s, i, j, k)
                     +M2(0, i, s, m)*I4D4sijk(ep, s, l, j, k)
                     +M2(0, j, s, m)*I4D4sijk(ep, s, i, l, k)
                     +M2(0, k, s, m)*I4D4sijk(ep, s, i, j, l)
                     +M2(0, s, 0, m)*I4D4sijkl(ep, s, i, j, k, l);
      ncomplex sum2 = sum1;
      if (m!=l) {
        sum2 = M2(0, m, s, l)*I4D4sijk(ep, s, i, j, k)
              +M2(0, i, s, l)*I4D4sijk(ep, s, m, j, k)
              +M2(0, j, s, l)*I4D4sijk(ep, s, i, m, k)
              +M2(0, k, s, l)*I4D4sijk(ep, s, i, j, m)
              +M2(0, s, 0, l)*I4D4sijkl(ep, s, i, j, k, m);
      }
      ncomplex sum3 = sum1;
      if (k==l) {
        sum3 = sum2;
      }
      else if (m!=k) {
        sum3 = M2(0, l, s, k)*I4D4sijk(ep, s, i, j, m)
              +M2(0, i, s, k)*I4D4sijk(ep, s, l, j, m)
              +M2(0, j, s, k)*I4D4sijk(ep, s, i, l, m)
              +M2(0, m, s, k)*I4D4sijk(ep, s, i, j, l)
              +M2(0, s, 0, k)*I4D4sijkl(ep, s, i, j, m, l);
      }
      ncomplex sum4 = sum1;
      if (j==k) {
        sum4 = sum3;
      }
      else if (m!=j) {
        sum4 = M2(0, l, s, j)*I4D4sijk(ep, s, i, m, k)
              +M2(0, i, s, j)*I4D4sijk(ep, s, l, m, k)
              +M2(0, m, s, j)*I4D4sijk(ep, s, i, l, k)
              +M2(0, k, s, j)*I4D4sijk(ep, s, i, m, l)
              +M2(0, s, 0, j)*I4D4sijkl(ep, s, i, m, k, l);
      }
      ncomplex sum5 = sum1;
      if (i==j) {
        sum5 = sum4;
      }
      else if (m!=i) {
        sum5 = M2(0, l, s, i)*I4D4sijk(ep, s, m, j, k)
              +M2(0, m, s, i)*I4D4sijk(ep, s, l, j, k)
              +M2(0, j, s, i)*I4D4sijk(ep, s, m, l, k)
              +M2(0, k, s, i)*I4D4sijk(ep, s, m, j, l)
              +M2(0, s, 0, i)*I4D4sijkl(ep, s, m, j, k, l);
      }
      sum12345 += sum1+sum2+sum3+sum4+sum5;
    }
    pID5ijklm[ep][iss(i-1,j-1,k-1,l-1,m-1)] = sum12345/(5.*M1(0, 0));
  }
  }
  }
  }
  }
  fEval[E_D5ijklm+ep] = true;
}

/* Undefine local aliases for minor arrays
 *
 * pMi  - scratched lines numbering
 */

#undef pM1
#undef pM2
#undef pM3
#undef evalM1
#undef evalM2
#undef evalM3
#undef DM1
#undef DM2
#undef DM3
