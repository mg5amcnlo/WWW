
#ifndef QUL_ENTRY_H
#define QUL_ENTRY_H

template <typename TK, typename TV>
class Entry
{
  public:
    Entry() : key(), val() {}
    Entry(const TK& k, TV& v) : key(k), val(v) {}

    Entry& operator= (const Entry& entry)
    {
      key = entry.key;
      val = entry.val;
      return *this;
    }

    TK key;
    mutable TV val; // TODO: remove auto_ptr in the future

    Entry(const Entry& entry);
};

#endif // QUL_ENTRY_H
