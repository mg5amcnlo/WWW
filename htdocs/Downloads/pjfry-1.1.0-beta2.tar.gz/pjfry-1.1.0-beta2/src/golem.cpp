/*
 * cache.h - golem-mode wrapper function
 *
 * this file is part of PJFry library
 * Copyright 2011 Valery Yundin
 */

#include "common.h"
#include "mcache.h"
#include "icache.h"
#include "kinem.h"

#include "pjfry.h"
#include "golem.h"

int Golem::N = 0;
int Golem::caylen = 0;

MinorBase* Golem::minortbl[128] = {};
Minor6::Ptr Golem::minor6;
Minor5::Ptr Golem::minor5;
Minor4::Ptr Golem::minor4;
Minor3::Ptr Golem::minor3;
Minor2::Ptr Golem::minor2;
Minor1::Ptr Golem::minor1;

double Golem::Cay[6*(6+1)/2];
unsigned int Golem::bitfield;
unsigned int Golem::bitmask;

// s,t,u :el: [0,N)
// i,j,k :el: [1,N]
const unsigned char Golem::scrtbl[128][8] = {
  {0, 1, 2, 3, 4, 5, 6, 7},  //   0         0b0
  {0, 0, 1, 2, 3, 4, 5, 6},  //   1         0b1
  {0, 1, 0, 2, 3, 4, 5, 6},  //   2        0b10
  {0, 0, 0, 1, 2, 3, 4, 5},  //   3        0b11
  {0, 1, 2, 0, 3, 4, 5, 6},  //   4       0b100
  {0, 0, 1, 0, 2, 3, 4, 5},  //   5       0b101
  {0, 1, 0, 0, 2, 3, 4, 5},  //   6       0b110
  {0, 0, 0, 0, 1, 2, 3, 4},  //   7       0b111
  {0, 1, 2, 3, 0, 4, 5, 6},  //   8      0b1000
  {0, 0, 1, 2, 0, 3, 4, 5},  //   9      0b1001
  {0, 1, 0, 2, 0, 3, 4, 5},  //  10      0b1010
  {0, 0, 0, 1, 0, 2, 3, 4},  //  11      0b1011
  {0, 1, 2, 0, 0, 3, 4, 5},  //  12      0b1100
  {0, 0, 1, 0, 0, 2, 3, 4},  //  13      0b1101
  {0, 1, 0, 0, 0, 2, 3, 4},  //  14      0b1110
  {0, 0, 0, 0, 0, 1, 2, 3},  //  15      0b1111
  {0, 1, 2, 3, 4, 0, 5, 6},  //  16     0b10000
  {0, 0, 1, 2, 3, 0, 4, 5},  //  17     0b10001
  {0, 1, 0, 2, 3, 0, 4, 5},  //  18     0b10010
  {0, 0, 0, 1, 2, 0, 3, 4},  //  19     0b10011
  {0, 1, 2, 0, 3, 0, 4, 5},  //  20     0b10100
  {0, 0, 1, 0, 2, 0, 3, 4},  //  21     0b10101
  {0, 1, 0, 0, 2, 0, 3, 4},  //  22     0b10110
  {0, 0, 0, 0, 1, 0, 2, 3},  //  23     0b10111
  {0, 1, 2, 3, 0, 0, 4, 5},  //  24     0b11000
  {0, 0, 1, 2, 0, 0, 3, 4},  //  25     0b11001
  {0, 1, 0, 2, 0, 0, 3, 4},  //  26     0b11010
  {0, 0, 0, 1, 0, 0, 2, 3},  //  27     0b11011
  {0, 1, 2, 0, 0, 0, 3, 4},  //  28     0b11100
  {0, 0, 1, 0, 0, 0, 2, 3},  //  29     0b11101
  {0, 1, 0, 0, 0, 0, 2, 3},  //  30     0b11110
  {0, 0, 0, 0, 0, 0, 1, 2},  //  31     0b11111
  {0, 1, 2, 3, 4, 5, 0, 6},  //  32    0b100000
  {0, 0, 1, 2, 3, 4, 0, 5},  //  33    0b100001
  {0, 1, 0, 2, 3, 4, 0, 5},  //  34    0b100010
  {0, 0, 0, 1, 2, 3, 0, 4},  //  35    0b100011
  {0, 1, 2, 0, 3, 4, 0, 5},  //  36    0b100100
  {0, 0, 1, 0, 2, 3, 0, 4},  //  37    0b100101
  {0, 1, 0, 0, 2, 3, 0, 4},  //  38    0b100110
  {0, 0, 0, 0, 1, 2, 0, 3},  //  39    0b100111
  {0, 1, 2, 3, 0, 4, 0, 5},  //  40    0b101000
  {0, 0, 1, 2, 0, 3, 0, 4},  //  41    0b101001
  {0, 1, 0, 2, 0, 3, 0, 4},  //  42    0b101010
  {0, 0, 0, 1, 0, 2, 0, 3},  //  43    0b101011
  {0, 1, 2, 0, 0, 3, 0, 4},  //  44    0b101100
  {0, 0, 1, 0, 0, 2, 0, 3},  //  45    0b101101
  {0, 1, 0, 0, 0, 2, 0, 3},  //  46    0b101110
  {0, 0, 0, 0, 0, 1, 0, 2},  //  47    0b101111
  {0, 1, 2, 3, 4, 0, 0, 5},  //  48    0b110000
  {0, 0, 1, 2, 3, 0, 0, 4},  //  49    0b110001
  {0, 1, 0, 2, 3, 0, 0, 4},  //  50    0b110010
  {0, 0, 0, 1, 2, 0, 0, 3},  //  51    0b110011
  {0, 1, 2, 0, 3, 0, 0, 4},  //  52    0b110100
  {0, 0, 1, 0, 2, 0, 0, 3},  //  53    0b110101
  {0, 1, 0, 0, 2, 0, 0, 3},  //  54    0b110110
  {0, 0, 0, 0, 1, 0, 0, 2},  //  55    0b110111
  {0, 1, 2, 3, 0, 0, 0, 4},  //  56    0b111000
  {0, 0, 1, 2, 0, 0, 0, 3},  //  57    0b111001
  {0, 1, 0, 2, 0, 0, 0, 3},  //  58    0b111010
  {0, 0, 0, 1, 0, 0, 0, 2},  //  59    0b111011
  {0, 1, 2, 0, 0, 0, 0, 3},  //  60    0b111100
  {0, 0, 1, 0, 0, 0, 0, 2},  //  61    0b111101
  {0, 1, 0, 0, 0, 0, 0, 2},  //  62    0b111110
  {0, 0, 0, 0, 0, 0, 0, 1},  //  63    0b111111
  {0, 1, 2, 3, 4, 5, 6, 0},  //  64   0b1000000
  {0, 0, 1, 2, 3, 4, 5, 0},  //  65   0b1000001
  {0, 1, 0, 2, 3, 4, 5, 0},  //  66   0b1000010
  {0, 0, 0, 1, 2, 3, 4, 0},  //  67   0b1000011
  {0, 1, 2, 0, 3, 4, 5, 0},  //  68   0b1000100
  {0, 0, 1, 0, 2, 3, 4, 0},  //  69   0b1000101
  {0, 1, 0, 0, 2, 3, 4, 0},  //  70   0b1000110
  {0, 0, 0, 0, 1, 2, 3, 0},  //  71   0b1000111
  {0, 1, 2, 3, 0, 4, 5, 0},  //  72   0b1001000
  {0, 0, 1, 2, 0, 3, 4, 0},  //  73   0b1001001
  {0, 1, 0, 2, 0, 3, 4, 0},  //  74   0b1001010
  {0, 0, 0, 1, 0, 2, 3, 0},  //  75   0b1001011
  {0, 1, 2, 0, 0, 3, 4, 0},  //  76   0b1001100
  {0, 0, 1, 0, 0, 2, 3, 0},  //  77   0b1001101
  {0, 1, 0, 0, 0, 2, 3, 0},  //  78   0b1001110
  {0, 0, 0, 0, 0, 1, 2, 0},  //  79   0b1001111
  {0, 1, 2, 3, 4, 0, 5, 0},  //  80   0b1010000
  {0, 0, 1, 2, 3, 0, 4, 0},  //  81   0b1010001
  {0, 1, 0, 2, 3, 0, 4, 0},  //  82   0b1010010
  {0, 0, 0, 1, 2, 0, 3, 0},  //  83   0b1010011
  {0, 1, 2, 0, 3, 0, 4, 0},  //  84   0b1010100
  {0, 0, 1, 0, 2, 0, 3, 0},  //  85   0b1010101
  {0, 1, 0, 0, 2, 0, 3, 0},  //  86   0b1010110
  {0, 0, 0, 0, 1, 0, 2, 0},  //  87   0b1010111
  {0, 1, 2, 3, 0, 0, 4, 0},  //  88   0b1011000
  {0, 0, 1, 2, 0, 0, 3, 0},  //  89   0b1011001
  {0, 1, 0, 2, 0, 0, 3, 0},  //  90   0b1011010
  {0, 0, 0, 1, 0, 0, 2, 0},  //  91   0b1011011
  {0, 1, 2, 0, 0, 0, 3, 0},  //  92   0b1011100
  {0, 0, 1, 0, 0, 0, 2, 0},  //  93   0b1011101
  {0, 1, 0, 0, 0, 0, 2, 0},  //  94   0b1011110
  {0, 0, 0, 0, 0, 0, 1, 0},  //  95   0b1011111
  {0, 1, 2, 3, 4, 5, 0, 0},  //  96   0b1100000
  {0, 0, 1, 2, 3, 4, 0, 0},  //  97   0b1100001
  {0, 1, 0, 2, 3, 4, 0, 0},  //  98   0b1100010
  {0, 0, 0, 1, 2, 3, 0, 0},  //  99   0b1100011
  {0, 1, 2, 0, 3, 4, 0, 0},  // 100   0b1100100
  {0, 0, 1, 0, 2, 3, 0, 0},  // 101   0b1100101
  {0, 1, 0, 0, 2, 3, 0, 0},  // 102   0b1100110
  {0, 0, 0, 0, 1, 2, 0, 0},  // 103   0b1100111
  {0, 1, 2, 3, 0, 4, 0, 0},  // 104   0b1101000
  {0, 0, 1, 2, 0, 3, 0, 0},  // 105   0b1101001
  {0, 1, 0, 2, 0, 3, 0, 0},  // 106   0b1101010
  {0, 0, 0, 1, 0, 2, 0, 0},  // 107   0b1101011
  {0, 1, 2, 0, 0, 3, 0, 0},  // 108   0b1101100
  {0, 0, 1, 0, 0, 2, 0, 0},  // 109   0b1101101
  {0, 1, 0, 0, 0, 2, 0, 0},  // 110   0b1101110
  {0, 0, 0, 0, 0, 1, 0, 0},  // 111   0b1101111
  {0, 1, 2, 3, 4, 0, 0, 0},  // 112   0b1110000
  {0, 0, 1, 2, 3, 0, 0, 0},  // 113   0b1110001
  {0, 1, 0, 2, 3, 0, 0, 0},  // 114   0b1110010
  {0, 0, 0, 1, 2, 0, 0, 0},  // 115   0b1110011
  {0, 1, 2, 0, 3, 0, 0, 0},  // 116   0b1110100
  {0, 0, 1, 0, 2, 0, 0, 0},  // 117   0b1110101
  {0, 1, 0, 0, 2, 0, 0, 0},  // 118   0b1110110
  {0, 0, 0, 0, 1, 0, 0, 0},  // 119   0b1110111
  {0, 1, 2, 3, 0, 0, 0, 0},  // 120   0b1111000
  {0, 0, 1, 2, 0, 0, 0, 0},  // 121   0b1111001
  {0, 1, 0, 2, 0, 0, 0, 0},  // 122   0b1111010
  {0, 0, 0, 1, 0, 0, 0, 0},  // 123   0b1111011
  {0, 1, 2, 0, 0, 0, 0, 0},  // 124   0b1111100
  {0, 0, 1, 0, 0, 0, 0, 0},  // 125   0b1111101
  {0, 1, 0, 0, 0, 0, 0, 0},  // 126   0b1111110
  {0, 0, 0, 0, 0, 0, 0, 0},  // 127   0b1111111
};

void Golem::initgolem95(int n)
{
  assert(1<=n && n<=6);

// cleanup old minor cache
  minor6 = Minor6::Ptr();
  minor5 = Minor5::Ptr();
  minor4 = Minor4::Ptr();
  minor3 = Minor3::Ptr();
  minor2 = Minor2::Ptr();
  minor1 = Minor1::Ptr();

// set N to the new value
  N = n;
  caylen = N*(N+1)/2;
  for (int i=0; i<caylen; i++) {
    Cay[i] = 0.;
  }
  bitfield = 0;
  bitmask = (1<<caylen)-1;
}

void Golem::prepare6()
{
  assert(N==6);
  const Kinem6 k6 = Kinem6(Cay);
  minor6 = Minor6::create(k6);
  minortbl[0] = minor6.operator->();

  for (int r=0; r<N; r++) {
    Minor5::Ptr m5 = minor6->mnr5[r];
    minortbl[(1<<r)] = m5.operator->();
    for (int s=r+1; s<N; s++) {
      Minor4::Ptr m4 = m5->mnr4[s-1];
      minortbl[(1<<r|1<<s)] = m4.operator->();
      for (int t=s+1; t<N; t++) {
        Minor3::Ptr m3 = m4->mnr3[t-2];
        minortbl[(1<<r|1<<s|1<<t)] = m3.operator->();
        for (int u=t+1; u<N; u++) {
          Minor2::Ptr m2 = m3->mnr2[u-3];
          minortbl[(1<<r|1<<s|1<<t|1<<u)] = m2.operator->();
          for (int v=u+1; v<N; v++) {
            Minor1::Ptr m1 = m2->mnr1[v-4];
            minortbl[(1<<r|1<<s|1<<t|1<<u|1<<v)] = m1.operator->();
          }
        }
      }
    }
  }
}

void Golem::prepare5()
{
  assert(N==5);
  const Kinem5 k5 = Kinem5(Cay);
  minor5 = Minor5::create(k5);
  minortbl[0] = minor5.operator->();

  for (int s=0; s<N; s++) {
    Minor4::Ptr m4 = minor5->mnr4[s];
    minortbl[(1<<s)] = m4.operator->();
    for (int t=s+1; t<N; t++) {
      Minor3::Ptr m3 = m4->mnr3[t-1];
      minortbl[(1<<s|1<<t)] = m3.operator->();
      for (int u=t+1; u<N; u++) {
        Minor2::Ptr m2 = m3->mnr2[u-2];
        minortbl[(1<<s|1<<t|1<<u)] = m2.operator->();
        for (int v=u+1; v<N; v++) {
          Minor1::Ptr m1 = m2->mnr1[v-3];
          minortbl[(1<<s|1<<t|1<<u|1<<v)] = m1.operator->();
        }
      }
    }
  }
}

void Golem::prepare4()
{
  assert(N==4);
  const Kinem4 k4 = Kinem4(Cay);
  minor4 = Minor4::create(k4);
  minortbl[0] = minor4.operator->();

  for (int t=0; t<N; t++) {
    Minor3::Ptr m3 = minor4->mnr3[t];
    minortbl[(1<<t)] = m3.operator->();
    for (int u=t+1; u<N; u++) {
      Minor2::Ptr m2 = m3->mnr2[u-1];
      minortbl[(1<<t|1<<u)] = m2.operator->();
      for (int v=u+1; v<N; v++) {
        Minor1::Ptr m1 = m2->mnr1[v-2];
        minortbl[(1<<t|1<<u|1<<v)] = m1.operator->();
      }
    }
  }
}

void Golem::prepare3()
{
  assert(N==3);
  const Kinem3 k3 = Kinem3(Cay);
  minor3 = Minor3::create(k3);
  minortbl[0] = minor3.operator->();

  for (int u=0; u<N; u++) {
    Minor2::Ptr m2 = minor3->mnr2[u];
    minortbl[(1<<u)] = m2.operator->();
    for (int v=u+1; v<N; v++) {
      Minor1::Ptr m1 = m2->mnr1[v-1];
      minortbl[(1<<u|1<<v)] = m1.operator->();
    }
  }
}

void Golem::prepare2()
{
  assert(N==2);
  const Kinem2 k2 = Kinem2(Cay);
  minor2 = Minor2::create(k2);
  minortbl[0] = minor2.operator->();

  for (int v=0; v<N; v++) {
    Minor1::Ptr m1 = minor2->mnr1[v];
    minortbl[(1<<v)] = m1.operator->();
  }
}

void Golem::prepare1()
{
  assert(N==1);
  const Kinem1 k1 = Kinem1(Cay);
  minor1 = Minor1::create(k1);
  minortbl[0] = minor1.operator->();
}

void Golem::preparesmatrix()
{
  switch (N)
  {
    case 6:
      prepare6();
      break;
    case 5:
      prepare5();
      break;
    case 4:
      prepare4();
      break;
    case 3:
      prepare3();
      break;
    case 2:
      prepare2();
      break;
    case 1:
      prepare1();
      break;
    default:
      assert(1<=N && N<=6);
  }
}

double Golem::getmat(int i, int j)
{
  int idx = MinorBase::ns(i,j);
  assert(idx<caylen);
  unsigned int mark = 1<<idx;
  assert((bitfield & mark) != 0);
  return -Cay[idx];  // golem95 cayley = -pjfry cayley
}

void Golem::setmat(int i, int j, double val)
{
  int idx = MinorBase::ns(i,j);
  unsigned int mark=1<<idx;
  Cay[idx] = -val;  // golem95 cayley = -pjfry cayley
  bitfield |= mark;
//   if (bitfield == bitmask) {
//     preparesmatrix();
//   }
}


#define golem(type,indices) \
  const int s0 = s>>1; \
  ncomplex ivalue = minortbl[s0]->type indices;

#define scr(i) (scrtbl[s0][i])

ncomplex Golem::ga0(int s, int ep)
{
  golem(A,(ep))
  return ivalue;
}

ncomplex Golem::ga1(int i, int s, int ep)
{
  if ( ((1<<i))&s ) return 0.;
  golem(A,(ep, scr(i)))
  return -ivalue;
}

ncomplex Golem::ga2(int i, int j, int s, int ep)
{
  if ( ((1<<j)|(1<<i))&s ) return 0.;
  golem(A,(ep, scr(i), scr(j)))
  return ivalue;
}

ncomplex Golem::gb2(int s, int ep)
{
  golem(B,(ep))
  return ivalue;
}

ncomplex Golem::ga3(int i, int j, int k, int s, int ep)
{
  if ( ((1<<k)|(1<<j)|(1<<i))&s ) return 0;
  golem(A,(ep, scr(i), scr(j), scr(k)))
  return -ivalue;
}

ncomplex Golem::gb3(int i, int s, int ep)
{
  if ( ((1<<i))&s ) return 0;
  golem(B,(ep, scr(i)))
  return -ivalue;
}

ncomplex Golem::ga4(int i, int j, int k, int l, int s, int ep)
{
  if ( ((1<<l)|(1<<k)|(1<<j)|(1<<i))&s ) return 0;
  golem(A,(ep, scr(i), scr(j), scr(k), scr(l)))
  return ivalue;
}

ncomplex Golem::gb4(int i, int j, int s, int ep)
{
  if ( ((1<<j)|(1<<i))&s ) return 0;
  golem(B,(ep, scr(i), scr(j)))
  return ivalue;
}

ncomplex Golem::gc4(int s, int ep)
{
  golem(C,(ep))
  return ivalue;
}

ncomplex Golem::ga5(int i, int j, int k, int l, int m, int s, int ep)
{
  if ( ((1<<m)|(1<<l)|(1<<k)|(1<<j)|(1<<i))&s ) return 0;
  golem(A,(ep, scr(i), scr(j), scr(k), scr(l), scr(m)))
  return -ivalue;
}

ncomplex Golem::gb5(int i, int j, int k, int s, int ep)
{
  if ( ((1<<k)|(1<<j)|(1<<i))&s ) return 0;
  golem(B,(ep, scr(i), scr(j), scr(k)))
  return -ivalue;
}

ncomplex Golem::gc5(int i, int s, int ep)
{
  if ( ((1<<i))&s ) return 0;
  golem(C,(ep, scr(i)))
  return -ivalue;
}

ncomplex Golem::ga6(int i, int j, int k, int l, int m, int n, int s, int ep)
{
  if ( ((1<<n)|(1<<m)|(1<<l)|(1<<k)|(1<<j)|(1<<i))&s ) return 0;
  golem(A,(ep, scr(i), scr(j), scr(k), scr(l), scr(m), scr(n)))
  return ivalue;
}

ncomplex Golem::gb6(int i, int j, int k, int l, int s, int ep)
{
  if ( ((1<<l)|(1<<k)|(1<<j)|(1<<i))&s ) return 0;
  golem(B,(ep, scr(i), scr(j), scr(k), scr(l)))
  return ivalue;
}

ncomplex Golem::gc6(int i, int j, int s, int ep)
{
  if ( ((1<<j)|(1<<i))&s ) return 0;
  golem(C,(ep, scr(i), scr(j)))
  return ivalue;
}
#undef golem


// ====================================================
// ====================================================
// ====================================================
// ====================================================
// ====================================================
// ====================================================
double pggetmusq_()
{
  return ICache::getMu2();
}

void pgsetmusq_(double *mu2)
{
  ICache::setMu2(*mu2);
  Golem::preparesmatrix();
}

double pggetmat_(int *i, int *j)
{
  return Golem::getmat(*i,*j);
}

void pgpreparesmatrix_()
{
  Golem::preparesmatrix();
}

void pgsetmat_(int *i, int *j, double *val)
{
  Golem::setmat(*i,*j,*val);
}

void pginitgolem95_(int *n)
{
  Golem::initgolem95(*n);
}

#ifdef USE_F2C
/* f2c,g77,ifort calling convention section (result is the first parameter) */

void pga0_(pj_complex *rslt, int *s, int *ep)
{ *rslt = Golem::ga0(*s,*ep); }

void pga1_(pj_complex *rslt, int *i, int *s, int *ep)
{ *rslt = Golem::ga1(*i,*s,*ep); }

void pga2_(pj_complex *rslt, int *i, int *j, int *s, int *ep)
{ *rslt = Golem::ga2(*i,*j,*s,*ep); }

void pgb2_(pj_complex *rslt, int *s, int *ep)
{ *rslt = Golem::gb2(*s,*ep); }

void pga3_(pj_complex *rslt, int *i, int *j, int *k, int *s, int *ep)
{ *rslt = Golem::ga3(*i,*j,*k,*s,*ep); }

void pgb3_(pj_complex *rslt, int *i, int *s, int *ep)
{ *rslt = Golem::gb3(*i,*s,*ep); }

void pga4_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *s, int *ep)
{ *rslt = Golem::ga4(*i,*j,*k,*l,*s,*ep); }

void pgb4_(pj_complex *rslt, int *i, int *j, int *s, int *ep)
{ *rslt = Golem::gb4(*i,*j,*s,*ep); }

void pgc4_(pj_complex *rslt, int *s, int *ep)
{ *rslt = Golem::gc4(*s,*ep); }

void pga5_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *m, int *s, int *ep)
{ *rslt = Golem::ga5(*i,*j,*k,*l,*m,*s,*ep); }

void pgb5_(pj_complex *rslt, int *i, int *j, int *k, int *s, int *ep)
{ *rslt = Golem::gb5(*i,*j,*k,*s,*ep); }

void pgc5_(pj_complex *rslt, int *i, int *s, int *ep)
{ *rslt = Golem::gc5(*i,*s,*ep); }

void pga6_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *m, int *n, int *s, int *ep)
{ *rslt = Golem::ga6(*i,*j,*k,*l,*m,*n,*s,*ep); }

void pgb6_(pj_complex *rslt, int *i, int *j, int *k, int *l, int *s, int *ep)
{ *rslt = Golem::gb6(*i,*j,*k,*l,*s,*ep); }

void pgc6_(pj_complex *rslt, int *i, int *j, int *s, int *ep)
{ *rslt = Golem::gc6(*i,*j,*s,*ep); }

#else /* USE_F2C */
/* GNU calling convention section (result is a complex return value) */

pj_complex pga0_(int *s, int *ep)
{ return Golem::ga0(*s,*ep); }

pj_complex pga1_(int *i, int *s, int *ep)
{ return Golem::ga1(*i,*s,*ep); }

pj_complex pga2_(int *i, int *j, int *s, int *ep)
{ return Golem::ga2(*i,*j,*s,*ep); }

pj_complex pgb2_(int *s, int *ep)
{ return Golem::gb2(*s,*ep); }

pj_complex pga3_(int *i, int *j, int *k, int *s, int *ep)
{ return Golem::ga3(*i,*j,*k,*s,*ep); }

pj_complex pgb3_(int *i, int *s, int *ep)
{ return Golem::gb3(*i,*s,*ep); }

pj_complex pga4_(int *i, int *j, int *k, int *l, int *s, int *ep)
{ return Golem::ga4(*i,*j,*k,*l,*s,*ep); }

pj_complex pgb4_(int *i, int *j, int *s, int *ep)
{ return Golem::gb4(*i,*j,*s,*ep); }

pj_complex pgc4_(int *s, int *ep)
{ return Golem::gc4(*s,*ep); }

pj_complex pga5_(int *i, int *j, int *k, int *l, int *m, int *s, int *ep)
{ return Golem::ga5(*i,*j,*k,*l,*m,*s,*ep); }

pj_complex pgb5_(int *i, int *j, int *k, int *s, int *ep)
{ return Golem::gb5(*i,*j,*k,*s,*ep); }

pj_complex pgc5_(int *i, int *s, int *ep)
{ return Golem::gc5(*i,*s,*ep); }

pj_complex pga6_(int *i, int *j, int *k, int *l, int *m, int *n, int *s, int *ep)
{ return Golem::ga6(*i,*j,*k,*l,*m,*n,*s,*ep); }

pj_complex pgb6_(int *i, int *j, int *k, int *l, int *s, int *ep)
{ return Golem::gb6(*i,*j,*k,*l,*s,*ep); }

pj_complex pgc6_(int *i, int *j, int *s, int *ep)
{ return Golem::gc6(*i,*j,*s,*ep); }

#endif /* USE_F2C */

